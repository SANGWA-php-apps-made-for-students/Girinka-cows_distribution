<?php

header("HTTP/1.1 200 OK");
header("Server: Apache-Coyote/1.1");
header("Path=/ekaye/girinka.php");
header("Freeflow: FB");
header("cpRefId: 12345");
header("Expires: -1");
header("Pragma: no-cache");
header("Cache-Control: max-age=0");
header("Content-Type: UTF-8");
header("Content-Length: 20");
echo "Ikaze mubibazo!"; //ok, go on..
?>
