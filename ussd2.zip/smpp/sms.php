<?php

    require_once 'smppclient.class.php';
    require_once 'gsmencoder.class.php';
    require_once 'sockettransport.class.php';


    // Construct transport and clienti
    $transport = new SocketTransport(array('172.17.83.20'), 3339);
    $transport->setRecvTimeout(30000);
    $smpp = new SmppClient($transport);


    // Activate binary hex-output of server interaction
    $smpp->debug = true;
    $transport->debug = true;

    // Open the connection
    $transport->open();
    $smpp->bindTransmitter("SMPP294", "924SMPP");

    // Optional connection specific overrides
    //SmppClient::$sms_null_terminate_octetstrings = false;
    //SmppClient::$csms_method = SmppClient::CSMS_PAYLOAD;
    //SmppClient::$sms_registered_delivery_flag = SMPP::REG_DELIVERY_SMSC_BOTH;
    // Prepare message
    $message = 'Umuturage utuye Akaboti/Impinga/Kansi atanze amakuru yinka yapfuye';
    $encodedMessage = GsmEncoder::utf8_to_gsm0338($message);
    $from = new SmppAddress('757', SMPP::TON_ALPHANUMERIC);
    //$to = new SmppAddress('250785142113',SMPP::TON_INTERNATIONAL,SMPP::NPI_E164);
    $rec1 = new SmppAddress(250784113888, SMPP::TON_INTERNATIONAL, SMPP::NPI_E164);
    $rec1_Mayor = new SmppAddress(250788612293, SMPP::TON_INTERNATIONAL, SMPP::NPI_E164);
    $rec2_V_Mayor = new SmppAddress(250788842221, SMPP::TON_INTERNATIONAL, SMPP::NPI_E164);
    $rec3_Director_vet = new SmppAddress(250788352353, SMPP::TON_INTERNATIONAL, SMPP::NPI_E164);
    $rec4_Main_vet = new SmppAddress(250788977537, SMPP::TON_INTERNATIONAL, SMPP::NPI_E164);
    $rec5_Tema = new SmppAddress(250788807478, SMPP::TON_INTERNATIONAL, SMPP::NPI_E164);
    $rec6_dev = new SmppAddress(250784113888, SMPP::TON_INTERNATIONAL, SMPP::NPI_E164);

    $smpp->sendSMS($from, $rec1_Mayor, $encodedMessage, $tags);
    $smpp->sendSMS($from, $rec2_V_Mayor, $encodedMessage, $tags);
    $smpp->sendSMS($from, $rec3_Director_vet, $encodedMessage, $tags);
    $smpp->sendSMS($from, $rec4_Main_vet, $encodedMessage, $tags);
    $smpp->sendSMS($from, $rec5_Tema, $encodedMessage, $tags);
    $smpp->sendSMS($from, $rec6_dev, $encodedMessage, $tags);
    // Close connection
    $smpp->close();
    