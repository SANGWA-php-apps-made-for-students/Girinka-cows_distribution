<?php

//DATABASE CONSTANTS
//     'mmc_muh_user', 'Q.muhabura'
    defined("DB_SERVE") ? NULL : DEFINE("DB_SERVE", "localhost");
    defined("DB_USER") ? NULL : DEFINE("DB_USER", "root");
    defined("DB_PASS") ? NULL : DEFINE("DB_PASS", "Q22Ryf431kx");
    defined("DB_NAME") ? NULL : DEFINE("DB_NAME", "girinka");
?>
