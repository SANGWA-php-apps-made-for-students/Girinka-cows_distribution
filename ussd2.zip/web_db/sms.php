<?php

    require_once 'smppclient.class.php';
    require_once 'gsmencoder.class.php';
    require_once 'sockettransport.class.php';

    class send_sms {

        function saying($names, $address, $message, $receiver) {

            // Construct transport and clienti
            $transport = new SocketTransport(array('172.17.83.20'), 3339);
            $transport->setRecvTimeout(20000);
            $smpp = new SmppClient($transport);
            // Activate binary hex-output of server interaction
            $smpp->debug = true;
            $transport->debug = true;
            // Open the connection
            $transport->open();
            $smpp->bindTransmitter("SMPP294", "924SMPP");
            // Prepare message
//            $message = $address; // 'Umuturage utuye Akaboti/Impinga/Kansi atanze amakuru yinka yapfuye';;
            $addrs_msg = $names . ' utuye ' . $address . ' ' . $message;
            $encodedMessage = GsmEncoder::utf8_to_gsm0338($addrs_msg);
            $from = new SmppAddress('757', SMPP::TON_ALPHANUMERIC);
            $to = new SmppAddress($receiver, SMPP::TON_INTERNATIONAL, SMPP::NPI_E164);

            $smpp->sendSMS($from, $to, $encodedMessage, $tags);
            // Close connection
            $smpp->close();
        }

    }
    