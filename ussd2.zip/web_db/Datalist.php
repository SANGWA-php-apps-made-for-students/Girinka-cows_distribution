<?php

require_once 'connection.php';

class Datalist {

    function get_distr_by_citizen($nid) {
        $obj = new dbconnection();
        $sql = "select cow_distribution.cow_distribution_id from cow_distribution where cow_distribution.citizen=:nid";
        $stmt = $obj->openconnection()->prepare($sql);
        $stmt->execute(array(":nid" => $nid));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['cow_distribution_id'];
        return $field;
    }

    function get_citizenid_by_nid($nid) {
        $obj = new dbconnection();
        $sql = "select citizen.citizen_id from citizen where Idnumber=:nid";
        $stmt = $obj->openconnection()->prepare($sql);
        $stmt->execute(array(":nid" => $nid));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['citizen_id'];
        return $field;
    }

    function citzien_recieved_cow($nid) {
        $obj = new dbconnection();
        $sql = " select cow_distribution.citizen  from cow_distribution 
                join citizen on cow_distribution.citizen = citizen.citizen_id 
                where citizen.citizen_id=:nid
                group by citizen.Idnumber";
        $stmt = $obj->openconnection()->prepare($sql);
        $stmt->execute(array(":nid" => $nid));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['citizen'];
        return $field;
    }

    function cow_already_dead($distr) {
        $obj = new dbconnection();
        $sql = " select cow_distribution from cowdead where 
            cowdead.cow_distribution =:distr ";
        $stmt = $obj->openconnection()->prepare($sql);
        $stmt->execute(array(":distr" => $distr));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['cow_distribution'];
        return $field;
    }

}
