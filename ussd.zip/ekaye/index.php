<?php

require_once 'includes/config.php';
require_once 'includes/database.php';
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
if ($_REQUEST['input'] == '757' || $_REQUEST['input'] == '0') {
    header("HTTP/1.1 200 OK");
    header("Server: Apache-Coyote/1.1");
    header("Path=/ekaye/index.php");
    header("Freeflow: FC");
    header("cpRefId: 12345");
    header("Expires: -1");
    header("Pragma: no-cache");
    header("Cache-Control: max-age=0");
    header("Content-Type: UTF-8");
    header("Content-Length: 20");
    $sql = "INSERT INTO ussd(data,input,sessionid,phone,time) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW()) ";
    $database->query($sql);
    echo "Welcome to Ekaye By Gisagara district.Hitamo icyo ushaka kureba: \n 1.Ibibazo \n 2.Ubudehe \n 3.Umuhigo \n 4.Girinka \n 5.Gusohoka ";
}
if ($_REQUEST['input'] == '1') {//For ibibazo input
    header("HTTP/1.1 200 OK");
    header("Server: Apache-Coyote/1.1");
    header("Path=/ekaye/index.php");
    header("Freeflow: FC");
    header("cpRefId: 12345");
    header("Expires: -1");
    header("Pragma: no-cache");
    header("Cache-Control: max-age=0");
    header("Content-Type: UTF-8");
    header("Content-Length: 20");
    $sql = "INSERT INTO ussd(data,input,sessionid,phone,time) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW()) ";
    $database->query($sql);
    echo "IBIBAZO. \n Shyiramo numero y' indangamuntu kugirango ubashe gukomeza \n Shyiramo 0 usubire ahabanza";
}
if ($_REQUEST['input'] == '2') {//for ubudehe input
    $_SESSION['ubudehe'] = 2;
    header("HTTP/1.1 200 OK");
    header("Server: Apache-Coyote/1.1");
    header("Path=/ekaye/index.php");
    header("Freeflow: FC");
    header("cpRefId: 12345");
    header("Expires: -1");
    header("Pragma: no-cache");
    header("Cache-Control: max-age=0");
    header("Content-Type: UTF-8");
    header("Content-Length: 20");
    $sql = "INSERT INTO ussd(data,input,sessionid,phone,time) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW()) ";
    $database->query($sql);
    echo "UBUDEHE. \n Shyiramo numero y' indangamuntu ubashe gukomeza, niba ntayo ufite shyiramo iy'ukurera \n Shyiramo 0 usubire ahabanza";
}
if ($_REQUEST['input'] == '3') {// for imihigo
    header("HTTP/1.1 200 OK");
    header("Server: Apache-Coyote/1.1");
    header("Path=/ekaye/imihigo.php");
    header("Freeflow: FC");
    header("cpRefId: 12345");
    header("Expires: -1");
    header("Pragma: no-cache");
    header("Cache-Control: max-age=0");
    header("Content-Type: UTF-8");
    header("Content-Length: 20");
    $sql = "INSERT INTO ussd(data,input,sessionid,phone,time) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW()) ";
    $database->query($sql);
    echo "UMUHIGO. \n Shyiramo numero y'indangamuntu ubashe gukomeza \n Shyiramo 0 usubire ahabanza";
}
if ($_REQUEST['input'] == '5') {// for closing the flare
    header("HTTP/1.1 200 OK");
    header("Server: Apache-Coyote/1.1");
    header("Path=/ekaye/index.php");
    header("cpRefId: 12345");
    header("Expires: -1");
    header("Pragma: no-cache");
    header("Cache-Control: max-age=0");
    $sql = "INSERT INTO ussd(data,input,sessionid,phone,time) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW()) ";
    $database->query($sql);
    echo "Murakoze gukoresha E-kaye by Gisagara district!";
}
if ($_REQUEST['input'] == '4') {// for closing the flare
    header("HTTP/1.1 200 OK");
    header("Server: Apache-Coyote/1.1");
    header("Path=/ekaye/index.php");
    header("cpRefId: 12345");
    header("Expires: -1");
    header("Pragma: no-cache");
    header("Cache-Control: max-age=0");
    $sql = "INSERT INTO ussd(data,input,sessionid,phone,time) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW()) ";
    $database->query($sql);
    echo "1. ABAHAWE INKA \n"
    . "2. ABATARAHAWE INKA \n"
    . "3. INKA YAPFUYE \n"
    . "4. INKA YAVUTSE \n"
    . "5. INKA YAVUTSE \n"
    . "6. INKA YIBWE";
}

if ($_REQUEST['input'] != 757 && $_REQUEST['input'] != 0 && $_REQUEST['input'] != 1 && $_REQUEST['input'] != 2 && $_REQUEST['input'] != 3 && $_REQUEST['input'] != 4) {
    $sql = "SELECT id,input,sessionid,nic FROM ussd WHERE sessionid ='{$_REQUEST['sessionid']}' ORDER BY time DESC LIMIT 1  ";
    $query = $database->query($sql);
    $row = $database->fetch_array($query);
    //Processing ubudehe
    if ($row['input'] == 2) {
        header("HTTP/1.1 200 OK");
        header("Server: Apache-Coyote/1.1");
        header("Path=/ekaye/index.php");
        header("Freeflow: FC");
        header("cpRefId: 12345");
        header("Expires: -1");
        header("Pragma: no-cache");
        header("Cache-Control: max-age=0");
        header("Content-Type: UTF-8");
        header("Content-Length: 20");
        $sql = "SELECT category,hhm  FROM ubudehe WHERE q_1_9 ='{$_REQUEST['input']}'  ";
        $query = $database->query($sql);
        $row = $database->fetch_array($query);
        if ($row['hhm'] != '') {
            echo " Amazina: {$row['hhm']}; Icyiciro: {$row['category']} \n 0)usubire ahabanza \n 5) Gusohoka";
        } else {
            echo "Nomero y'indangamuntu washyizemo ntabudehe ifite, ongera ugerageze.";
        }
    } else if ($row['input'] == 1) { //processing Ibibazo
        if ($_REQUEST['input'] == 11) {
            header("HTTP/1.1 200 OK");
            header("Server: Apache-Coyote/1.1");
            header("Path=/ekaye/index.php");
            header("Freeflow: FC");
            header("cpRefId: 12345");
            header("Expires: -1");
            header("Pragma: no-cache");
            header("Cache-Control: max-age=0");
            header("Content-Type: UTF-8");
            header("Content-Length: 20");
            $sql = "SELECT Solution  FROM tbl_problems WHERE nic ='{$row['nic']}'  ";
            $query1 = $database->query($sql);
            $row1 = $database->fetch_array($query1);
            if ($row1['Solution'] != '') {
                echo " Igisubizo: {$row1['Solution']} \n 12)ibindi byakivuzweho \n 0)usubire ahabanza \n 5) Gusohoka";
            } else {
                echo "Ikibazo cyawe Ntagisubizo kirabona. \n 0)usubire ahabanza \n 5) Gusohoka";
            }
        } else if ($_REQUEST['input'] == 12) {
            header("HTTP/1.1 200 OK");
            header("Server: Apache-Coyote/1.1");
            header("Path=/ekaye/index.php");
            header("Freeflow: FC");
            header("cpRefId: 12345");
            header("Expires: -1");
            header("Pragma: no-cache");
            header("Cache-Control: max-age=0");
            header("Content-Type: UTF-8");
            header("Content-Length: 20");
            $sql = "SELECT Comment  FROM tbl_problems WHERE nic ='{$row['nic']}'  ";
            $query1 = $database->query($sql);
            $row1 = $database->fetch_array($query1);
            if ($row1['Comment'] != '') {
                echo " Ibindi: {$row1['Comment']} \n 0)usubire ahabanza \n 5) Gusohoka";
            } else {
                echo "Ntabindi byavuzwe kuri ikikibazo. \n 0)usubire ahabanza \n 5) Gusohoka";
            }
        } else {
            header("HTTP/1.1 200 OK");
            header("Server: Apache-Coyote/1.1");
            header("Path=/ekaye/index.php");
            header("Freeflow: FC");
            header("cpRefId: 12345");
            header("Expires: -1");
            header("Pragma: no-cache");
            header("Cache-Control: max-age=0");
            header("Content-Type: UTF-8");
            header("Content-Length: 20");
            $sql = "SELECT statement,Solution  FROM tbl_problems WHERE nic ='{$_REQUEST['input']}'  ";
            $query1 = $database->query($sql);
            $row1 = $database->fetch_array($query1);
            if ($row1['statement'] != '') {
                $sql = "UPDATE  ussd SET nic ='{$_REQUEST['input']}' WHERE id = {$row['id']}";
                $database->query($sql);
                echo " Ikabazo: {$row1['statement']} \n 11)Igisubizo \n 12)ibindi byakivuzweho \n 0)usubire ahabanza \n 4) Gusohoka";
            } else {
                echo "Nomero y'indangamuntu washyizemo ntago iri muri sisiteme yabantu bafite ibibazo. \n 0)usubire ahabanza \n 5) Gusohoka";
            }
        }
    } else if ($row['input'] == 3) { //processing Imihigo
        header("HTTP/1.1 200 OK");
        header("Server: Apache-Coyote/1.1");
        header("Path=/ekaye/index.php");
        header("cpRefId: 12345");
        header("Expires: -1");
        header("Pragma: no-cache");
        header("Cache-Control: max-age=0");
        echo "Iyi service ntibashije kuboneka";
    } else {
        header("HTTP/1.1 200 OK");
        header("Server: Apache-Coyote/1.1");
        header("Path=/ekaye/index.php");
        header("cpRefId: 12345");
        header("Expires: -1");
        header("Pragma: no-cache");
        header("Cache-Control: max-age=0");
        echo "Ibyo ushyizemo ntago byemewe.";
    }
}
?>


