-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: realestate
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `account_category` int(11) DEFAULT NULL,
  `is_online` varchar(60) DEFAULT NULL,
  `deleted` varchar(60) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `profile` int(11) DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  KEY `acc_acc_category_idx` (`account_category`),
  KEY `acc_profile_idx` (`profile`),
  CONSTRAINT `acc_acc_category` FOREIGN KEY (`account_category`) REFERENCES `account_category` (`account_category_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `acc_profile` FOREIGN KEY (`profile`) REFERENCES `profile` (`profile_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (8,'paul@gmail.com','123',1,'yes','no','2017-06-18',16),(17,'jules@gmail.com','123',4,'no','no','2018-01-17',18);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_category`
--

DROP TABLE IF EXISTS `account_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_category` (
  `account_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`account_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_category`
--

LOCK TABLES `account_category` WRITE;
/*!40000 ALTER TABLE `account_category` DISABLE KEYS */;
INSERT INTO `account_category` VALUES (1,'Admin'),(2,'Private user'),(3,'Manager'),(4,'pub user');
/*!40000 ALTER TABLE `account_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basic_apartment`
--

DROP TABLE IF EXISTS `basic_apartment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basic_apartment` (
  `basic_apartment_id` int(11) NOT NULL AUTO_INCREMENT,
  `basic_apartmentdeleted` varchar(60) DEFAULT NULL,
  `listing` int(11) DEFAULT NULL,
  `bedrooms` varchar(60) DEFAULT NULL,
  `bathrooms` int(11) DEFAULT NULL,
  `floor_number` varchar(60) DEFAULT NULL,
  `total_number_floors` int(11) DEFAULT NULL,
  `furnished` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`basic_apartment_id`),
  KEY `BasAprt_listing_idx` (`listing`),
  CONSTRAINT `BasAprt_listing` FOREIGN KEY (`listing`) REFERENCES `listing` (`listing_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basic_apartment`
--

LOCK TABLES `basic_apartment` WRITE;
/*!40000 ALTER TABLE `basic_apartment` DISABLE KEYS */;
/*!40000 ALTER TABLE `basic_apartment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basic_commercial`
--

DROP TABLE IF EXISTS `basic_commercial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basic_commercial` (
  `basic_commercial_id` int(11) NOT NULL AUTO_INCREMENT,
  `basic_commercialdeleted` varchar(60) DEFAULT NULL,
  `listing` int(11) DEFAULT NULL,
  `bedroom` int(11) DEFAULT NULL,
  `bathroom` int(11) DEFAULT NULL,
  `compound_size` int(11) DEFAULT NULL,
  `living_floors` int(11) DEFAULT NULL,
  `total_number_floors` int(11) DEFAULT NULL,
  `furnished` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`basic_commercial_id`),
  KEY `BasicComm_idx` (`listing`),
  CONSTRAINT `BasicComm` FOREIGN KEY (`listing`) REFERENCES `listing` (`listing_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basic_commercial`
--

LOCK TABLES `basic_commercial` WRITE;
/*!40000 ALTER TABLE `basic_commercial` DISABLE KEYS */;
/*!40000 ALTER TABLE `basic_commercial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basic_develop`
--

DROP TABLE IF EXISTS `basic_develop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basic_develop` (
  `basic_develop_id` int(11) NOT NULL AUTO_INCREMENT,
  `basic_developdeleted` varchar(60) DEFAULT NULL,
  `listing` int(11) DEFAULT NULL,
  `bedrooms` int(11) DEFAULT NULL,
  `bathrooms` int(11) DEFAULT NULL,
  `compound_size` int(11) DEFAULT NULL,
  `living_floors` int(11) DEFAULT NULL,
  `total_number_floors` int(11) DEFAULT NULL,
  `furnished` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`basic_develop_id`),
  KEY `BasicDev_idx` (`listing`),
  CONSTRAINT `BasicDev` FOREIGN KEY (`listing`) REFERENCES `listing` (`listing_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basic_develop`
--

LOCK TABLES `basic_develop` WRITE;
/*!40000 ALTER TABLE `basic_develop` DISABLE KEYS */;
/*!40000 ALTER TABLE `basic_develop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basic_house`
--

DROP TABLE IF EXISTS `basic_house`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basic_house` (
  `basic_house_id` int(11) NOT NULL AUTO_INCREMENT,
  `basic_housedeleted` varchar(60) DEFAULT NULL,
  `listing` int(11) DEFAULT NULL,
  `furnished` varchar(60) DEFAULT NULL,
  `available_from` date DEFAULT NULL,
  `bedroom` int(11) DEFAULT NULL,
  `bathroom` int(11) DEFAULT NULL,
  `compound_size` int(11) DEFAULT NULL,
  `living_floors` int(11) DEFAULT NULL,
  `total_number_floors` int(11) DEFAULT NULL,
  PRIMARY KEY (`basic_house_id`),
  KEY `BasicHouse_listing_idx` (`listing`),
  CONSTRAINT `BasicHouse_listing` FOREIGN KEY (`listing`) REFERENCES `listing` (`listing_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basic_house`
--

LOCK TABLES `basic_house` WRITE;
/*!40000 ALTER TABLE `basic_house` DISABLE KEYS */;
/*!40000 ALTER TABLE `basic_house` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basic_land`
--

DROP TABLE IF EXISTS `basic_land`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basic_land` (
  `basic_land_id` int(11) NOT NULL AUTO_INCREMENT,
  `basic_landdeleted` varchar(60) DEFAULT NULL,
  `listing` int(11) DEFAULT NULL,
  `administrative_location` varchar(160) DEFAULT NULL,
  `plot_number` varchar(60) DEFAULT NULL,
  `plot_size` varchar(60) DEFAULT NULL,
  `lot_use` varchar(60) DEFAULT NULL,
  `available_from` date DEFAULT NULL,
  PRIMARY KEY (`basic_land_id`),
  KEY `BasicLand_lising_idx` (`listing`),
  CONSTRAINT `BasicLand_lising` FOREIGN KEY (`listing`) REFERENCES `listing` (`listing_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basic_land`
--

LOCK TABLES `basic_land` WRITE;
/*!40000 ALTER TABLE `basic_land` DISABLE KEYS */;
/*!40000 ALTER TABLE `basic_land` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cell`
--

DROP TABLE IF EXISTS `cell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cell` (
  `cell_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `sector` int(11) DEFAULT NULL,
  PRIMARY KEY (`cell_id`),
  KEY `cell_sector_idx` (`sector`),
  CONSTRAINT `cell_sector` FOREIGN KEY (`sector`) REFERENCES `sector` (`sector_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=676 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cell`
--

LOCK TABLES `cell` WRITE;
/*!40000 ALTER TABLE `cell` DISABLE KEYS */;
INSERT INTO `cell` VALUES (131,'Nyamugari',3863),(132,' Karururma',3863),(133,' Nyamabuye									',3863),(134,'\nMuasve',3864),(135,' Kinyaga',3864),(136,' Nyabikenke',3864),(137,' Ngara',3864),(138,'Mvuzo',3864),(139,'Nkazuzu',3864),(140,'Nyagasozi									',3864),(141,'\nAgateko',3865),(142,' Nyabuliba',3865),(143,' Buhiza',3865),(144,' Nkusi',3865),(145,' Nyakabungo',3865),(146,' Muko',3865),(147,' Nyamitanga									',3865),(148,'\nGicaca',3866),(149,' Kibara',3866),(150,' Murambi',3866),(151,' Munini',3866),(152,' Gasagara									',3866),(153,'\nRuhango',3867),(154,' Musezero									',3867),(155,'\nNgiryi',3868),(156,' Kidashya',3868),(157,' Akamatamu',3868),(158,' Kabuye',3868),(159,' Bweramvura									',3868),(160,'\nKagugu',3869),(161,' Gacuriro',3869),(162,' Murama',3869),(163,' Gasharu									',3869),(164,'\nMasoro',3870),(165,' Mukuyu',3870),(166,' Kibenga',3870),(167,' Rudashya',3870),(168,' Bwiza',3870),(169,' Cyaruzinge									',3870),(170,'\nButare',3871),(171,' Gasanze',3871),(172,' Gasura',3871),(173,' Gatunga',3871),(174,' Muremure',3871),(175,' Sha',3871),(176,' Shango									',3871),(177,'\nKabuga I',3872),(178,' Kabuga II',3872),(179,' Nyagahinga',3872),(180,' Ruhanga',3872),(181,' Kinyana',3872),(182,' Bisenga',3872),(183,' Gasagara',3872),(184,'Mbandazi									',3872),(185,'\nGasabo',3873),(186,' Indatemwa',3873),(187,' Kibenga',3873),(188,' Kabaliza',3873),(189,' Kacyatwa',3873),(190,' Kigabiro									',3873),(191,'\nKamatamu',3874),(192,' Kamutwa',3874),(193,' Kibaza									',3874),(194,'\nKamukina',3875),(195,' Rugando',3875),(196,' Kimihurura									',3875),(197,'\nKibagabaga',3876),(198,' Bibare',3876),(199,' Nyagatovu									',3876),(200,'\nNyarutarama',3877),(201,' Nyabisindu',3877),(202,' Rukiri I',3877),(203,' Rukiri II									',3877),(204,'\nGahanga',3878),(205,' Rwabutenge',3878),(206,' Murinja',3878),(207,' Kagasa',3878),(208,' Nunga',3878),(209,' Karembure									',3878),(210,'\nNyanza',3879),(211,' Gatenga',3879),(212,' Karambo',3879),(213,' Nyarurama									',3879),(214,'\nKANSEREGE ',3880),(215,' Nunga',3880),(216,' Kagunga									',3880),(217,'\nRukatsa',3881),(218,' Muyange',3881),(219,' Kanserege									',3881),(220,'\nBusanza',3882),(221,' Kabeza',3882),(222,' Rubirizi',3882),(223,' Karama									',3882),(224,'\nKicukiro',3883),(225,' Ngoma',3883),(226,' Gasharu',3883),(227,' Kagina									',3883),(228,'\nRwampara',3884),(229,' Kigarama',3884),(230,' Nyarurama',3884),(231,' Karugira',3884),(232,' Bwerankori									',3884),(233,'\nGako',3885),(234,' Ayabaraya',3885),(235,' Gitaraga',3885),(236,' Rusheshe',3885),(237,' Mbabe',3885),(238,' Cyimo									',3885),(239,'\nGatare',3886),(240,' Niboye',3886),(241,' Nyakabanda									',3886),(242,'\nKamashashi',3887),(243,' Rwimbogo',3887),(244,' Nonko									',3887),(245,'\nKora',3888),(246,' Kinyange',3888),(247,' Akabeza',3888),(248,' Akabahizi',3888),(249,' Kigarama',3888),(250,' Gacyamo									',3888),(251,'\nNyamweru',3889),(252,' Nzove',3889),(253,' Taba									',3889),(254,'\nNyabugogo',3890),(255,' Ruliba',3890),(256,' igali',3890),(257,' Rwesero',3890),(258,' Mwendo									',3890),(259,'\nKatabaro',3891),(260,' kimisagara',3891),(261,' Kamuhoza									',3891),(262,'\nNtungamo',3892),(263,' Kankuba',3892),(264,' Kavumu',3892),(265,' Nyarufunzo',3892),(266,' Runzenze',3892),(267,' Mataba ',3892),(268,' Nyarurenzi									',3892),(269,'\nKabasengerezi',3893),(270,' Amahoro',3893),(271,' Tetero',3893),(272,' Ubumwe',3893),(273,' kabeza',3893),(274,' Nyabugogo',3893),(275,' Rugenge									',3893),(276,'\nNyakabanda I',3894),(277,' Munanira I',3894),(278,' Munanira II',3894),(279,' Nyakabanda II									',3894),(280,'\nMumena',3895),(281,' Gasharu',3895),(282,' Cyivugiza',3895),(283,' Rugarama									',3895),(284,'\nAgatare',3896),(285,' Kiyovu',3896),(286,' Biryogo',3896),(287,' Rwampara									',3896),(288,'\nRwezamenyo II',3897),(289,' Rwezamenyo I',3897),(290,' KabuguruII',3897),(291,' KabuguruI									',3897),(292,'\nBUNGWE',3898),(293,' TUMBA ',3898),(294,' MUDUGALI',3898),(295,' BUSHENYA 									',3898),(296,'\nRUSUMO ',3899),(297,' NYAMICUCU ',3899),(298,' MUHOTORA ',3899),(299,' GATSIBO',3899),(300,' MUBUGA',3899),(301,' 									',3863),(302,'\nKAGITEGA ',3900),(303,' KAMANYANA',3900),(304,' KABYINIRO',3900),(305,' NYAGAHINGA ',3900),(306,' GASIZA ',3900),(307,' GISOVU									',3900),(308,'\nBUTARE ',3901),(309,' RUYANGE ',3901),(310,' NDONGOZI 									',3901),(311,'\nKIDAKAMA ',3902),(312,' GISIZI ',3902),(313,' NYANGWE ',3902),(314,' BURAMBA ',3902),(315,' RWASA 									',3902),(316,'\nRWASA ',3903),(317,' MUSENDA ',3903),(318,' GABIRO ',3903),(319,' RWAMBOGO 									',3903),(320,'\nMARIBA ',3904),(321,' MUSASA ',3904),(322,' RUNOGA ',3904),(323,' RUNOGA 									',3904),(324,'\nKABAYA ',3905),(325,' KIRINGA ',3905),(326,' KAYEZI ',3905),(327,' NYAMABUYE 									',3905),(328,'\nGAFUKA ',3906),(329,' NKENKE ',3906),(330,' NKUMBA ',3906),(331,' NTARUKA 									',3906),(332,'\nBUGAMBA ',3907),(333,' RUTOVU ',3907),(334,' KAGANDA ',3907),(335,' MUSASA 									',3907),(336,'\nBUKWASHULI ',3908),(337,' GASHANJE ',3908),(338,' MURWA ',3908),(339,'NYIRATABA 									',3908),(340,'\nNYAMUGALI ',3909),(341,' KIVUMU ',3909),(342,' RUSHARA ',3909),(343,' RUBONA 									',3909),(344,'\nCYAHI ',3910),(345,' GAFUMBA ',3910),(346,' KARANGARA ',3910),(347,' RUREMBO 									',3910),(348,'\nNYANAMO ',3911),(349,' MUCACA ',3911),(350,' RUKANDABYUMA ',3911),(351,' KIRIBATA 									',3911),(352,'\nGITOVU ',3912),(353,' GASEKE ',3912),(354,' RUSEKERA ',3912),(355,' GATARE 									',3912),(356,'\nNDAGO ',3913),(357,' RUHANGA ',3913),(358,' KABONA       									',3913),(359,'\nGACUNDURA ',3914),(360,' GASHORO ',3914),(361,' RUCONSHO ',3914),(362,' RUGARI 									',3914),(363,'\nKamina',3915),(364,' Butereri',3915),(365,' Birambo',3915),(366,' Mwumba ',3915),(367,' Byibuhiro',3915),(368,' Ruhanga',3915),(369,' Kirabo									',3915),(370,'\nNyanza',3916),(371,' Kiruku',3916),(372,' Nyange',3916),(373,' Mbirima									',3916),(374,'\nMuhaza',3917),(375,' Muhororo',3917),(376,' Muramba',3917),(377,' Mutanda',3917),(378,' Mukore									',3917),(379,'\nKagoma',3918),(380,' Nganzo',3918),(381,' Buheta									',3918),(382,'\nTaba',3919),(383,' Nyakina',3919),(384,' Rukura',3919),(385,' Rutabo',3919),(386,' Rutenderi									',3919),(387,'\nGahinga',3920),(388,' Mutego',3920),(389,' Munyana',3920),(390,' Nkomane',3920),(391,' Rutabo',3920),(392,' Rutenderi',3920),(393,' Rwamambe									',3920),(394,'\nGakindo',3921),(395,' Gashyamba ',3921),(396,' Gatwa',3921),(397,' karukungu									',3921),(398,'\nKamubuga',3863),(399,' Kidomo',3922),(400,' Mbatabata',3922),(401,' Rukore									',3922),(402,'\nKanyanza',3923),(403,' Karambo',3923),(404,' Kirebe									',3923),(405,'\nGasiza',3924),(406,' Sereri',3924),(407,' Rugimbu',3924),(408,' Cyintare',3924),(409,' Ruhinga									',3924),(410,'\nBuyange',3925),(411,' Gikombe',3925),(412,' Nyundo									',3925),(413,'\nGasiho',3926),(414,' Raba',3926),(415,' Munyana',3926),(416,' Murambi									',3926),(417,'\nBusake',3927),(418,' Bwenda',3927),(419,' Gasiza',3927),(420,' Gihinga',3927),(421,' Huro									',3927),(422,'\nBumba',3928),(423,' Gisiza',3928),(424,' Karyango',3928),(425,' Nganzo',3928),(426,' Va									',3928),(427,'\nKabatezi',3929),(428,'Kiryamo',3929),(429,' Mubuga',3929),(430,' Mwiyando',3929),(431,' Rwa									',3929),(432,'\nGisozi',3930),(433,' Mucaca',3930),(434,' Buranga',3930),(435,' gahinga									',3930),(436,'\nRuli',3931),(437,' Jango',3931),(438,' Busoro',3931),(439,' Gikingo',3931),(440,' Rwesero									',3931),(441,'\nRumbi',3932),(442,' Murambi',3932),(443,' Kamonyi',3932),(444,' Nyundo',3932),(445,' Gataba',3932),(446,' Rurembo									',3932),(447,'\nJoma',3933),(448,' Razi',3933),(449,' Rwankuba',3933),(450,' Mbogo',3933),(451,' Shyombwe',3933),(452,' Bulimba',3933),(453,' Busanane',3933),(454,' Kageyo 									',3933),(455,'Kivumbu',3934),(457,'\n3',3936),(458,'\n4',3937),(459,'\n5',3938),(460,'\n6',3939),(461,'\n7',3940),(462,'\n8',3941),(463,'\n9',3942),(464,'\n10',3943),(465,'\n11',3944),(466,'\n12',3945),(467,'\n13',3946),(468,'\n14',3947),(469,'\n15',3948),(470,'\n16',3949),(471,'\n17',3950),(472,'\nGisesero',3951),(473,' Sahara',3951),(474,' Kavumu',3951),(475,' Nyagisozi									',3951),(476,'\nRwebeya',3952),(477,' Migeshi',3952),(478,' Buruba',3952),(479,' Cyanya',3952),(480,' Bukinanyana',3952),(481,' Kabeza									',3952),(482,'\nGakoro',3953),(483,' Gasakuza',3953),(484,' Karwasa',3953),(485,' Kabirizi									',3954),(486,'\nMuharuro',3954),(487,' kavumu',3954),(488,' Kigabiro',3954),(489,' Mbwe									',3954),(490,'\nRubindi',3955),(491,' Murago',3955),(492,' Mudakama',3955),(493,' Rungu									',3955),(494,'\nKivumu',3956),(495,' Birira',3956),(496,' Buramira',3956),(497,' Mbizi									',3956),(498,'\nNyabigoma',3957),(499,' Kaguhu',3957),(500,' Bisoke',3957),(501,' Kampanga',3957),(502,' Nyonirima									',3957),(503,'\nMpenge',3958),(504,' Cyabararika',3958),(505,' Kigombe',3958),(506,' Ruhengeri									',3958),(507,'\nMburabuturo',3959),(508,' Cyivugiza',3959),(509,' Songa',3959),(510,' cyago									',3959),(511,'\nCyabazungu',3960),(512,' Nyarubuye',3960),(513,' Rwambogo',3960),(514,' Garuka',3960),(515,' Cyabagarura									',3960),(516,'\nBikara',3961),(517,' Ruyumba',3961),(518,' Mubago',3961),(519,' Rugeshi',3961),(520,' Gashinga									',3961),(521,'\nNinda',3962),(522,' Kamwumba',3962),(523,' Cyivugiza',3962),(524,' Muhabura',3962),(525,'Kabeza									',3962),(526,'\nMurwa',3963),(527,' Rurambo',3963),(528,' Kamisave',3963),(529,' Murandi',3963),(530,' Gasongero									',3963),(531,'\nKabushinge',3964),(532,' Nturo',3964),(533,' Bumara',3964),(534,' Musezero',3964),(535,' Nyarubuye									',3964),(536,'\nGakingo',3965),(537,' Kibuguzo',3965),(538,' Mudende',3965),(539,' Mugari									',3965),(540,'\nCYOHOHA',3966),(541,' RWAMAHWA',3966),(542,' GITARE									',3966),(543,'\nKARENGELI',3967),(544,' TABA',3967),(545,' BUTANGAMPUNDU									',3967),(546,'\nMUKOTO',3863),(547,' N.NGARAMA',3863),(548,' GIKO',3863),(549,' KAYENZI',3863),(550,' GASIZA									',3863),(551,'\nMWUMBA',3969),(552,' GAHORORO',3969),(553,' KARAMA',3969),(554,' BUSORO',3969),(555,' BUTARE',3969),(556,' GITUMBA',3969),(557,' NDARAGE									',3969),(558,'\nBUDAKIRANYA',3970),(559,' RUDOGO',3970),(560,' MIGENDEZO									',3970),(561,'\nBUREHE',3971),(562,' MAREMBO',3971),(563,' RWILI									',3971),(564,'\nBUTUNZI',3972),(565,' REBERO',3972),(566,' MAREMBO',3972),(567,' KAREGAMAZI									',3972),(568,'\nKAMUSHENYI',3973),(569,' SAYO',3973),(570,' KIGARAMA',3973),(571,' GITATSA',3973),(572,' MUBUGA',3973),(573,' MURAMA									',3973),(574,'\nKABUGA',3974),(575,' SHENGAMPURI',3974),(576,' KIVUGIZA',3974),(577,' KIGARAMA',3974),(578,' NYAMYUMBA									',3974),(579,'\nNGIRAMAZI',3975),(580,' MUSHALI',3975),(581,' RURENGE',3975),(582,' BUKORO									',3975),(583,'\nMVUZO',3976),(584,' MUGAMBAZI',3976),(585,' GATWA',3976),(586,' BUBANGU									',3976),(587,'\nKABUGA',3977),(588,' KARAMBO',3977),(589,' MUGOTE',3977),(590,' MUNYARWANDA',3977),(591,' 									',3863),(592,'\nKIYANZA',3978),(593,' KAJEVUBA',3978),(594,' MAHAZA									',3978),(595,'\nMBUYE',3979),(596,' MBERUKA',3979),(597,' BWIMO',3979),(598,' BURARO									',3979),(599,'\nKIRENGE',3980),(600,' TABA',3980),(601,' GAKO									',3980),(602,'\nRUTONDE',3981),(603,' BUGARAGARA',3981),(604,' KIJABAGWE',3981),(605,' MUVUMU',3981),(606,' RUBONA									',3981),(607,'\nMISEZERO',3982),(608,' NYIRABIRORI',3982),(609,' NYIRABIRORI',3982),(610,' BARARI',3982),(611,' TABA',3982),(612,' GAHABWA									',3982),(613,'\ncyili',3983),(614,' mbogo',3983),(615,' gikonko',3983),(616,' Gasagara									',3983),(617,'\ngabiro',3984),(618,' nyakibungo',3984),(619,' nyabitare',3984),(620,' nyebanzi									',3984),(621,'\nbwiza',3985),(622,' akaboti',3985),(623,' Sabusaro',3985),(624,' Umunini									',3985),(625,'\nmuyira',3986),(626,' kibirizi',3986),(627,' Ruturo',3986),(628,' duwani',3986),(629,'									',3863),(630,'\nagahabwa',3987),(631,' gatovu',3987),(632,' impinga',3987),(633,' rubona ',3987),(634,' nyabikenke',3987),(635,'rusaga',3987),(636,' 									',3863),(637,'\ngakoma',3988),(638,'  kabumbwe',3988),(639,' mamba',3988),(640,'muyaga',3988),(641,' ramba									',3988),(642,'\nmuganza',3989),(643,' rwamiko',3989),(644,' saga',3989),(645,' cyumba',3989),(646,' remera									',3989),(647,'\nKibu',3990),(648,' baziro',3990),(649,' kibayi',3990),(650,' mukomacara',3990),(651,' mugombwa									',3990),(652,'\nnyabisagara',3991),(653,' mukiza',3991),(654,' gitega',3991),(655,' runyinya									',3991),(656,'\nkigarama',3992),(657,' bukinanyana',3992),(658,' kimana',3992),(659,' gatovu									',3992),(660,'\ngisagara',3993),(661,' dahwe',3993),(662,' bweya',3993),(663,' mukande',3993),(664,' cyamukuza									',3993),(665,'\nHigiro',3994),(666,' umubanga',3994),(667,' nyamugari',3994),(668,' nyaruteja									',3994),(669,'\nrwaza',3995),(670,' shyamba',3995),(671,' gatoki',3995),(672,' zivu',3995),(673,' munazi',3995),(674,'Kigabiro',3934),(675,'Kirenge',3934);
/*!40000 ALTER TABLE `cell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `commentdeleted` varchar(60) DEFAULT NULL,
  `message` varchar(60) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `listing` int(11) DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `comment_listing_idx` (`listing`),
  CONSTRAINT `comment_listing` FOREIGN KEY (`listing`) REFERENCES `listing` (`listing_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_replies`
--

DROP TABLE IF EXISTS `comment_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment_replies` (
  `comment_replies_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_repliesdeleted` varchar(60) DEFAULT NULL,
  `message` varchar(60) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `comment` int(11) DEFAULT NULL,
  PRIMARY KEY (`comment_replies_id`),
  KEY `commReply_comm_idx` (`comment`),
  CONSTRAINT `comm_REply_comm` FOREIGN KEY (`comment`) REFERENCES `comment` (`comment_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_replies`
--

LOCK TABLES `comment_replies` WRITE;
/*!40000 ALTER TABLE `comment_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_conversion`
--

DROP TABLE IF EXISTS `currency_conversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency_conversion` (
  `currency_conversion_id` int(11) NOT NULL AUTO_INCREMENT,
  `currency_conversiondeleted` varchar(60) DEFAULT NULL,
  `from` varchar(60) DEFAULT NULL,
  `to` varchar(60) DEFAULT NULL,
  `rate` int(11) DEFAULT NULL,
  PRIMARY KEY (`currency_conversion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_conversion`
--

LOCK TABLES `currency_conversion` WRITE;
/*!40000 ALTER TABLE `currency_conversion` DISABLE KEYS */;
INSERT INTO `currency_conversion` VALUES (1,'no','USD','RWF',850),(2,'NO','RWF','USD',850),(3,'no','Shs','Rwf',4),(4,'no','Euro','Rwf',950),(5,NULL,'Rwf','Euro',950);
/*!40000 ALTER TABLE `currency_conversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `district`
--

DROP TABLE IF EXISTS `district`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `district` (
  `district_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `province` int(11) DEFAULT NULL,
  PRIMARY KEY (`district_id`),
  KEY `distr_prov_idx` (`province`),
  CONSTRAINT `distr_prov` FOREIGN KEY (`province`) REFERENCES `province` (`province_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `district`
--

LOCK TABLES `district` WRITE;
/*!40000 ALTER TABLE `district` DISABLE KEYS */;
INSERT INTO `district` VALUES (1,'Nyarugenge',8),(3,'Musanze',9),(4,'Kucukiro',8),(5,'Gasabo',8),(6,'Gatsibo',11),(7,'Nyagatare',11),(8,'Ngoma',11),(9,'Kirehe',11),(10,'Bugesera',11),(11,'Kayonza',11),(12,'Nyabihu',12),(13,'Ngororero',12),(14,'Rusizi',12),(15,'Nyamasheke',12),(16,'Rubavu',12),(17,'Rulindo',9),(18,'Gakenke',9),(19,'Burera',9),(20,'Gicumbi',9),(21,'Nyanza',10),(22,'Ruhango',10),(23,'Huye',10),(24,'Gisagara',10),(25,'Kamonyi',10),(26,'sd',9),(27,'Muhanga',10),(28,'Rutsiro',12);
/*!40000 ALTER TABLE `district` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `features`
--

DROP TABLE IF EXISTS `features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `features` (
  `features_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `property_type` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  PRIMARY KEY (`features_id`),
  KEY `feat_featCat_idx` (`category`),
  CONSTRAINT `feat_featCat` FOREIGN KEY (`category`) REFERENCES `features_cat` (`features_cat_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `features`
--

LOCK TABLES `features` WRITE;
/*!40000 ALTER TABLE `features` DISABLE KEYS */;
INSERT INTO `features` VALUES (1,'It has access to asphalt road',10,8),(2,'It has access to stone road',10,8),(4,'Along side High class residential building',10,9),(5,'Alongside shanty town',10,9),(6,'Alongside developing area',10,9),(7,'Along upcoming upcoming area',10,9),(8,'City view',10,10),(9,'Waterfall',10,10),(10,'Water view',10,10),(11,'River view',10,10),(12,'Hill / mountain view',10,10),(13,'Washing machine',10,11),(14,'Dish washer',10,11),(15,'Built-in wardrobes',10,11),(16,'Solar panels',10,11),(17,'Generator',10,11),(18,'Solar Hot water',10,11),(19,'Water tank',10,11),(20,'It has access to asphalt road',9,8),(21,'It has access to stone road',9,8),(22,'It has access to unpaved road',9,8),(23,'Alongside High class residential',9,9),(24,'alongside shanty town',9,9),(25,'alongside developping area',9,9),(26,'Alongside upcoming developing area',9,10),(27,'City view',9,10),(28,'Water front',9,10),(29,'Water view',9,10),(30,'River view',9,10),(31,'Hill/Mountain view',9,10),(32,'Washing machine',9,13),(33,'Dish washer',9,13),(34,'built-in_wardrobes',9,13),(35,'Solar panels',9,13),(36,'Generator',9,13),(37,'Solar hot water',9,13),(38,'Water tank',9,13),(39,'Lift',9,13),(40,'Gym',9,13),(41,'Swimming pool',9,13),(42,'Internet available',9,13),(43,'Pay TV',9,13),(44,'Pets allowed',9,13),(45,'Disability feature',9,13),(46,'Ducted vacuum system',9,13),(47,'Broad band',9,13),(48,'Fire place',9,13),(49,'Air conditionning',9,13),(50,'heating system',9,13),(51,'Cooling system',9,13),(52,'Grey water system',9,13),(53,'It has access to asphalt road',8,8),(54,'It has access to stone road',8,8),(55,'It has access to unpaved road',8,8),(56,'Alongside High class residential',8,9),(57,'alongside shanty town',8,9),(58,'alongside developping area',8,9),(59,'Alongside upcoming developing area',8,9),(60,'alongside developping area',8,9),(61,'City view',8,10),(62,'Water front',8,10),(63,'Water view',8,10),(64,'Fully fenced',9,14),(65,'Alarm system',9,14),(66,'Intercom',9,14),(67,'Garage',9,14),(68,'Open car',9,14),(69,'spaces',9,14),(70,'Remote garage',9,14),(71,'Covered parking',9,14),(72,'Balcony',9,14),(73,'Deck',9,14),(74,'Courtyard',9,14),(75,'Entertaining area',9,14),(76,'Tennis court',9,14),(77,'It has access to asphalt road',11,8),(78,'It has access to stone road',11,8),(79,'It has access to unpaved road',11,8),(80,'Alongside High class residential buildings',11,9),(81,'alongside shanty town',11,9),(82,'Alongside upcoming developing area',11,9),(83,'alongside developing area',11,9),(84,'City view',11,10);
/*!40000 ALTER TABLE `features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `features_cat`
--

DROP TABLE IF EXISTS `features_cat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `features_cat` (
  `features_cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `features_catdeleted` varchar(60) DEFAULT NULL,
  `cat_name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`features_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `features_cat`
--

LOCK TABLES `features_cat` WRITE;
/*!40000 ALTER TABLE `features_cat` DISABLE KEYS */;
INSERT INTO `features_cat` VALUES (8,'no','Accessibility'),(9,'no','Neighborhood'),(10,'no','View'),(11,'no','Appliances'),(12,'no','Extra'),(13,'no','Appliances & extra'),(14,'no','Other features');
/*!40000 ALTER TABLE `features_cat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(160) DEFAULT NULL,
  `listing` int(11) DEFAULT NULL,
  `deleted` varchar(60) DEFAULT NULL,
  `appear` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`image_id`),
  KEY `list_image_idx` (`listing`),
  CONSTRAINT `list_image` FOREIGN KEY (`listing`) REFERENCES `listing` (`listing_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=419 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listing`
--

DROP TABLE IF EXISTS `listing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `listing` (
  `listing_id` int(11) NOT NULL AUTO_INCREMENT,
  `listing_date` date DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `listing_type` int(11) DEFAULT NULL,
  `property` int(11) DEFAULT NULL,
  `title` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `description` longtext CHARACTER SET utf8,
  `purpose` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `property_category` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `location` int(11) DEFAULT NULL,
  PRIMARY KEY (`listing_id`),
  KEY `list_type_listing_idx` (`listing_type`),
  CONSTRAINT `list_type_listing` FOREIGN KEY (`listing_type`) REFERENCES `listing_type` (`listing_type_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listing`
--

LOCK TABLES `listing` WRITE;
/*!40000 ALTER TABLE `listing` DISABLE KEYS */;
/*!40000 ALTER TABLE `listing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listing_features`
--

DROP TABLE IF EXISTS `listing_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `listing_features` (
  `listing_features_id` int(11) NOT NULL AUTO_INCREMENT,
  `listing` int(11) DEFAULT NULL,
  `features` int(11) DEFAULT NULL,
  PRIMARY KEY (`listing_features_id`),
  KEY `ListFeat_listing_idx` (`listing`),
  KEY `ListFeat_feat_idx` (`features`),
  CONSTRAINT `ListFeat_feat` FOREIGN KEY (`features`) REFERENCES `features` (`features_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `ListFeat_listing` FOREIGN KEY (`listing`) REFERENCES `listing` (`listing_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=543 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listing_features`
--

LOCK TABLES `listing_features` WRITE;
/*!40000 ALTER TABLE `listing_features` DISABLE KEYS */;
/*!40000 ALTER TABLE `listing_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listing_type`
--

DROP TABLE IF EXISTS `listing_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `listing_type` (
  `listing_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`listing_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listing_type`
--

LOCK TABLES `listing_type` WRITE;
/*!40000 ALTER TABLE `listing_type` DISABLE KEYS */;
INSERT INTO `listing_type` VALUES (1,'Property for rent'),(2,'Property for sale');
/*!40000 ALTER TABLE `listing_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `appear` varchar(60) DEFAULT NULL,
  `property` int(11) DEFAULT NULL,
  `cell` int(11) DEFAULT NULL,
  `lat` varchar(60) DEFAULT NULL,
  `longtd` varchar(60) DEFAULT NULL,
  `area` varchar(60) DEFAULT NULL,
  `address` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=281 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (16,'yes',NULL,1,'','','Nyamirambo','kg st 233'),(17,'yes',NULL,1,'','','Nyamirambo','kg st 24'),(18,'yes',NULL,4,'','','Nyarutarama','kg av 35'),(19,'yes',NULL,1,'','','Kagarama','kg st 211'),(20,'yes',NULL,4,'','','Kagarama','kg av 35'),(21,'yes',NULL,1,'','','Akazu kamazi','kg av 73'),(22,'yes',NULL,1,'','','Biryogo','kg av 73'),(23,'yes',NULL,4,'-1.9781455394534826','30.105514186508117','Nyamirambo','kg Av 322'),(24,'yes',NULL,4,'','','Kagarama','kg av 560'),(25,'yes',NULL,1,'','','Akazu kamazi','kg av 522'),(26,'yes',NULL,1,'','','juru','Kg av 56'),(27,'yes',NULL,1,'','','Nyamirambo','KG AV 21'),(28,'yes',NULL,4,'','','Nyamirambo','Kg av 451'),(29,'yes',NULL,1,'','','Akazu kamazi','Kg av 453'),(30,'yes',NULL,1,'','','Akazu kamazi','Kg av 51'),(31,'yes',NULL,4,'','','Nyamirambo','Kg av 48'),(32,'yes',NULL,1,'','','Biryogo','Kg Av 434'),(33,'yes',NULL,4,'','','Kabesenerezi','Kg Av 411'),(34,'yes',NULL,1,'','','Kabesengerezi','Kg Av 415'),(35,'yes',NULL,1,'','','Kabesenerezi','Kg Av 411'),(36,'yes',NULL,1,'','','Kagarama','Kg Av 211'),(37,'yes',NULL,1,'','','Nyamirambo','Kg av 890'),(38,'yes',NULL,4,'','','Nyamirambo','Kv av 390'),(39,'yes',NULL,1,'','','Kabesenerezi','Kv av 395'),(40,'yes',NULL,1,'','','Nyamirambo','Kv av 301'),(41,'yes',NULL,1,'','','Kabesengerezi','kg av 233'),(42,'yes',NULL,1,'','','Muhima','kg av 233'),(43,'yes',NULL,4,'','','Muhima','kg av 232'),(44,'yes',NULL,1,'','','Muhima','kg av 232'),(45,'yes',NULL,4,'','','Muhima','kg av 232'),(46,'yes',NULL,1,'','','Muhima','kg av 232'),(47,'yes',NULL,1,'','','Muhima','kg av 232'),(48,'yes',NULL,4,'','','Muhima','kg av 231'),(49,'yes',NULL,1,'','','Muhima','kg av 231'),(50,'yes',NULL,1,'','','Muhima','kg av 231'),(51,'yes',NULL,1,'','','Muhima','kg av 231'),(52,'yes',NULL,4,'','','Nyamirambo','kg av 232'),(53,'yes',NULL,1,'','','Muhima','kg av 231'),(54,'yes',NULL,1,'','','Muhima','kg av 231'),(55,'yes',NULL,4,'-1.942914','','Nyamirambo','KN2Av4'),(56,'yes',NULL,1,'','','Kabesenerezi','KN2Av4'),(57,'yes',NULL,4,'','','Nyamirambo','KN2Av4'),(58,'yes',NULL,1,'','','Nyamirambo','KN2Av4'),(59,'yes',NULL,1,'','','Nyamirambo','KN2Av4'),(60,'yes',NULL,1,'-1.97755726161318','30.104091693115265','Nyarutarama','asdf'),(61,'yes',NULL,1,'-1.977417869806931','30.10520749206546','Kabesengerezi','asdf'),(62,'yes',NULL,1,'','','Nyarutarama','asdf'),(63,'yes',NULL,1,'','','Nyarutarama','dsfsfd'),(64,'yes',NULL,4,'','','Kimisange','Kg av 670'),(65,'yes',NULL,1,'','','Muhima','dsfsddfdf dsaf'),(66,'yes',NULL,1,'','','Kabesengerezi','dsfsddfdf dsaf'),(67,'yes',NULL,1,'','','Nyamirambo','sadfads'),(68,'yes',NULL,1,'-1.9693776805527472','30.105748446835378','Kibagabaga','kg av 450'),(69,'yes',NULL,1,'','','ASDKLFF;F','JDSFKASDF'),(70,'yes',NULL,1,'','','Biryogo','asdf'),(71,'yes',NULL,1,'','','sdf','asdf'),(72,'yes',NULL,4,'','','sdf','asdf'),(73,'yes',NULL,4,'','','sdf','asdf'),(74,'yes',NULL,1,'','','Kabesengerezi','sdf'),(75,'yes',NULL,1,'','','Kimisange','dsfad'),(76,'yes',NULL,4,'-1.9789933463388858','30.10603069709782','Kagarama','hjgh fggf'),(77,'yes',NULL,1,'','','Kimisange','asdf ghgh'),(78,'yes',NULL,4,'','','Kacyiru','sdf'),(79,'yes',NULL,4,'','','Kacyiru','sdfafas'),(80,'yes',NULL,4,'','','Kacyiru','asdf'),(81,'yes',NULL,1,'','','Kacyiru','asdf'),(82,'yes',NULL,4,'','','Akazu kamazi','kjsdhf'),(83,'yes',NULL,4,'','','Kagarama','asdf'),(84,'yes',NULL,1,'','','Kagarama','sdfasdf'),(85,'yes',NULL,1,'','','Kacyiru','asdf'),(86,'yes',NULL,4,'','','Biryogo','sadf'),(87,'yes',NULL,1,'','','ASDKLFF;F','safds'),(88,'yes',NULL,4,'','','Nyakabanda','kg AV 345'),(89,'yes',NULL,4,'','','Nyakabanda','kg AV 345'),(90,'yes',NULL,4,'','','Kimisange','asdfasdf'),(91,'yes',NULL,1,'','','Nyakabanda','asew'),(92,'yes',NULL,1,'','','Kimisange','asdfdsaf'),(93,'yes',NULL,1,'','','Nyakabanda','kg AV 345'),(94,'yes',NULL,1,'','','Nyakabanda','kg AV 345'),(95,'yes',NULL,4,'','','Nyakabanda','kg AV 345'),(96,'yes',NULL,1,'','','Nyakabanda','kg AV 345'),(97,'yes',NULL,4,'','','Biryogo','adsff'),(98,'yes',NULL,4,'','','Nyakabanda','asdf'),(99,'yes',NULL,2,'','','juru','Kg av 560'),(100,'yes',NULL,1,'','','Nyakabanda','sadfs'),(101,'yes',NULL,1,'','','Kabesengerezi','gh'),(102,'yes',NULL,1,'','','Kibagabaga','ssdf'),(103,'yes',NULL,1,'','','Kabesengerezi','kasjdf'),(104,'yes',NULL,1,'','','Kabesengerezi','hjg'),(105,'yes',NULL,2,'','','Muhima','45'),(106,'yes',NULL,1,'','','Biryogo','kjj'),(107,'yes',NULL,1,'-1.949957109507415','30.067243730163568','Kimisange','kalsdjkjadskfjl adsjfhs dkjfhas dfjkj fsa'),(108,'yes',NULL,1,'','','juru','dfa'),(109,'yes',NULL,1,'','','Muhima','efe'),(110,'yes',NULL,1,'','','Kabesenerezi','sadf'),(111,'yes',NULL,4,'','','juru','sadf'),(112,'yes',NULL,4,'','','Nyakabanda','sdfasd '),(113,'yes',NULL,4,'','','Kabesenerezi','dsfdsaf'),(114,'yes',NULL,4,'-1.9486167810630661','30.065763150787347','Kabesengerezi','dsfdsaf'),(115,'yes',NULL,1,'','','Kabesenerezi','dsfdsaf'),(116,'yes',NULL,1,'','','Nyarutarama','ctu'),(117,'yes',NULL,4,'','','Kabesengerezi','dfdf'),(118,'yes',NULL,4,'','','Muhima','ssd'),(119,'yes',NULL,1,'','','Muhima','ssd'),(120,'yes',NULL,1,'','','Muhima','dfdf'),(121,'yes',NULL,4,'','','Muhima','dfdf'),(122,'yes',NULL,1,'','','Kagarama','kg av 890'),(123,'yes',NULL,1,'','','Kimisange','dfdf'),(124,'yes',NULL,1,'','','Muhima','dfdf'),(125,'yes',NULL,4,'','','Kabesengerezi','sdfsa'),(126,'yes',NULL,1,'','','Kabesengerezi','sdfsd'),(127,'yes',NULL,1,'','','Kabesenerezi','sadf'),(128,'yes',NULL,1,'','','Kabesengerezi','asdf'),(129,'yes',NULL,1,'','','juru','asdf'),(130,'yes',NULL,1,'','','Kimisange','sdf'),(131,'yes',NULL,1,'','','Kimisange','assd sd'),(132,'yes',NULL,4,'','','Nyakabanda','sdf'),(133,'yes',NULL,1,'','','Nyamirambo','Kg av 56 st'),(134,'yes',NULL,4,'','','Nyakabanda','sdf'),(135,'yes',NULL,4,'','','Nyarutarama','asdf'),(136,'yes',NULL,1,'','','Nyakabanda','asdf'),(137,'yes',NULL,1,'','','ASDKLFF;F','dsdf'),(138,'yes',NULL,1,'','','Kacyiru','cbbh'),(139,'yes',NULL,1,'','','juru','skjfkja'),(140,'yes',NULL,1,'','','Biryogo','sdfasfd saf'),(141,'yes',NULL,1,'','','Nyakabanda','sdf'),(142,'yes',NULL,1,'','','Akazu kamazi','asdf asf'),(143,'yes',NULL,1,'','','Biryogo','df'),(144,'yes',NULL,1,'','','Nyarutarama','rt'),(145,'yes',NULL,1,'','','Kimisange','sdfsa'),(146,'yes',NULL,1,'','','Nyarutarama','sfa'),(147,'yes',NULL,1,'','','Kimisange','asdf'),(148,'yes',NULL,1,'','','Kabesenerezi','dsvsf'),(149,'yes',NULL,1,'','','juru','sdfas'),(150,'yes',NULL,4,'','','Nyakabanda','sdf'),(151,'yes',NULL,4,'','','Nyakabanda','sdf'),(152,'yes',NULL,1,'','','Nyamirambo','dgds'),(153,'yes',NULL,1,'','','Kabesengerezi','sdf'),(154,'yes',NULL,1,'','','Nyarutarama','asdfg sdf'),(155,'yes',NULL,1,'-1.941625288800428','30.054955643358653','Nyamirambo',''),(156,'yes',NULL,1,'-1.9409368132839564','30.06155250000006','Nyakabanda','sdf'),(157,'yes',NULL,1,'','','Nyarutarama','h'),(158,'yes',NULL,1,'','','Kabesenerezi','the breeze'),(159,'yes',NULL,1,'','','Nyarutarama','sf'),(160,'yes',NULL,1,'','','Nyarutarama','sd'),(161,'yes',NULL,1,'','','Kabesenerezi','sd'),(162,'yes',NULL,1,'','','Nyarutarama','u'),(163,'yes',NULL,1,'','','Muhima','u'),(164,'yes',NULL,1,'','','Muhima','Kv av 390'),(165,'yes',NULL,1,'','','Muhima','Kv av 2323'),(166,'yes',NULL,1,'','','Kabesengerezi','erer'),(167,'yes',NULL,1,'','','Akazu kamazi','ddf'),(168,'yes',NULL,1,'','','Nyarutarama','ty'),(169,'yes',NULL,1,'-1.9780038273594788','30.104409323240133','Kabesengerezi',''),(170,'yes',NULL,1,'','','Kabesenerezi','asklf'),(171,'yes',NULL,1,'-1.9729831896591787','30.112137946867733','Kabesenerezi','asklf'),(172,'yes',NULL,1,'-1.9729831896591787','','Kabesenerezi','kg av 45 st'),(173,'yes',NULL,1,'-1.9774068538254143','30.1002897408639','Akazu kamazi','kg av 45 st'),(174,'yes',NULL,1,'-1.9783826495511971','','Kabesenerezi','kg av 45 st'),(175,'yes',NULL,1,'-1.9783826495511971','','Kabesenerezi','kg av 48 st'),(176,'yes',NULL,1,'','','ASDKLFF;F',''),(177,'yes',NULL,1,'','','Akazu kamazi',''),(178,'yes',NULL,1,'-1.9487025621154723','30.066782390213006','Kimisange','sdf'),(179,'yes',NULL,1,'-1.9346778824128374','','Nyarutarama','kg av 45 st'),(180,'yes',NULL,1,'','','Biryogo','kg av 48 st'),(181,'yes',NULL,1,'','','juru','sdf'),(182,'yes',NULL,1,'','','Nyakabanda',''),(183,'yes',NULL,1,'-1.977720904234351','30.10564217434387','Biryogo',''),(184,'yes',NULL,1,'-1.968766498001683','30.096264155758718','Muhima',''),(185,'yes',NULL,1,'','','Nyarutarama',''),(186,'yes',NULL,1,'-1.9485846131672974','30.06670728836059','Kibagabaga',''),(187,'yes',NULL,1,'','','ya',''),(188,'yes',NULL,1,'','','Nyarutarama',''),(189,'yes',NULL,1,'-1.9685520479306453','30.10040548647771','Kabesenerezi',''),(190,'yes',NULL,1,'-1.9695492405267914','30.104139121426442','Kabesenerezi',''),(191,'yes',NULL,1,'-1.971018222081146','30.095384391201833','Nyamirambo',''),(192,'yes',NULL,1,'','','Nyarutarama','kg av 27'),(193,'yes',NULL,1,'','','Kagarama',''),(194,'yes',NULL,1,'','','Muhima',''),(195,'yes',NULL,1,'','','Nyarutarama',''),(196,'yes',NULL,1,'','','Biryogo',''),(197,'yes',NULL,1,'','','Muhima',''),(198,'yes',NULL,4,'','','Nyarutarama',''),(199,'yes',NULL,1,'','','Kimisange',''),(200,'yes',NULL,1,'','','Muhima',''),(201,'yes',NULL,4,'','','Muhima',''),(202,'yes',NULL,1,'-1.9490027957644546','30.059315120315545','Nyakabanda',''),(203,'yes',NULL,1,'-1.9406498467992523','30.04817858848571','Nyabugogo',''),(204,'yes',NULL,1,'-1.9591269401000297','30.08494523371587','Nyarutarama',''),(205,'yes',NULL,1,'-1.9484773868436031','30.048918878173822','juru',''),(206,'yes',NULL,4,'-1.9512009333488016','30.05967990074157','Kabesenerezi',''),(207,'yes',NULL,1,'-1.972701651903635','30.103323729885915','Kabesenerezi',''),(208,'yes',NULL,1,'','','Kabesenerezi',''),(209,'yes',NULL,1,'-1.945839617132137','30.055806790924066','la gallette',''),(210,'yes',NULL,4,'-1.9486703942213321','30.06673947486877','kigali','kn 21'),(211,'yes',NULL,1,'','','Kabesenerezi',''),(212,'yes',NULL,1,'','','Kagarama',''),(213,'yes',NULL,1,'','','juru','sdf'),(214,'yes',NULL,1,'','','Kabesenerezi','sadf'),(215,'yes',NULL,4,'','','Kabesenerezi','sadf'),(216,'yes',NULL,5,'','','Kagarama','sdd'),(217,'yes',NULL,1,'','','Muhima','sdf'),(218,'yes',NULL,1,'','','Muhima','sdf'),(219,'yes',NULL,1,'','','Kibagabaga','sdf'),(220,'yes',NULL,1,'','','Kabesengerezi','sdf'),(221,'yes',NULL,1,'','','Kimisange','sadf'),(222,'yes',NULL,1,'','','Nyakabanda','hj'),(223,'yes',NULL,1,'','','Nyarutarama','r'),(224,'yes',NULL,1,'','','Nyarutarama',''),(225,'yes',NULL,4,'','','ny',''),(226,'yes',NULL,1,'','','nyamirambo','kg av 349'),(227,'yes',NULL,1,'','','kimisagara','kg av 456'),(228,'yes',NULL,1,'','','kimisagara','kg av 349'),(229,'yes',NULL,1,'','','kimisagara','kg av 349'),(230,'yes',NULL,211,'','','a,msf','kg av 349'),(231,'yes',NULL,211,'-1.9778311022788297','30.105705916671695','Kasdflk','nya'),(232,'yes',NULL,555,'','','Kasdflk','nya'),(233,'yes',NULL,376,'-1.9737458459307328','30.092284142761173','Kicukiro',''),(234,'yes',NULL,371,'','','asf',''),(235,'yes',NULL,211,'','','asfd',''),(236,'yes',NULL,215,'','','Kacyiru',''),(237,'yes',NULL,252,'','','skjladlf',''),(238,'yes',NULL,566,'','','asdf',''),(239,'yes',NULL,305,'','','asdf',''),(242,NULL,NULL,305,'0','0','Nyarutarama','Kg av 340St'),(243,'yes',NULL,305,'0','0','Nyarutarama','Kg av 340St'),(245,'yes',1,305,'0','0','kimisagara','Kg kim 300N'),(246,'yes',1,305,'0','0','Kagarama','Kg kim 340N'),(247,'yes',1,305,'0','0','Nyakabanda','Kg kim 334N'),(248,'yes',1,305,'0','0','Nyakabanda','kg av450'),(249,'yes',1,305,'0','0','Nyakabanda','kg av450'),(250,'yes',1,305,'0','0','Nyarutarama','kg av34'),(251,'yes',1,305,'0','0','Kabesenerezi','kg av34'),(252,'yes',1,305,'0','0','Nyamirambo','Kg av 340St'),(253,'yes',1,305,'0','0','Nyarutarama','Kg av 450St'),(254,'yes',1,305,'0','0','Biryogo','ASDF'),(255,'yes',1,305,'0','0','Muhima','asdf'),(256,'yes',1,305,'0','0','juru','kg av 56N'),(257,'yes',1,305,'0','0','Kimisange','kg av 340W'),(258,'yes',1,305,'0','0','Nyarutarama','kg av 450St'),(259,'yes',1,305,'0','0','Kabesenerezi','Kg av 4500'),(260,'yes',1,305,'0','0','Nyamirambo','kg av_sd'),(261,'yes',1,305,'-1.9737244009890264','30.092444346466095','Kabesenerezi','Kg av 400St'),(262,'yes',1,305,'0','0','Kimisange','kg av 5600'),(263,'yes',1,305,'0','0','Kagarama','kg av 4500'),(264,'yes',1,305,'0','0','Kabesenerezi','ks av 560'),(265,'yes',1,305,'-1.979450190595253','30.111434386291535','Kagarama','Kg av 450St'),(266,'yes',1,305,'-1.9703897091882545','30.084290431060822','Muhima','asdf'),(267,'yes',1,305,'-1.9737351234599114','30.092669652023346','Nyakabanda','hj'),(268,'yes',1,305,'','','Kutu','Kg av 3000'),(269,'yes',1,305,'','','Nyamirambo','Kg av 450St'),(270,'yes',1,305,'','','Kutu','Kg av 45600'),(271,'yes',1,305,'','','Kagarama','kg av 2300'),(272,'yes',1,305,'','','Nyarutarama','Kg av 4500'),(273,'yes',1,305,'','','Nyamirambo','Kg av 4500k'),(274,'yes',1,305,'','','Nyamirambo','Kg av 4500St'),(275,'yes',1,305,'','','Biryogo','Kg av 340'),(276,'yes',1,305,'','','Kg av 4500','Kg av 200'),(277,'yes',1,305,'','','Akazu kamazi','Kg av 44Rd'),(278,'yes',1,305,'','','Nyarutarama','Kg sd'),(279,'yes',1,305,'','','Kabesenerezi','kg av 4500'),(280,'yes',1,305,'','','Kimisange','sdf');
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price`
--

DROP TABLE IF EXISTS `price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` int(11) DEFAULT NULL,
  `currency` varchar(60) DEFAULT NULL,
  `cond` varchar(60) DEFAULT NULL,
  `property` int(11) DEFAULT NULL,
  `Minimum_advance` varchar(60) DEFAULT NULL,
  `deposit_required` varchar(60) DEFAULT NULL,
  `commission` varchar(60) DEFAULT NULL,
  `utilities_extra` varchar(60) DEFAULT NULL,
  `listing` int(11) DEFAULT NULL,
  `amount_per_day` varchar(45) DEFAULT NULL,
  `price_square_meter_per_day` int(11) DEFAULT NULL,
  `minimum_advance_per_day` varchar(45) DEFAULT NULL,
  `deposit_required_per_day` varchar(45) DEFAULT NULL,
  `commission_per_day` varchar(45) DEFAULT NULL,
  `utilities_extra_per_day` varchar(45) DEFAULT NULL,
  `currency_month` varchar(45) DEFAULT NULL,
  `currency_day` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`price_id`),
  KEY `list_price_idx` (`listing`),
  CONSTRAINT `list_price` FOREIGN KEY (`listing`) REFERENCES `listing` (`listing_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price`
--

LOCK TABLES `price` WRITE;
/*!40000 ALTER TABLE `price` DISABLE KEYS */;
/*!40000 ALTER TABLE `price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_utilities`
--

DROP TABLE IF EXISTS `price_utilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price_utilities` (
  `price_utilities_id` int(11) NOT NULL AUTO_INCREMENT,
  `price_id` int(11) NOT NULL,
  `utilities_id` int(11) NOT NULL,
  PRIMARY KEY (`price_utilities_id`),
  KEY `price_util_idx` (`price_id`),
  KEY `price_utils_utils_idx` (`utilities_id`),
  CONSTRAINT `price_util` FOREIGN KEY (`price_id`) REFERENCES `price` (`price_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `price_utils_utils` FOREIGN KEY (`utilities_id`) REFERENCES `utilities` (`utilities_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=265 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_utilities`
--

LOCK TABLES `price_utilities` WRITE;
/*!40000 ALTER TABLE `price_utilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `price_utilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `home_phone` varchar(60) DEFAULT NULL,
  `office_phone` varchar(60) DEFAULT NULL,
  `mobile_phone` varchar(60) DEFAULT NULL,
  `address` varchar(60) DEFAULT NULL,
  `city` varchar(60) DEFAULT NULL,
  `country` varchar(60) DEFAULT NULL,
  `image` varchar(245) DEFAULT NULL,
  PRIMARY KEY (`profile_id`),
  KEY `prof_image_idx` (`image`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (16,'HIRWA','Fauntaine','hirwa@gmail.com','078875656','0874747','0887757','Kicukiro','Kigali','Armenia','18'),(17,'felicien','bahanuzi','felicien@gmai.com','07888477','078467576','078326637','kigali','kigali','Rwanda','158'),(18,'Jules','HABIMANA','jules@gmail.com','0788','34','34','asf','asdf','Rwanda','189');
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `property`
--

DROP TABLE IF EXISTS `property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `property` (
  `property_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`property_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `property`
--

LOCK TABLES `property` WRITE;
/*!40000 ALTER TABLE `property` DISABLE KEYS */;
INSERT INTO `property` VALUES (8,'House'),(9,'Land');
/*!40000 ALTER TABLE `property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `property_category`
--

DROP TABLE IF EXISTS `property_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `property_category` (
  `property_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `property_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`property_category_id`),
  KEY `propcat_prop_type_idx` (`property_type`),
  CONSTRAINT `propcat_prop_type` FOREIGN KEY (`property_type`) REFERENCES `property_type` (`property_type_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `property_category`
--

LOCK TABLES `property_category` WRITE;
/*!40000 ALTER TABLE `property_category` DISABLE KEYS */;
INSERT INTO `property_category` VALUES (20,'Detached',10),(21,'Semi-detached',10),(22,'Multi-family house',10),(23,'Annexe',10),(25,'Guest House',10),(26,'Lot',11),(27,'Plot',11),(28,'Acreage',11),(29,'Farm',11),(30,'Studio',8),(31,'2 bedroom apartment',8),(32,'3 bedroom apartment',8),(33,'Offices',9),(34,'Retail',9),(35,'Warehouse',9),(37,'Hotel',9),(38,'Showroom',9),(39,'Leisure',9),(40,'Medical',9),(41,'1 bedroom apartment',8),(42,'5 bedroom apartment',8),(43,'single family house',10),(44,'Guest house',8),(46,'Guest house',9),(47,'4 bedroom apartment',8),(48,'Penthouse',8),(49,'Warehouse',10);
/*!40000 ALTER TABLE `property_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `property_request`
--

DROP TABLE IF EXISTS `property_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `property_request` (
  `property_request_id` int(11) NOT NULL AUTO_INCREMENT,
  `property_requestdeleted` varchar(60) DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `names` varchar(60) DEFAULT NULL,
  `telephone` varchar(60) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `listing` int(11) DEFAULT NULL,
  `received` varchar(60) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  PRIMARY KEY (`property_request_id`),
  KEY `propReq_listing_idx` (`listing`),
  CONSTRAINT `propReq_listing` FOREIGN KEY (`listing`) REFERENCES `listing` (`listing_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `property_request`
--

LOCK TABLES `property_request` WRITE;
/*!40000 ALTER TABLE `property_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `property_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `property_type`
--

DROP TABLE IF EXISTS `property_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `property_type` (
  `property_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `property` int(11) DEFAULT NULL,
  PRIMARY KEY (`property_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `property_type`
--

LOCK TABLES `property_type` WRITE;
/*!40000 ALTER TABLE `property_type` DISABLE KEYS */;
INSERT INTO `property_type` VALUES (8,'Apartment',8),(9,'Commercial',8),(10,'House',8),(11,'Land',9),(12,'Development',8);
/*!40000 ALTER TABLE `property_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `property_visitor`
--

DROP TABLE IF EXISTS `property_visitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `property_visitor` (
  `property_visitor_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`property_visitor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `property_visitor`
--

LOCK TABLES `property_visitor` WRITE;
/*!40000 ALTER TABLE `property_visitor` DISABLE KEYS */;
/*!40000 ALTER TABLE `property_visitor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `province`
--

DROP TABLE IF EXISTS `province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `province` (
  `province_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `province`
--

LOCK TABLES `province` WRITE;
/*!40000 ALTER TABLE `province` DISABLE KEYS */;
INSERT INTO `province` VALUES (8,'Kigali'),(9,'North'),(10,'South'),(11,'East'),(12,'WEst');
/*!40000 ALTER TABLE `province` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sector`
--

DROP TABLE IF EXISTS `sector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sector` (
  `sector_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `district` int(11) DEFAULT NULL,
  PRIMARY KEY (`sector_id`),
  KEY `sector_district_idx` (`district`),
  CONSTRAINT `sector_district` FOREIGN KEY (`district`) REFERENCES `district` (`district_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4261 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sector`
--

LOCK TABLES `sector` WRITE;
/*!40000 ALTER TABLE `sector` DISABLE KEYS */;
INSERT INTO `sector` VALUES (3863,'Gatsata',6),(3864,'Bumbogo',6),(3865,'Jali	',6),(3866,'Gikomero',6),(3867,'Gisozi	',6),(3868,'Jabana	',6),(3869,'Kinyinya',6),(3870,'Ndera	',6),(3871,'Nduba	',6),(3872,'Rusororo',6),(3873,'Rutunga',6),(3874,'Kacyiru',6),(3875,'Kimihurura',6),(3876,'Kimironko',6),(3877,'Remera	',6),(3878,' Gahanga',4),(3879,' Gatenga',4),(3880,' Gikondo',4),(3881,' Kagarama',4),(3882,'Kanombe',4),(3883,'Kicukiro',4),(3884,'Kigarama',4),(3885,' Masaka',4),(3886,'Niboye	',4),(3887,'Nyarugunga',4),(3888,'Gitega	',1),(3889,'Kanyinya',1),(3890,'Kigali	',1),(3891,'Kimisagara',1),(3892,' Mageragere',1),(3893,'Muhima	',1),(3894,'Nyakabanda',1),(3895,' Nyamirambo',1),(3896,'Nyarugenge',1),(3897,'Rwezamenyo',1),(3898,'Bungwe	',19),(3899,'Butaro	',19),(3900,' Cyanika',19),(3901,'Cyeru	',19),(3902,' Gahunga',19),(3903,'Gatebe	',19),(3904,' Gitovu',19),(3905,'Kagogo	',19),(3906,'Kinoni	',19),(3907,'Kinyababa',19),(3908,'Kivuye	',19),(3909,' Nemba	',19),(3910,'Rugarama',19),(3911,' Rugendabar',19),(3912,'Ruhunde',19),(3913,'Rusarabuye',19),(3914,'Rwerere',19),(3915,'Busengo',18),(3916,'Coko	',18),(3917,' Cyabingo',18),(3918,'Gakenke',18),(3919,'Gashenyi',18),(3920,'Mugunga',18),(3921,' Janja	',18),(3922,'Kamubuga',18),(3923,'Karambo',18),(3924,'Kivuruga',18),(3925,' Mataba',18),(3926,'Minazi	',18),(3927,'Muhondo',18),(3928,'Muyongwe',18),(3929,'Muzo	',18),(3930,'Nemba	',18),(3931,'Ruli	',18),(3932,' Rusasa',18),(3933,'Rushashi',18),(3934,'Bukure	',20),(3935,'Bwisige',20),(3936,'Bwisige',20),(3937,'Byumba	',20),(3938,'Cyumba	',20),(3939,' Giti	',20),(3940,'Kaniga	',20),(3941,' Manyagiro',20),(3942,'Miyove	',20),(3943,'Kageyo	',20),(3944,' Mukarange',20),(3945,'Muko	',20),(3946,'Mutete	',20),(3947,'Nyamiyaga',20),(3948,'Nyankenke I',20),(3949,'Rubaya	',20),(3950,'Rukomo	',20),(3951,'Busogo	',3),(3952,' Cyuve	',3),(3953,'Gacaca	',3),(3954,'Gashaki',3),(3955,'Gataraga',3),(3956,'Kimonyi',3),(3957,'Kinigi	',3),(3958,'Muhoza	',3),(3959,'Muko	',3),(3960,'Musanze',3),(3961,'Nkotsi	',3),(3962,'Nyange	',3),(3963,'Remera	',3),(3964,'Rwaza	',3),(3965,'Shingiro',3),(3966,' Base	',17),(3967,'Burega	',17),(3968,'Bushoki',17),(3969,'Buyoga	',17),(3970,'Cyinzuzi',17),(3971,'Cyungo	',17),(3972,'Kinihira',17),(3973,'Kisaro	',17),(3974,'Masoro	',17),(3975,'Mbogo	',17),(3976,'Murambi',17),(3977,'Ngoma	',17),(3978,'Ntarabana',17),(3979,'Rukozo	',17),(3980,'Rusiga	',17),(3981,'Shyorongi',17),(3982,'Tumba	',17),(3983,' Gikonko',24),(3984,' Gishubi',24),(3985,'Kansi	',24),(3986,'Kibilizi',24),(3987,'Kigembe',24),(3988,'Mamba	',24),(3989,'Muganza',24),(3990,'Mugombwa',24),(3991,'Mukindo',24),(3992,'Musha	',24),(3993,'Ndora	',24),(3994,'Nyanza	',24),(3995,'Save	',24),(3996,'Gishamvu',5),(3997,'Karama	',5),(3998,'Kigoma	',5),(3999,'Kinazi	',5),(4000,'Maraba	',5),(4001,'Mbazi	',5),(4002,'Mukura	',5),(4003,'Ngoma	',5),(4004,'Ruhashya',5),(4005,'Huye	',5),(4006,'Rusatira',5),(4007,'Rwaniro',5),(4008,'Simbi	',5),(4009,'Tumba	',5),(4010,'Gacurabweng',25),(4011,'Karama	',25),(4012,'Kayenzi',25),(4013,'Kayumbu',25),(4014,'Mugina	',25),(4015,'Musambira',25),(4016,'Ngamba	',25),(4017,'Nyamiyaga',25),(4018,'Nyarubaka',25),(4019,'Rugalika',25),(4020,'Rukoma	',25),(4021,'Runda	',25),(4022,'Muhanga',27),(4023,'Cyeza	',27),(4024,'Kibangu',27),(4025,'Kiyumba',27),(4026,'Mushishiro',27),(4027,'Kabacuzi',27),(4028,'Nyabinoni',27),(4029,'Nyamabuye',27),(4030,'Nyarusange',27),(4031,'Rongi	',27),(4032,'Rugendabari',27),(4033,'Shyogwe',27),(4034,'Buruhukiro',5),(4035,'Cyanika',5),(4036,'Gatare	',5),(4037,'Kaduha	',5),(4038,'Kamegeli',5),(4039,'Kibirizi',5),(4040,'Kibumbwe',5),(4041,'Kitabi	',5),(4042,'Mbazi	',5),(4043,'Mugano	',5),(4044,'Musange',5),(4045,'Musebeya',5),(4046,'Mushubi',5),(4047,'Nkomane',5),(4048,'Gasaka	',5),(4049,'Tare	',5),(4050,'Uwinkingi',5),(4051,'Busasamana',21),(4052,' Busoro',21),(4053,'Cyabakamyi',21),(4054,'Kibirizi',21),(4055,'Kigoma	',21),(4056,'Mukingo',21),(4057,'Muyira	',21),(4058,'Ntyazo	',21),(4059,'Nyagisozi ',21),(4060,'Rwabicuma',21),(4061,'Cyahinda',5),(4062,'Busanze',5),(4063,'Kibeho	',5),(4064,'Mata	',5),(4065,'Munini	',5),(4066,'Kivu	',5),(4067,'Ngera	',5),(4068,'Ngoma	',5),(4069,'Nyabimata',5),(4070,'Nyagisozi',5),(4071,'Muganza',5),(4072,'Ruheru	',5),(4073,'Ruramba',5),(4074,'Rusenge',5),(4075,'Kinazi ',22),(4076,'Byimana',22),(4077,'Bweramana',22),(4078,'Mbuye	',22),(4079,'Ruhango',22),(4080,'Mwendo	',22),(4081,'Kinihira',22),(4082,'Ntongwe',22),(4083,'Kabagari',22),(4084,'Bwishyura',5),(4085,'Gishyita',5),(4086,'Gishari',5),(4087,'Gitesi	',5),(4088,'Mubuga	',5),(4089,'Murambi',5),(4090,'Murundi',5),(4091,'Mutuntu',5),(4092,'Rubengera',5),(4093,'Rugabano',5),(4094,'Ruganda',5),(4095,'Rwankuba',5),(4096,'Twumba	',5),(4097,'Bwira	',13),(4098,'Gatumba',13),(4099,' Hindiro',13),(4100,'Kabaya	',13),(4101,'Kageyo	',13),(4102,'Kavumu	',13),(4103,'Matyazo',13),(4104,' Muhanda',13),(4105,'Muhororo',13),(4106,'Ndaro	',13),(4107,'Ngororero',13),(4108,'Nyange	',13),(4109,'Sovu	',13),(4110,'Bigogwe',12),(4111,'Jenda	',12),(4112,'Jomba	',12),(4113,'Kabatwa',12),(4114,'Karago	',12),(4115,'Kintobo',12),(4116,'Mukamira',12),(4117,'Muringa',12),(4118,'Rambura',12),(4119,'Rugera	',12),(4120,'Rurembo',12),(4121,'Shyira	',12),(4122,'Ruharambuga',15),(4123,'Bushekeri',15),(4124,'Bushenge,',15),(4125,'Cyato	',15),(4126,'Gihombo',15),(4127,'Kagano	',15),(4128,'Kanjongo',15),(4129,'Karambi',15),(4130,'Karengera',15),(4131,'Kirimbi',15),(4132,'Macuba	',15),(4133,'Nyabitekeri',15),(4134,'Mahembe',15),(4135,'Rangiro',15),(4136,'Shangi	',15),(4137,'Bugeshi',16),(4138,'Busasamana',16),(4139,'Cyanzarwe',16),(4140,'Gisenyi',16),(4141,'Kanama	',16),(4142,'Kanzenze',16),(4143,'Mudende',16),(4144,'Nyakiliba',16),(4145,'Nyamyumba',16),(4146,'Nyundo	',16),(4147,'Rubavu	',16),(4148,'Rugerero',16),(4149,'Bugarama',14),(4150,'Butare	',14),(4151,'Bweyeye',14),(4152,'Gikundamvur',14),(4153,'Gashonga',14),(4154,'Giheke	',14),(4155,'Gihundwe',14),(4156,'Gitambi',14),(4157,'Kamembe',14),(4158,'Muganza',14),(4159,'Mururu	',14),(4160,'Nkanka	',14),(4161,'Nkombo	',14),(4162,'Nkungu	',14),(4163,'Nyakabuye',14),(4164,'Nyakarenzo',14),(4165,'Nzahaha',14),(4166,'Rwimbogo',14),(4167,'Boneza	',5),(4168,'Gihango',5),(4169,'Kigeyo	',5),(4170,'Kivumu	',5),(4171,'Manihira',5),(4172,'Murunda',5),(4173,'Musasa	',5),(4174,'Mushonyi',5),(4175,'Mushubati',5),(4176,'Nyabirasi',5),(4177,'Ruhango',5),(4178,'Rusebeya',5),(4179,'MUKURA	',5),(4180,'Gashora',10),(4181,'Juru	',10),(4182,'Kamabuye',10),(4183,'Ntarama',10),(4184,'Mareba	',10),(4185,'Mayange',10),(4186,'Musenyi',10),(4187,'Mwogo	',10),(4188,'Ngeruka',10),(4189,'Nyamata',10),(4190,'Nyarugenge',10),(4191,'Rilima	',10),(4192,'Ruhuha	',10),(4193,'Rweru	',10),(4194,'Shyara	',10),(4195,'Gasange',6),(4196,'Gatsibo',6),(4197,'Gitoki	',6),(4198,'Kabarore',6),(4199,'Kageyo	',6),(4200,'Kiramuruzi',6),(4201,'Kiziguro',6),(4202,'Muhura	',6),(4203,'Murambi',6),(4204,'Ngarama',6),(4205,'Nyagihanga',6),(4206,'Remera	',6),(4207,'Rugarama',6),(4208,'Rwimbogo',6),(4209,'Gahini	',11),(4210,'Kabare	',11),(4211,'Kabarondo',11),(4212,'Mukarange',11),(4213,'Murama	',11),(4214,'Murundi',11),(4215,'Mwiri	',11),(4216,'Ndego	',11),(4217,'Nyamirama',11),(4218,'Rukara	',11),(4219,'Ruramira',11),(4220,' Rwinkwavu',11),(4221,'Gashanda',8),(4222,'Remera	',8),(4223,'Jarama	',8),(4224,'Karembo',8),(4225,'Kazo	',8),(4226,'Kibungo',8),(4227,'Mugesera',8),(4228,'Murama	',8),(4229,'zaza	',8),(4230,'Mutenderi',8),(4231,'Rukira	',8),(4232,'Rukumberi',8),(4233,'Rurenge',8),(4234,'Sake	',8),(4235,'Gatunda',8),(4236,'Kiyombe',8),(4237,'Karama	',8),(4238,'Karangazi',8),(4239,'Katabagemu',8),(4240,'Matimba',8),(4241,'Mimuli	',8),(4242,'Mukama	',8),(4243,'Musheli',8),(4244,'Nyagatare',8),(4245,'Rukomo	',8),(4246,'Rwempasha',8),(4247,'Rwimiyaga',8),(4248,'Tabagwe',8),(4249,'Gahara	',9),(4250,'Gatore	',9),(4251,'Kigarama',9),(4252,'Kigina	',9),(4253,'Kirehe	',9),(4254,'Mahama	',9),(4255,'Mpanga	',9),(4256,'Musaza	',9),(4257,'Mushikiri',9),(4258,'Nasho	',9),(4259,'Nyamugari',9),(4260,'Nyarubuye',9);
/*!40000 ALTER TABLE `sector` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilities`
--

DROP TABLE IF EXISTS `utilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `utilities` (
  `utilities_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`utilities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilities`
--

LOCK TABLES `utilities` WRITE;
/*!40000 ALTER TABLE `utilities` DISABLE KEYS */;
INSERT INTO `utilities` VALUES (1,'electricity'),(2,'water'),(3,'local security and waste collection fees'),(4,'gym'),(5,'swimming pool'),(6,'DSTV');
/*!40000 ALTER TABLE `utilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'realestate'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-27 23:16:11
