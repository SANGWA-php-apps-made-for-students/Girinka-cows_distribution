$(document).ready(function () {
    try {
        get_new_data_hide_show();
        show_form_toUpdate();
        cowdead_del_udpate();
        dlog_btn_No_Yes();
        get_CowDonerID_id_combo();

        get_SectorID_id_combo();
        get_CellID_id_combo();
        get_VillageID_id_combo();
        get_CowID_id_combo();
        get_LastUserID_id_combo();
        get_CowBornID_id_combo();
        get_CitizenID_id_combo();
        get_LastUserID_id_combo();
        get_CowDistributionID_id_combo();
        get_LastUserID_id_combo();
                show_users();
        show_cowdonors();
        show_citizens();
        show_cow_distribution();
        show_cowborn();
        selectable_link_click();
        hide_select_pane();
        user_del_udpate();
        cell_del_udpate();
        cowdonor_del_udpate();
        cowidentification_del_udpate();
        citizenshortlisted_del_udpate();
        sector_del_udpate();
        cowdistribution_del_udpate();
        cowborn_del_udpate();
        newborncowdistribution_del_udpate();
        cowdead_del_udpate();
        get_citizen_Page();
        show_cow_cow_identif();
    } catch (err) {
        alert(err);
    }

});

function get_LastUserID_id_combo() {
    try {
        $('.cbo_LastUserID').change(function () {
            var cbo_LastUserID = $('.cbo_LastUserID option:selected').val();
            $('#txt_LastUserID_id').val(cbo_LastUserID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_CowDonerID_id_combo() {
    try {
        $('.cbo_CowDonerID').change(function () {
            var cbo_CowDonerID = $('.cbo_CowDonerID option:selected').val();
            $('#txt_CowDonerID_id').val(cbo_CowDonerID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_LastUserID_id_combo() {
    try {
        $('.cbo_LastUserID').change(function () {
            var cbo_LastUserID = $('.cbo_LastUserID option:selected').val();
            $('#txt_LastUserID_id').val(cbo_LastUserID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_SectorID_id_combo() {
    try {
        $('.cbo_SectorID').change(function () {
            var cbo_SectorID = $('.cbo_SectorID option:selected').val();
            $('#txt_SectorID_id').val(cbo_SectorID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_CellID_id_combo() {
    try {
        $('.cbo_CellID').change(function () {
            var cbo_CellID = $('.cbo_CellID option:selected').val();
            $('#txt_CellID_id').val(cbo_CellID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_VillageID_id_combo() {
    try {
        $('.cbo_VillageID').change(function () {
            var cbo_VillageID = $('.cbo_VillageID option:selected').val();
            $('#txt_VillageID_id').val(cbo_VillageID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_LastUserID_id_combo() {
    try {
        $('.cbo_LastUserID').change(function () {
            var cbo_LastUserID = $('.cbo_LastUserID option:selected').val();
            $('#txt_LastUserID_id').val(cbo_LastUserID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_CitizenID_id_combo() {
    try {
        $('.cbo_CitizenID').change(function () {
            var cbo_CitizenID = $('.cbo_CitizenID option:selected').val();
            $('#txt_CitizenID_id').val(cbo_CitizenID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_CowID_id_combo() {
    try {
        $('.cbo_CowID').change(function () {
            var cbo_CowID = $('.cbo_CowID option:selected').val();
            $('#txt_CowID_id').val(cbo_CowID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_LastUserID_id_combo() {
    try {
        $('.cbo_LastUserID').change(function () {
            var cbo_LastUserID = $('.cbo_LastUserID option:selected').val();
            $('#txt_LastUserID_id').val(cbo_LastUserID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_CowDistributionID_id_combo() {
    try {
        $('.cbo_CowDistributionID').change(function () {
            var cbo_CowDistributionID = $('.cbo_CowDistributionID option:selected').val();
            $('#txt_CowDistributionID_id').val(cbo_CowDistributionID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_LastUserID_id_combo() {
    try {
        $('.cbo_LastUserID').change(function () {
            var cbo_LastUserID = $('.cbo_LastUserID option:selected').val();
            $('#txt_LastUserID_id').val(cbo_LastUserID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_CowBornID_id_combo() {
    try {
        $('.cbo_CowBornID').change(function () {
            var cbo_CowBornID = $('.cbo_CowBornID option:selected').val();
            $('#txt_CowBornID_id').val(cbo_CowBornID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_CitizenID_id_combo() {
    try {
        $('.cbo_CitizenID').change(function () {
            var cbo_CitizenID = $('.cbo_CitizenID option:selected').val();
            $('#txt_CitizenID_id').val(cbo_CitizenID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_LastUserID_id_combo() {
    try {
        $('.cbo_LastUserID').change(function () {
            var cbo_LastUserID = $('.cbo_LastUserID option:selected').val();
            $('#txt_LastUserID_id').val(cbo_LastUserID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_CowDistributionID_id_combo() {
    try {
        $('.cbo_CowDistributionID').change(function () {
            var cbo_CowDistributionID = $('.cbo_CowDistributionID option:selected').val();
            $('#txt_CowDistributionID_id').val(cbo_CowDistributionID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_CitizenID_id_combo() {
    try {
        $('.cbo_CitizenID').change(function () {
            var cbo_CitizenID = $('.cbo_CitizenID option:selected').val();
            $('#txt_CitizenID_id').val(cbo_CitizenID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_LastUserID_id_combo() {
    try {
        $('.cbo_LastUserID').change(function () {
            var cbo_LastUserID = $('.cbo_LastUserID option:selected').val();
            $('#txt_LastUserID_id').val(cbo_LastUserID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_CowDistributionID_id_combo() {
    try {
        $('.cbo_CowDistributionID').change(function () {
            var cbo_CowDistributionID = $('.cbo_CowDistributionID option:selected').val();
            $('#txt_CowDistributionID_id').val(cbo_CowDistributionID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_LastUserID_id_combo() {
    try {
        $('.cbo_LastUserID').change(function () {
            var cbo_LastUserID = $('.cbo_LastUserID option:selected').val();
            $('#txt_LastUserID_id').val(cbo_LastUserID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_CowDistributionID_id_combo() {
    try {
        $('.cbo_CowDistributionID').change(function () {
            var cbo_CowDistributionID = $('.cbo_CowDistributionID option:selected').val();
            $('#txt_CowDistributionID_id').val(cbo_CowDistributionID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_LastUserID_id_combo() {
    try {
        $('.cbo_LastUserID').change(function () {
            var cbo_LastUserID = $('.cbo_LastUserID option:selected').val();
            $('#txt_LastUserID_id').val(cbo_LastUserID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_CowDistributionID_id_combo() {
    try {
        $('.cbo_CowDistributionID').change(function () {
            var cbo_CowDistributionID = $('.cbo_CowDistributionID option:selected').val();
            $('#txt_CowDistributionID_id').val(cbo_CowDistributionID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_LastUserID_id_combo() {
    try {
        $('.cbo_LastUserID').change(function () {
            var cbo_LastUserID = $('.cbo_LastUserID option:selected').val();
            $('#txt_LastUserID_id').val(cbo_LastUserID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_CowDistributionID_id_combo() {
    try {
        $('.cbo_CowDistributionID').change(function () {
            var cbo_CowDistributionID = $('.cbo_CowDistributionID option:selected').val();
            $('#txt_CowDistributionID_id').val(cbo_CowDistributionID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_LastUserID_id_combo() {
    try {
        $('.cbo_LastUserID').change(function () {
            var cbo_LastUserID = $('.cbo_LastUserID option:selected').val();
            $('#txt_LastUserID_id').val(cbo_LastUserID);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_new_data_hide_show() {
    $('.new_data_hider').click(function () {
        $('.new_data_box').slideToggle();
    });

}
function validate_numbers_textfields() {
    $('.only_numbers').keyup(function () {
        var n = $(this).val();
        if (n >= 1 || n == 0) {
            //here its fine!.
        } else {
            $(this).val('');
        }
    });
}
function hover_theme1() {
    $('.hover_theme1').mouseover(function () {
        $(this).css('background-color', '#29f15c');
        $(this).addClass('no_shade_noBorder');
        $(this).css('cursoer', 'pointer');
    });

    $('.hover_theme1').mouseleave(function () {
        $(this).css('background-color', 'transparent');
        $(this).removeClass('no_shade_noBorder');
    });
}
function show_form_toUpdate() {
    var updname = $('#txt_shall_expand_toUpdate').val();
    if (updname != '') {
        $('.new_data_box').delay(200).slideDown();
    }

}
function postDisplayData(call_dialog, div) {
    $.post('../Admin/handler.php', {call_dialog: call_dialog}, function (data) {
        $(div).html(data);
    }).complete(function () {
        $('.msg_dialog').slideDown(300);
    });
}
function dlog_btn_No_Yes() {
    $('#dlog_btnNo').unbind('click').click(function () {
        alert('Confirmed!');
    });
    $('#dlog_btnYs').unbind('click').click(function () {
        alert('Declined!');
    });
}

//update from user ...

function user_del_udpate() {
    $('.user_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.user').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromuser.. 
    $('.user_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.user').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from cowdonor ...

function cowdonor_del_udpate() {
    $('.cowdonor_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowdonor').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowdonor.. 
    $('.cowdonor_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cowdonor').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from cowidentification ...

function cowidentification_del_udpate() {
    $('.cowidentification_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowidentification').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowidentification.. 
    $('.cowidentification_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cowidentification').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from cell ...

function cell_del_udpate() {
    $('.cell_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cell').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcell.. 
    $('.cell_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cell').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from village ...

function village_del_udpate() {
    $('.village_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.village').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromvillage.. 
    $('.village_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.village').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from sector ...

function sector_del_udpate() {
    $('.sector_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.sector').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromsector.. 
    $('.sector_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.sector').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from citizenshortlisted ...

function citizenshortlisted_del_udpate() {
    $('.citizenshortlisted_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.citizenshortlisted').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcitizenshortlisted.. 
    $('.citizenshortlisted_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.citizenshortlisted').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from cowdistribution ...

function cowdistribution_del_udpate() {
    $('.cowdistribution_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowdistribution').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowdistribution.. 
    $('.cowdistribution_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cowdistribution').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from cowborn ...

function cowborn_del_udpate() {
    $('.cowborn_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowborn').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowborn.. 
    $('.cowborn_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cowborn').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from newborncowdistribution ...

function newborncowdistribution_del_udpate() {
    $('.newborncowdistribution_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.newborncowdistribution').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromnewborncowdistribution.. 
    $('.newborncowdistribution_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.newborncowdistribution').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from cowmovement ...

function cowmovement_del_udpate() {
    $('.cowmovement_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowmovement').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowmovement.. 
    $('.cowmovement_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cowmovement').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from cowtreatmentreceived ...

function cowtreatmentreceived_del_udpate() {
    $('.cowtreatmentreceived_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowtreatmentreceived').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowtreatmentreceived.. 
    $('.cowtreatmentreceived_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cowtreatmentreceived').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from cowsold ...

function cowsold_del_udpate() {
    $('.cowsold_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowsold').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowsold.. 
    $('.cowsold_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cowsold').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from cowstolen ...

function cowstolen_del_udpate() {
    $('.cowstolen_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowstolen').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowstolen.. 
    $('.cowstolen_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cowstolen').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}//update from cowdead ...

function cowdead_del_udpate() {
    $('.cowdead_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowdead').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowdead.. 
    $('.cowdead_delete_link').unbind('click').click(function () {
        var table_to_delete = $(this).closest('td').siblings('.cowdead').attr('title');
        var id_delete = $(this).attr('value').trim();

        $(this).closest('tr').slideUp(400);
        $.post('../Admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {
        }).complete(function () {

        });

    });
}


 
//<editor-fold defaultstate="collapsed" desc="----foreign -----------">
function get_foreign_click(dialog_title, table) {
    $(".foreign_select").show("puff", {percent: 100}, 100, function () {
        $('.dialog').show("drop", {direction: 'up'}, 500);
    });
    $('.dialog_title').html(dialog_title);
    $('.tables').hide();
    $('#' + table).show();
}
function show_users() {
    $('#foreign_users').unbind('click').click(function () {
        $('.menu').hide();
        get_foreign_click('select a User', 'users');
    });
}
function show_cowdonors() {
    $('#foreign_cowdonor').unbind('click').click(function () {
        $('.menu').hide();
        get_foreign_click('select a cow donor', 'cowdonor');
    });
}
function show_citizens() {
    $('#foreign_citizens').unbind('click').click(function () {
        $('.menu').hide();
        get_foreign_click('select a citizen', 'citizens');
    });
}
function show_cow_distribution() {
    $('#foreign_cow_distribution').unbind('click').click(function () {
        $('.menu').hide();
        get_foreign_click('select a distribution', 'cow_distribution');
    });
}
function show_cowborn() {
    $('#foreign_cowborn').click(function () {
        $('.menu').hide();
        get_foreign_click('select a cow ', 'cowborn');
    });
}
function show_cow_cow_identif() {
    $('#foreign_cow_identif').click(function () {
                $('.menu').hide();
        get_foreign_click('select a cow ', 'cow_cow_identif');
    });
}
function selectable_link_click() {
    //account
    $('.select_link_users').click(function () {
        var user_id = $(this).closest('td').siblings('.users_cols').text().trim();
        var users_name = $(this).closest('td').siblings('.names_cols').text().trim();

        $('#txt_user_id').val(user_id);
        $('.foreign_select').fadeOut(300);
        $('.dialog').hide("drop", {direction: "up"}, 500);

        $('#user_holder').html('(' + users_name + ')');
        $('.menu').show();
        //request for profile
        //stock for product
    });
    $('.select_link_cowdonor').click(function () {
        var cowdonor_id = $(this).closest('td').siblings('.cowdonor_cols').text().trim();
        var cowdonor_name = $(this).closest('td').siblings('.cowdonor_cols').text().trim();
        var distr_last_name = $(this).closest('td').siblings('.distr_lastName_cols').text().trim();
        $('.foreign_select').fadeOut(300);
        $('.dialog').hide("drop", {direction: "up"}, 500);
        $('.menu').show();
        $('#selected_cowdonor').html(cowdonor_name);
        $('#txt_CowDonerID_id').val(cowdonor_id);

        //request for profile

        //stock for product
    });
    $('.select_link_citizens').click(function () {
        var citizens_id = $(this).closest('td').siblings('.citizens_col').text().trim();
        var citizens_name = $(this).closest('td').siblings('.FirstName_cols').text().trim();
        $('#txt_CitizenID_id').val(citizens_id);
        var quantity_av = citizens_id;
        $('#item_id_holder').html('(' + citizens_name + ')');
        $('.foreign_select').fadeOut(300);
        $('.dialog').hide("drop", {direction: "up"}, 500);
        $('.menu').show();
        $.post('../Admin/handler.php', {quantity_av: quantity_av}, function (data) {
            $('#Qty_check').val(data);
        });
    });
    $('.select_link_cow_distribution').click(function () {
        var cow_distribution_id = $(this).closest('td').siblings('.cow_distribution_id_col').text().trim();
        var cow_distribution_name = $(this).closest('td').siblings('.date_recorded').text().trim();//this is the date
        $('#txt_item_id').val(cow_distribution_id);
        var quantity_av = cow_distribution_id;
        $('#item_id_holder').html('(' + cow_distribution_name + ')');
        $('.foreign_select').fadeOut(300);
        $('.dialog').hide("drop", {direction: "up"}, 500);
        $('#txt_CowDistributionID_id').val(cow_distribution_id);
    });
    $('.select_link_cow_identif').click(function () {
        var cow_cow_identif_id = $(this).closest('td').siblings('.cow_cow_identif_id_col').text().trim();
        var cow_cow_identif_name = $(this).closest('td').siblings('.TagNumber_id_cols').text().trim();//this is the date
        $('#citizn_holder').val(cow_cow_identif_name);
        var quantity_av = cow_cow_identif_id;
        $('#tag_holder').html('(' + cow_cow_identif_name + ')');
        $('.foreign_select').fadeOut(300);
        $('.dialog').hide("drop", {direction: "up"}, 500);
        $('#txt_cow_identification_id').val(cow_cow_identif_id);
          $('.menu').show();
                    
    });
    $('.select_link_cow_born').click(function () {
        var cow_distribution_id = $(this).closest('td').siblings('.cow_born_col').text().trim();
        var cow_distribution_name = $(this).closest('td').siblings('.DateRecorded_col').text().trim();
        $('#txt_item_id').val(cow_distribution_id);
        var quantity_av = cow_distribution_id;
        $('#item_id_holder').html('(' + cow_distribution_name + ')');
        $('.foreign_select').fadeOut(300);
        $('.dialog').hide("drop", {direction: "up"}, 500);

    });

}
//</editor-fold>
function hide_select_pane() {
    $('.foreign_select').unbind('click').click(function () {
        $(this).fadeOut(200);
        $('.dialog').hide("drop", {direction: 'up'}, 500,
                (function () {
                    $('.menu').show();
                }));
    });
}
function get_citizen_Page() {
    $('.more_onCitizen').click(function () {
        $(this).find('span:first').slideToggle();
        return false;
    });
}
 