<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/> 
        <style>
            #home_bg{
                box-shadow: 0px 0px 15px #00ff5b;
                background-image: url('web_images/preSlide_bg.png');
                background-size: 100%;
                background-repeat: no-repeat;
                border-radius: 100%;
            }
            #side_menu{
                float: right;
                min-height: 100%;;
            }
            .slide_paper{
                width: 100%;
                height: 100%;
                background-color: #00ff5b;
                border-radius: 100%;
            }
            #slide_1, #slide_2, #slide_3{
                background-size: 100%;
                background-repeat: no-repeat;
            }
            #slide_1{
                background-image: url('web_images/cow3.PNG');
            }
            #slide_2{
                background-image: url('web_images/cow2.PNG');
            }
            #slide_3{
                background-image: url('web_images/mycow.PNG');
            }
            #slidetext{
                font-size: 100px;
                margin: 100px;
                float: left;
                text-align: center;
                text-shadow: 2px 2px #fff;
            }
            #side_menu a{
                display: block;
                padding: 10px;
                background-color: #429c2c;
                border-radius: 10px;
                margin-top: 10px;
                color: #fff;
                text-decoration: none;
            }
            .otherparts{
                background-color: #fff;
                margin-top: 200px;
            }
            .xxx_titles{
                font-weight: bolder;
                font-family: arial;
            }
        </style>
    </head>
    <body>
        <?php
        include 'header_menu.php';
        ?>
        <div id="fb-root"></div>
        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>        
        <div class="parts full_center_two_h margin_free x_height_5x  reverse_border">

            <div class="parts eighty_right margin_free no_paddin_shade_no_Border x_height_5x accept_abs" id="home_bg">
                <span id="slidetext" class="off">For the rwandan family</span>
                <div class="parts  abs_full slide_paper margin_free" id="slide_1">
                </div>
                <div class="parts  abs_full slide_paper margin_free" id="slide_2">
                </div>
                <div class="parts  abs_full slide_paper margin_free" id="slide_3">
                </div>
            </div>
            <div class="parts side_menu" id="side_menu" id="slide_3">
                <a href="#">Home</a>
                <a href="#">Cow-related activities</a>
                <a href="login.php">Login</a>
            </div>
        </div>
        <div class="parts eighty_centered otherparts no_shade_noBorder">
            <div class="parts no_shade_noBorder xxx_titles">More on Cows production</div>
            <div class="parts thirty_Per_cent_two_h ">
                <div class="xx_titles">Title1</div>
                More on Organization</div>
            <div class="parts thirty_Per_cent_two_h">
                <div class="xx_titles">Title1</div>
                More comments</div>
            <div class="parts thirty_Per_cent_two_h">
                <div class="xx_titles">Title1</div>
                More on sensibilize</div>
        </div>
        <div class="parts eighty_centered footer">
            Copyrights <?php echo date("Y"); ?>
            <div class="fb-share-button" data-href="https://www.codeguru-pro.net" data-layout="button_count" data-size="small" data-mobile-iframe="true">
                <a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.codeguru-pro.net%2Ftests%2Findex.php&amp;src=sdkpreparse">Share</a>
            </div>      
        </div> 
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <script src="web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>
        <script>
            var c = 0;
            $(document).ready(function () {
                slideforme();
            });
            function slideforme() {
                setTimeout(function name(parameters) {
                    c += 1;
                    $('.slide_paper').hide('slide', {direction: 'left'}, 1000);
                    $('#slide_' + c).delay(100).show("slide", {direction: 'right'}, 700);
                    if (c === 4) {
                        $('#slidetext').fadeIn();
                    }
                    if (c === 7) {
                        c = 0;
                        $('#slidetext').fadeOut(4000);
                    }
                    slideforme();
                }, 4000);
            }
        </script>
    </body>
</html>
