<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border margin_free" id="header_wrapper">
    <div class="parts  eighty_centered margin_free no_shade_noBorder">   
        <div class="parts  no_paddin_shade_no_Border xxx_titles">

        </div>
    </div>   </div>  
<div class="parts menu eighty_centered  no_shade_noBorder">
    <a href="index.php">Home</a>
    <a href="#">contact us</a>
    <a href="login.php">Login</a>

</div>
