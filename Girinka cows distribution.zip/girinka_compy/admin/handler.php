<?php
 session_start();

if (isset($_POST['cbo_LastUserID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_LastUserID_id_by_LastUserID_name($_POST['cbo_LastUserID']);
    return $id;
}
if (isset($_POST['cbo_CowDonerID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_CowDonerID_id_by_CowDonerID_name($_POST['cbo_CowDonerID']);
    return $id;
}
if (isset($_POST['cbo_LastUserID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_LastUserID_id_by_LastUserID_name($_POST['cbo_LastUserID']);
    return $id;
}
if (isset($_POST['cbo_SectorID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_SectorID_id_by_SectorID_name($_POST['cbo_SectorID']);
    return $id;
}
if (isset($_POST['cbo_CellID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_CellID_id_by_CellID_name($_POST['cbo_CellID']);
    return $id;
}
if (isset($_POST['cbo_VillageID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_VillageID_id_by_VillageID_name($_POST['cbo_VillageID']);
    return $id;
}
if (isset($_POST['cbo_LastUserID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_LastUserID_id_by_LastUserID_name($_POST['cbo_LastUserID']);
    return $id;
}
if (isset($_POST['cbo_CitizenID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_CitizenID_id_by_CitizenID_name($_POST['cbo_CitizenID']);
    return $id;
}
if (isset($_POST['cbo_CowID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_CowID_id_by_CowID_name($_POST['cbo_CowID']);
    return $id;
}
if (isset($_POST['cbo_LastUserID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_LastUserID_id_by_LastUserID_name($_POST['cbo_LastUserID']);
    return $id;
}
if (isset($_POST['cbo_CowDistributionID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_CowDistributionID_id_by_CowDistributionID_name($_POST['cbo_CowDistributionID']);
    return $id;
}
if (isset($_POST['cbo_LastUserID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_LastUserID_id_by_LastUserID_name($_POST['cbo_LastUserID']);
    return $id;
}
if (isset($_POST['cbo_CowBornID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_CowBornID_id_by_CowBornID_name($_POST['cbo_CowBornID']);
    return $id;
}
if (isset($_POST['cbo_CitizenID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_CitizenID_id_by_CitizenID_name($_POST['cbo_CitizenID']);
    return $id;
}
if (isset($_POST['cbo_LastUserID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_LastUserID_id_by_LastUserID_name($_POST['cbo_LastUserID']);
    return $id;
}
if (isset($_POST['cbo_CowDistributionID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_CowDistributionID_id_by_CowDistributionID_name($_POST['cbo_CowDistributionID']);
    return $id;
}
if (isset($_POST['cbo_CitizenID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_CitizenID_id_by_CitizenID_name($_POST['cbo_CitizenID']);
    return $id;
}
if (isset($_POST['cbo_LastUserID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_LastUserID_id_by_LastUserID_name($_POST['cbo_LastUserID']);
    return $id;
}
if (isset($_POST['cbo_CowDistributionID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_CowDistributionID_id_by_CowDistributionID_name($_POST['cbo_CowDistributionID']);
    return $id;
}
if (isset($_POST['cbo_LastUserID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_LastUserID_id_by_LastUserID_name($_POST['cbo_LastUserID']);
    return $id;
}
if (isset($_POST['cbo_CowDistributionID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_CowDistributionID_id_by_CowDistributionID_name($_POST['cbo_CowDistributionID']);
    return $id;
}
if (isset($_POST['cbo_LastUserID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_LastUserID_id_by_LastUserID_name($_POST['cbo_LastUserID']);
    return $id;
}
if (isset($_POST['cbo_CowDistributionID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_CowDistributionID_id_by_CowDistributionID_name($_POST['cbo_CowDistributionID']);
    return $id;
}
if (isset($_POST['cbo_LastUserID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_LastUserID_id_by_LastUserID_name($_POST['cbo_LastUserID']);
    return $id;
}
if (isset($_POST['cbo_CowDistributionID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_CowDistributionID_id_by_CowDistributionID_name($_POST['cbo_CowDistributionID']);
    return $id;
}
if (isset($_POST['cbo_LastUserID'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_LastUserID_id_by_LastUserID_name($_POST['cbo_LastUserID']);
    return $id;
}

if (isset($_POST['table_to_update']) ) {
    $id_upd = $_POST['id_update'];
    $table_upd = $_POST['table_to_update'];
    $pref = 'upd_';
    $sufx = $table_upd;
    $_SESSION['table_to_update'] = $table_upd;
    $_SESSION['id_upd'] = $id_upd;
    echo $_SESSION['id_upd'];
}


//The Delete from user
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'user') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_user($id);}
//The Delete from cowdonor
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowdonor') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowdonor($id);}
//The Delete from cowidentification
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowidentification') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowidentification($id);}
//The Delete from cell
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cell') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cell($id);}
//The Delete from village
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'village') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_village($id);}
//The Delete from sector
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'sector') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_sector($id);}
//The Delete from citizenshortlisted
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'citizenshortlisted') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_citizenshortlisted($id);}
//The Delete from cowdistribution
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowdistribution') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowdistribution($id);}
//The Delete from cowborn
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowborn') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowborn($id);}
//The Delete from newborncowdistribution
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'newborncowdistribution') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_newborncowdistribution($id);}
//The Delete from cowmovement
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowmovement') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowmovement($id);}
//The Delete from cowtreatmentreceived
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowtreatmentreceived') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowtreatmentreceived($id);}
//The Delete from cowsold
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowsold') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowsold($id);}
//The Delete from cowstolen
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowstolen') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowstolen($id);}
//The Delete from cowdead
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowdead') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowdead($id);}
if (isset($_POST['pagination_n'])) {
    $_SESSION['pagination_n'] = $_POST['pagination_n'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['paginated_page'];
}
if (isset($_POST['page_no_iteml'])) {
    unset($_SESSION['pagination_n']);
    $_SESSION['page_no_iteml'] = $_POST['page_no_iteml'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['page_no_iteml'];
}
