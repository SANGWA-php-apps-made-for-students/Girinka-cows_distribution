<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_cowmovement'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowmovement') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $cowmovement_id = $_SESSION['id_upd'];

            $CowDistributionID = trim($_POST['txt_CowDistributionID_id']);
            $CitizenID = $_POST['txt_CitizenID_id'];

            $DateMoved = $_POST['txt_DateMoved'];
            $CommentsMovement = $_POST['txt_CommentsMovement'];
            $LastUserID = $_SESSION['userid'];
            $DateRecorded = date('y-m-d');

            $upd_obj->update_cowmovement($CowDistributionID, $CitizenID, $DateMoved, $CommentsMovement, $LastUserID, $DateRecorded, $cowmovement_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $CowDistributionID = trim($_POST['txt_CowDistributionID_id']);
        $CitizenID = trim($_POST['txt_CitizenID_id']);
        $DateMoved = $_POST['txt_DateMoved'];
        $CommentsMovement = $_POST['txt_CommentsMovement'];
        $LastUserID = trim($_SESSION['userid']);
        $DateRecorded = date('y-m-d');

        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_cowmovement($CowDistributionID, $CitizenID, $DateMoved, $CommentsMovement, $LastUserID, $DateRecorded);
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            cowmovement</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_cowmovement.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_CowDistributionID_id"   name="txt_CowDistributionID_id"/><input type="hidden" id="txt_CitizenID_id"   name="txt_CitizenID_id"/><input type="hidden" id="txt_LastUserID_id"   name="txt_LastUserID_id"/>
            <?php
            include 'admin_header.php';
            require_once './Foreign_selects.php';
            ?>

            <div class="parts eighty_centered no_paddin_shade_no_Border">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                cowmovement saved successfully!</div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered ">  cowmovement</div>
                <table class="new_data_table">
                    <tr><td>CowDistributionID :</td><td><a id="foreign_cow_distribution" href="#">select</a>
                            <span id="selected_cow_distribution"></span> <?php //get_CowDistributionID_combo();      ?>  </td></tr> <tr><td>CitizenID :</td><td> <?php get_CitizenID_combo(); ?>  </td></tr><tr><td>DateMoved :</td><td> <input type="text"     name="txt_DateMoved" required class="textbox" value="<?php echo trim(chosen_DateMoved_upd()); ?>"   />  </td></tr>
                    <tr><td>CommentsMovement :</td><td> <input type="text"     name="txt_CommentsMovement" required class="textbox" value="<?php echo trim(chosen_CommentsMovement_upd()); ?>"   />  </td></tr>

                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_cowmovement" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Cows movements List</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_cowmovement();
                $obj->list_cowmovement($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_CowDistributionID_combo() {
    $obj = new multi_values();
    $obj->get_CowDistributionID_in_combo();
}

function get_CitizenID_combo() {
    $obj = new multi_values();
    $obj->get_CitizenID_in_combo();
}

function get_LastUserID_combo() {
    $obj = new multi_values();
    $obj->get_LastUserID_in_combo();
}

function chosen_CowDistributionID_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowmovement') {
            $id = $_SESSION['id_upd'];
            $CowDistributionID = new multi_values();
            return $CowDistributionID->get_chosen_cowmovement_CowDistributionID($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_CitizenID_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowmovement') {
            $id = $_SESSION['id_upd'];
            $CitizenID = new multi_values();
            return $CitizenID->get_chosen_cowmovement_CitizenID($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_DateMoved_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowmovement') {
            $id = $_SESSION['id_upd'];
            $DateMoved = new multi_values();
            return $DateMoved->get_chosen_cowmovement_DateMoved($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_CommentsMovement_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowmovement') {
            $id = $_SESSION['id_upd'];
            $CommentsMovement = new multi_values();
            return $CommentsMovement->get_chosen_cowmovement_CommentsMovement($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_LastUserID_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowmovement') {
            $id = $_SESSION['id_upd'];
            $LastUserID = new multi_values();
            return $LastUserID->get_chosen_cowmovement_LastUserID($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_DateRecorded_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowmovement') {
            $id = $_SESSION['id_upd'];
            $DateRecorded = new multi_values();
            return $DateRecorded->get_chosen_cowmovement_DateRecorded($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
