<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        require_once './admin_header.php';
        ?>
        <div class="parts eighty_centered">
            <div class="parts xx_titles no_shade_noBorder">Brief Report</div>
            <?php
//Counting all records ...
            require_once '../web_db/multi_values.php';
            $count_obj = new multi_values();
            echo'
                    <div class="parts fixed_box_xx ">user<br/>' . $count_obj->All_user() . '</div>                
                    <div class="parts fixed_box_xx ">cowdonor<br/>' . $count_obj->All_cowdonor() . '</div>                
                    <div class="parts fixed_box_xx ">cow<br/>identification<br/>' . $count_obj->All_cowidentification() . '</div>                
                    <div class="parts fixed_box_xx ">sector<br/>' . $count_obj->All_sector() . '</div>                
                    <div class="parts fixed_box_xx ">Citizens<br/>' . $count_obj->All_citizenshortlisted() . '</div>                
                    <div class="parts fixed_box_xx ">cowdistribution<br/>' . $count_obj->All_cowdistribution() . '</div>                
                    <div class="parts fixed_box_xx ">cowborn<br/>' . $count_obj->All_cowborn() . '</div>                
                    <div class="parts fixed_box_xx ">newborncow</br/>distribution<br/>' . $count_obj->All_newborncowdistribution() . '</div>                
                    <div class="parts fixed_box_xx ">cow</br/>movement<br/>' . $count_obj->All_cowmovement() . '</div>                
                    <div class="parts fixed_box_xx ">Treatments<br/>' . $count_obj->All_cowtreatmentreceived() . '</div>                
                    <div class="parts fixed_box_xx ">cowsold<br/>' . $count_obj->All_cowsold() . '</div>                
                    <div class="parts fixed_box_xx ">cowstolen<br/>' . $count_obj->All_cowstolen() . '</div>                
                    <div class="parts fixed_box_xx ">cowdead<br/>' . $count_obj->All_cowdead() . '</div>                ';

//End conting all records .
            ?>
        </div>
    </body>
</html>
