<div class="parts full_center_two_h heit_free margin_free no_paddin_shade_no_Border" id="header_wrapper">
    <div class="parts  eighty_centered margin_free no_shade_noBorder">   
        <div class="parts  no_paddin_shade_no_Border xxx_titles">
            <a href="../index.php" style="color: #fff;">GIRINKA</a>
        </div>
    </div> 
</div>  
<div class="parts menu eighty_centered" id="menu_bar">
    <a href="admin_dashboard.php" class="menu_bg off" style="color: #fff;">Dashboard</a>
    <div class="allow_drop no_shade_noBorder">
        <span class="menu_bg no_shade_noBorder">New menu</span> 
        <div class="hovable_item no_shade_noBorder">
            <div class="parts s_hov no_shade_noBorder">
                <a href="new_user.php">Users</a>
                <!--<a href="new_profile.php">profile</a>-->
            </div>
        </div>
    </div>
    <div class="allow_drop ">
        <span class="menu_bg"> Locations</span> 
        <div class="hovable_item"> 
            <div class="parts s_hov no_shade_noBorder">
                <a href="new_cell.php">cell</a>
                <a href="new_village.php">village</a>
                <a href="new_sector.php">sector</a>
            </div> 
        </div>
    </div>
    <div class="allow_drop ">
        <span class="menu_bg"> Cows</span> 
        <div class="hovable_item"> 
            <div class="parts s_hov no_shade_noBorder">
                <a href="new_cowidentification.php">Cow identification</a>
                <a href="new_cowborn.php">cowborn</a>
            </div> 
        </div>
    </div>
    <div class="allow_drop ">
        <span class="menu_bg"> Distribution</span> 
        <div class="hovable_item"> 
            <div class="parts s_hov no_shade_noBorder">
                <a href="new_cowdistribution.php">Cows distributions</a>
            </div> 
        </div>
    </div>
    <div class="allow_drop">
        <span class="menu_bg"> Cows Supervision</span> 
        <div class="hovable_item"> 
            <div class="parts s_hov no_shade_noBorder">
                <a href="new_cowdonor.php">Donors</a>
                <a href="new_citizenshortlisted.php">Citizens</a>
                <a href="new_newborncowdistribution.php">newborncowdistribution</a>
                <a href="new_cowmovement.php">Movements</a>
                <a href="new_cowtreatmentreceived.php">Treatments</a>
                <a href="new_cowsold.php">Sold cows</a>
                <a href="new_cowstolen.php">Stolen cows</a>
                <a href="new_cowdead.php">Dead cows</a>

            </div> 
        </div>
    </div>





    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="../logout.php">Logout</a>
    </div>
</div>
