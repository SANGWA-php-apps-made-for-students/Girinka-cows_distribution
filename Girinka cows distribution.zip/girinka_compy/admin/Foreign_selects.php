 
<div class="parts abs_full off foreign_select">

</div>  
<div class="parts dialog eighty_centered off no_paddin_shade_no_Border"   >
    <div class="parts title margin_free full_center_two_h heit_free no_shade_noBorder ">
        <span class="dialog_title">Title</span>
    </div>
    <div class="parts tables off  no_shade_noBorder reverse_border" id="users">
        <?php list_user() ?> 
    </div>
    <div class="parts tables off  no_shade_noBorder reverse_border" id="cowdonor">
        <?php list_cowdonor() ?> 
    </div>
    <div class="parts tables off  no_shade_noBorder reverse_border" id="citizens">
        <?php list_citizenshortlisted() ?> 
    </div>
    <div class="parts tables off  no_shade_noBorder reverse_border" id="cow_distribution">
        <?php list_cowdistribution() ?> 
    </div>
    <div class="parts tables  tables no_shade_noBorder reverse_border" id="cow_born">
        <?php list_cowborn();
        ?> 
    </div>
    <div class="parts tables  tables no_shade_noBorder reverse_border" id="cow_cow_identif">
        <?php list_identification();
        ?> 
    </div>
    <div class="parts tables  off no_shade_noBorder reverse_border" id="plots_with_cells">
        <div class="parts  margin_free full_center_two_h heit_free no_shade_noBorder no_bg ">
            <div class="parts link_cursor" id="hide_famer_btn">Show/Hide Farmers' Plot</div>
        </div>
        <?php //list_plot_with_cells()     ?> 
    </div>

    <div class="parts tables  off no_shade_noBorder reverse_border" id="delete_stock">
        <div class="parts two_fifty_left  yes_no_btns" id="del_yes" >Yes</div>
        <div class="parts two_fifty_right yes_no_btns" id="del_no">No</div>
    </div>
</div>
<?php
//selectables
require_once '../web_db/connection.php';

function _e($string) {
    echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

function list_user() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from user    ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    ?>
    <table class="dataList_table">
        <thead><tr>
                <td> user </td>
                <td> names </td><td> user_name </td> <td> type </td>
                <td>Select</td>

            </tr></thead>
        <?php
        $pages = 1;
        while ($row = $stmt->fetch()) {
            ?><tr> 
                <td class="users_cols">
                    <?php echo $row['user_id']; ?>
                </td>
                <td class="names_cols user " title="user" >
                    <?php echo _e($row['names']); ?>
                </td>
                <td>
                    <?php echo _e($row['user_name']); ?>
                </td>
                <td>
                    <?php echo _e($row['type']); ?>
                </td>
                <td><a class="select_link_users" href="#">Select</a></td>

            </tr>
            <?php
            $pages+=1;
        }
        ?></table>
    <?php
}

function list_cowdonor() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from cowdonor   ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    ?>
    <table class="dataList_table">
        <thead><tr>
                <td> cowdonor </td>
                <td> CowDonorName </td><td> LastUserID </td><td> DateRecorded </td>
                <td>Select</td> 

            </tr></thead>
        <?php
        $pages = 1;
        while ($row = $stmt->fetch()) {
            ?><tr> 
                <td class="cowdonor_cols">
                    <?php echo $row['CowDonerID']; ?>
                </td>
                <td class="cowdonorname_cols cowdonor " title="cowdonor" >
                    <?php echo _e($row['CowDonorName']); ?>
                </td>
                <td>
                    <?php echo _e($row['LastUserID']); ?>
                </td>
                <td>
                    <?php echo _e($row['DateRecorded']); ?>
                </td>
                <td><a class="select_link_cowdonor" href="#">Select</a></td>
            </tr>
            <?php
            $pages+=1;
        }
        ?></table>
    <?php
}

function list_citizenshortlisted() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from citizenshortlisted   ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    ?>
    <table class="dataList_table">
        <thead><tr>

                <td> ID </td>
                <td> FirstName </td><td> LastName </td><td> PhoneNumber </td>
                <td>Select</td>
            </tr></thead>
        <?php
        $pages = 1;
        while ($row = $stmt->fetch()) {
            ?><tr> 
                <td class="citizens_col">
                    <?php echo $row['CitizenID']; ?>
                </td>
                <td class="FirstName_cols citizenshortlisted " title="citizenshortlisted" >
                    <?php echo _e($row['FirstName']); ?>
                </td>
                <td>
                    <?php echo _e($row['LastName']); ?>
                </td>

                <td>
                    <?php echo _e($row['PhoneNumber']); ?>
                </td>


                <td><a class="select_link_citizens" href="#">Select</a></td>
            </tr>
            <?php
            $pages+=1;
        }
        ?></table>
    <?php
}

function list_identification() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from cowidentification ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    ?>
    <table class="dataList_table">
        <thead><tr>

                <td> ID </td>
                <td> TagNumber </td><td> Color </td>
                <td> CowRace </td> 
                <td>Select</td></tr></thead>

        <?php
        $pages = 1;
        while ($row = $stmt->fetch()) {
            ?><tr> 

                <td class="cow_cow_identif_id_col">
                    <?php echo $row['CawId']; ?>
                </td>
                <td class="TagNumber_id_cols cowidentification " title="cowidentification" >
                    <?php echo _e($row['TagNumber']); ?>
                </td>
                <td>
                    <?php echo _e($row['Color']); ?>
                </td>
                <td>
                    <?php echo _e($row['CowRace']); ?>
                </td>
                <td><a class="select_link_cow_identif" href="#">Select</a></td>

            </tr>
            <?php
            $pages+=1;
        }
        ?></table>
    <?php
}

function list_cowdistribution() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from cowdistribution  ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    ?>
    <table class="dataList_table">
        <thead><tr>

                <td> cowdistribution </td>
                <td> CitizenID </td><td> CowID </td><td> DateDistribution </td><td> Comments </td><td> LastUserID </td><td> DateRecorded </td>
                <td>Select</td>

            </tr></thead>
        <?php
        $pages = 1;
        while ($row = $stmt->fetch()) {
            ?><tr> 
                <td class="cow_distribution_id_col">
                    <?php echo $row['cowdistribution_id']; ?>
                </td>
                <td class="CitizenID_id_cols cowdistribution " title="cowdistribution" >
                    <?php echo _e($row['CitizenID']); ?>
                </td>
                <td>
                    <?php echo _e($row['CowID']); ?>
                </td>
                <td>
                    <?php echo _e($row['DateDistribution']); ?>
                </td>
                <td>
                    <?php echo _e($row['Comments']); ?>
                </td>
                <td>
                    <?php echo _e($row['LastUserID']); ?>
                </td>
                <td class="date_recorded">
                    <?php echo _e($row['DateRecorded']); ?>
                </td>
                <td><a class="select_cow_distribution" href="#">Select</a></td>
            </tr>
            <?php
            $pages+=1;
        }
        ?></table>
    <?php
}

function list_cowborn() {
    try {
        $database = new dbconnection();
        $db = $database->openConnection();
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "select * from cowborn   ";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> cowborn </td>
                    <td> CowDistributionID </td><td> SexNewBorn </td>
                    <td> NewBornRace </td><td> BornDate </td>
                    <td> NewBornEarTagNumber </td><td> CowStatus </td>
                    <td> DateRecorded </td>
                    <td> LastUserID </td>
                    <td>Select</td>
                </tr></thead>
            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 
                    <td class="cow_born_col">
                        <?php echo $row['cowborn_id']; ?>
                    </td>
                    <td class="CowDistributionID_id_cols cowborn " title="cowborn" >
                        <?php echo _e($row['CowDistributionID']); ?>
                    </td>
                    <td>
                        <?php echo _e($row['SexNewBorn']); ?>
                    </td>
                    <td>
                        <?php echo _e($row['NewBornRace']); ?>
                    </td>
                    <td>
                        <?php echo _e($row['BornDate']); ?>
                    </td>
                    <td>
                        <?php echo _e($row['NewBornEarTagNumber']); ?>
                    </td>
                    <td>
                        <?php echo _e($row['CowStatus']); ?>
                    </td>
                    <td class="DateRecorded_col">
                        <?php echo _e($row['DateRecorded']); ?>
                    </td>
                    <td>
                        <?php echo _e($row['LastUserID']); ?>
                    </td>
                    <td><a class="select_link_cow_born" href="#">Select</a></td>
                    <td>
                        <a href="#" class="cowborn_delete_link" style="color: #000080;" value="
                           <?php echo $row['cowborn_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cowborn_update_link" style="color: #000080;" value="
                           <?php echo $row['cowborn_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
        <?php
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}
