<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_cowstolen'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowstolen') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $cowstolen_id = $_SESSION['id_upd'];
            $CowDistributionID = trim($_POST['txt_CowDistributionID_id']);
            $DateStolen = $_POST['txt_DateStolen'];
            $Returned = $_POST['txt_Returned'];
            $RecordDate = date('y-m-d');
            $LastUserID = $_SESSION['userid'];

            $Comments = $_POST['txt_Comments'];
            $upd_obj->update_cowstolen($CowDistributionID, $DateStolen, $Returned, $RecordDate, $LastUserID, $Comments, $cowstolen_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $CowDistributionID = trim($_POST['txt_CowDistributionID_id']);
        $DateStolen = $_POST['txt_DateStolen'];
        $Returned = $_POST['txt_Returned'];
        $RecordDate = date('y-m-d');
        $LastUserID = trim($_SESSION['userid']);
        $Comments = $_POST['txt_Comments'];

        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_cowstolen($CowDistributionID, $DateStolen, $Returned, $RecordDate, $LastUserID, $Comments);
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            cowstolen</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_cowstolen.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_CowDistributionID_id"   name="txt_CowDistributionID_id"/><input type="hidden" id="txt_LastUserID_id"   name="txt_LastUserID_id"/>
            <?php
            include 'admin_header.php';
            require_once './Foreign_selects.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                cowstolen saved successfully!</div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered ">  cowstolen</div>
                <table class="new_data_table">
                    <tr><td>CowDistributionID :</td><td><a id="foreign_cow_distribution" href="#">select</a>
                            <span id="selected_cow_distribution"></span> <?php //get_CowDistributionID_combo();        ?>  </td></tr><tr><td>DateStolen :</td><td> <input type="text"     name="txt_DateStolen" required class="textbox" value="<?php echo trim(chosen_DateStolen_upd()); ?>"   />  </td></tr>
                    <tr><td>Returned :</td><td> <input type="text"     name="txt_Returned" required class="textbox" value="<?php echo trim(chosen_Returned_upd()); ?>"   />  </td></tr>

                    <span id="selected_users"></span> <?php //get_LastUserID_combo();       ?>  </td></tr><tr><td>Comments :</td><td> <input type="text"     name="txt_Comments" required class="textbox" value="<?php echo trim(chosen_Comments_upd()); ?>"   />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_cowstolen" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">List of stolen cows</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_cowstolen();
                $obj->list_cowstolen($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_CowDistributionID_combo() {
    $obj = new multi_values();
    $obj->get_CowDistributionID_in_combo();
}

function get_LastUserID_combo() {
    $obj = new multi_values();
    $obj->get_LastUserID_in_combo();
}

function chosen_CowDistributionID_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowstolen') {
            $id = $_SESSION['id_upd'];
            $CowDistributionID = new multi_values();
            return $CowDistributionID->get_chosen_cowstolen_CowDistributionID($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_DateStolen_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowstolen') {
            $id = $_SESSION['id_upd'];
            $DateStolen = new multi_values();
            return $DateStolen->get_chosen_cowstolen_DateStolen($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_Returned_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowstolen') {
            $id = $_SESSION['id_upd'];
            $Returned = new multi_values();
            return $Returned->get_chosen_cowstolen_Returned($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_RecordDate_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowstolen') {
            $id = $_SESSION['id_upd'];
            $RecordDate = new multi_values();
            return $RecordDate->get_chosen_cowstolen_RecordDate($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_LastUserID_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowstolen') {
            $id = $_SESSION['id_upd'];
            $LastUserID = new multi_values();
            return $LastUserID->get_chosen_cowstolen_LastUserID($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_Comments_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowstolen') {
            $id = $_SESSION['id_upd'];
            $Comments = new multi_values();
            return $Comments->get_chosen_cowstolen_Comments($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
