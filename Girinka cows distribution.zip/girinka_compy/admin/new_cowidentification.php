<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_cowidentification'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowidentification') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $cowidentification_id = $_SESSION['id_upd'];

            $TagNumber = $_POST['txt_TagNumber'];
            $Color = $_POST['txt_Color'];
            $CowRace = $_POST['txt_CowRace'];
            $CowDonerID = $_POST['txt_CowDonerID_id'];

            $CowStatus = $_POST['txt_CowStatus'];
            $LastUserID = trim($_SESSION['userid']);
            $DateRecorded = date('y-m-d');

            $upd_obj->update_cowidentification($TagNumber, $Color, $CowRace, $CowDonerID, $CowStatus, $LastUserID, $DateRecorded, $cowidentification_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $TagNumber = $_POST['txt_TagNumber'];
        $Color = $_POST['txt_Color'];
        $CowRace = $_POST['txt_CowRace'];
        $CowDonerID = trim($_POST['txt_CowDonerID_id']);
        $CowStatus = $_POST['txt_CowStatus'];
        $LastUserID = trim($_SESSION['userid']);

        $DateRecorded = date('y-m-d');
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_cowidentification($TagNumber, $Color, $CowRace, $CowDonerID, $CowStatus, $LastUserID, $DateRecorded);
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            cowidentification</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_cowidentification.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_CowDonerID_id"   name="txt_CowDonerID_id"/>
            <input type="hidden" id="txt_LastUserID_id"   name="txt_LastUserID_id"/>
            <?php
            include 'admin_header.php';
            require_once './Foreign_selects.php';
            ?>

            <div class="parts eighty_centered no_paddin_shade_no_Border">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                cowidentification saved successfully!</div>


            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered ">  cowidentification</div>
                <table class="new_data_table">
                    <tr><td>TagNumber :</td><td> <input type="text"     name="txt_TagNumber" required class="textbox" value="<?php echo trim(chosen_TagNumber_upd()); ?>"   />  </td></tr>
                    <tr><td>Color :</td><td> <input type="text"     name="txt_Color" required class="textbox" value="<?php echo trim(chosen_Color_upd()); ?>"   />  </td></tr>
                    <tr><td>CowRace :</td><td> <input type="text"     name="txt_CowRace" required class="textbox" value="<?php echo trim(chosen_CowRace_upd()); ?>"   />  </td></tr>
                    <tr><td>CowDonerID :</td><td><a id="foreign_cowdonor" href="#">select</a>
                            <span id="selected_cowdonor"></span> <?php //get_CowDonerID_combo();               ?>  </td></tr><tr><td>CowStatus :</td><td> <input type="text"     name="txt_CowStatus" required class="textbox" value="<?php echo trim(chosen_CowStatus_upd()); ?>"   />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_cowidentification" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Cows identification report</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_cowidentification();
                $obj->list_cowidentification($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_CowDonerID_combo() {
    $obj = new multi_values();
    $obj->get_CowDonerID_in_combo();
}

function get_LastUserID_combo() {
    $obj = new multi_values();
    $obj->get_LastUserID_in_combo();
}

function chosen_TagNumber_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowidentification') {
            $id = $_SESSION['id_upd'];
            $TagNumber = new multi_values();
            return $TagNumber->get_chosen_cowidentification_TagNumber($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_Color_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowidentification') {
            $id = $_SESSION['id_upd'];
            $Color = new multi_values();
            return $Color->get_chosen_cowidentification_Color($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_CowRace_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowidentification') {
            $id = $_SESSION['id_upd'];
            $CowRace = new multi_values();
            return $CowRace->get_chosen_cowidentification_CowRace($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_CowDonerID_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowidentification') {
            $id = $_SESSION['id_upd'];
            $CowDonerID = new multi_values();
            return $CowDonerID->get_chosen_cowidentification_CowDonerID($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_CowStatus_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowidentification') {
            $id = $_SESSION['id_upd'];
            $CowStatus = new multi_values();
            return $CowStatus->get_chosen_cowidentification_CowStatus($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_LastUserID_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowidentification') {
            $id = $_SESSION['id_upd'];
            $LastUserID = new multi_values();
            return $LastUserID->get_chosen_cowidentification_LastUserID($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_DateRecorded_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'cowidentification') {
            $id = $_SESSION['id_upd'];
            $DateRecorded = new multi_values();
            return $DateRecorded->get_chosen_cowidentification_DateRecorded($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
