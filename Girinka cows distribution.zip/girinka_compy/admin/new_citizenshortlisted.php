<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_citizenshortlisted'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'citizenshortlisted') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $citizenshortlisted_id = $_SESSION['id_upd'];
            $FirstName = $_POST['txt_FirstName'];
            $LastName = $_POST['txt_LastName'];
            $IDNumber = $_POST['txt_IDNumber'];
            $PhoneNumber = $_POST['txt_PhoneNumber'];
            $VillageID = $_POST['txt_VillageID_id'];
            $UbudeheCategory = $_POST['txt_UbudeheCategory'];
            $NumberChoosen = $_POST['txt_NumberChoosen'];
            $Comments = $_POST['txt_Comments'];
            $Status = $_POST['txt_Status'];
            $RecordDate = date('y-m-d');
            $LastUserID = $_SESSION['userid'];
            $upd_obj->update_citizenshortlisted($FirstName, $LastName, $IDNumber, $PhoneNumber, $VillageID, $UbudeheCategory, $NumberChoosen, $Comments, $Status, $RecordDate, $LastUserID, $citizenshortlisted_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $FirstName = $_POST['txt_FirstName'];
        $LastName = $_POST['txt_LastName'];
        $IDNumber = $_POST['txt_IDNumber'];
        $PhoneNumber = $_POST['txt_PhoneNumber'];
        $VillageID = trim($_POST['txt_VillageID_id']);
        $UbudeheCategory = $_POST['txt_UbudeheCategory'];
        $NumberChoosen = $_POST['txt_NumberChoosen'];
        $Comments = $_POST['txt_Comments'];
        $Status = $_POST['txt_Status'];
        $RecordDate = date('y-m-d');
        $LastUserID = trim($_SESSION['userid']);
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_citizenshortlisted($FirstName, $LastName, $IDNumber, $PhoneNumber, $VillageID, $UbudeheCategory, $NumberChoosen, $Comments, $Status, $RecordDate, $LastUserID);
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            citizenshortlisted</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <style>
            .Details_row{
                background-color: #c0e1b7;
            }
            .Details_row thead{
                background-color: #99f183;
            }
            .Details_row table{
                background-color: #fff;
            }

        </style>
    </head>
    <body>
        <form action="new_citizenshortlisted.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_VillageID_id"   name="txt_VillageID_id"/><input type="hidden" id="txt_LastUserID_id"   name="txt_LastUserID_id"/>
            <?php
            include 'admin_header.php';
            require_once './Foreign_selects.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                citizenshortlisted saved successfully!</div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered ">  citizenshortlisted</div>
                <table class="new_data_table">
                    <tr><td>FirstName :</td><td> <input type="text"     name="txt_FirstName" required class="textbox" value="<?php echo trim(chosen_FirstName_upd()); ?>"   />  </td></tr>
                    <tr><td>LastName :</td><td> <input type="text"     name="txt_LastName" required class="textbox" value="<?php echo trim(chosen_LastName_upd()); ?>"   />  </td></tr>
                    <tr><td>IDNumber :</td><td> <input type="text"     name="txt_IDNumber" required class="textbox" value="<?php echo trim(chosen_IDNumber_upd()); ?>"   />  </td></tr>
                    <tr><td>PhoneNumber :</td><td> <input type="text"     name="txt_PhoneNumber" required class="textbox" value="<?php echo trim(chosen_PhoneNumber_upd()); ?>"   />  </td></tr>
                    <tr><td>VillageID :</td><td> <?php get_VillageID_combo(); ?>  </td></tr><tr><td>UbudeheCategory :</td><td> <input type="text"     name="txt_UbudeheCategory" required class="textbox" value="<?php echo trim(chosen_UbudeheCategory_upd()); ?>"   />  </td></tr>
                    <tr><td>NumberChoosen :</td><td> <input type="text"     name="txt_NumberChoosen" required class="textbox" value="<?php echo trim(chosen_NumberChoosen_upd()); ?>"   />  </td></tr>
                    <tr><td>Comments :</td><td> <input type="text"     name="txt_Comments" required class="textbox" value="<?php echo trim(chosen_Comments_upd()); ?>"   />  </td></tr>
                    <tr><td>Status :</td><td> <input type="text"     name="txt_Status" required class="textbox" value="<?php echo trim(chosen_Status_upd()); ?>"   />  </td></tr>


                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_citizenshortlisted" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">citizens List</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_citizenshortlisted();
                $obj->list_citizenshortlisted($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <script src="../web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_VillageID_combo() {
    $obj = new multi_values();
    $obj->get_VillageID_in_combo();
}

function get_LastUserID_combo() {
    $obj = new multi_values();
    $obj->get_LastUserID_in_combo();
}

function chosen_FirstName_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'citizenshortlisted') {
            $id = $_SESSION['id_upd'];
            $FirstName = new multi_values();
            return $FirstName->get_chosen_citizenshortlisted_FirstName($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_LastName_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'citizenshortlisted') {
            $id = $_SESSION['id_upd'];
            $LastName = new multi_values();
            return $LastName->get_chosen_citizenshortlisted_LastName($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_IDNumber_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'citizenshortlisted') {
            $id = $_SESSION['id_upd'];
            $IDNumber = new multi_values();
            return $IDNumber->get_chosen_citizenshortlisted_IDNumber($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_PhoneNumber_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'citizenshortlisted') {
            $id = $_SESSION['id_upd'];
            $PhoneNumber = new multi_values();
            return $PhoneNumber->get_chosen_citizenshortlisted_PhoneNumber($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_VillageID_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'citizenshortlisted') {
            $id = $_SESSION['id_upd'];
            $VillageID = new multi_values();
            return $VillageID->get_chosen_citizenshortlisted_VillageID($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_UbudeheCategory_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'citizenshortlisted') {
            $id = $_SESSION['id_upd'];
            $UbudeheCategory = new multi_values();
            return $UbudeheCategory->get_chosen_citizenshortlisted_UbudeheCategory($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_NumberChoosen_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'citizenshortlisted') {
            $id = $_SESSION['id_upd'];
            $NumberChoosen = new multi_values();
            return $NumberChoosen->get_chosen_citizenshortlisted_NumberChoosen($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_Comments_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'citizenshortlisted') {
            $id = $_SESSION['id_upd'];
            $Comments = new multi_values();
            return $Comments->get_chosen_citizenshortlisted_Comments($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_Status_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'citizenshortlisted') {
            $id = $_SESSION['id_upd'];
            $Status = new multi_values();
            return $Status->get_chosen_citizenshortlisted_Status($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_RecordDate_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'citizenshortlisted') {
            $id = $_SESSION['id_upd'];
            $RecordDate = new multi_values();
            return $RecordDate->get_chosen_citizenshortlisted_RecordDate($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_LastUserID_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'citizenshortlisted') {
            $id = $_SESSION['id_upd'];
            $LastUserID = new multi_values();
            return $LastUserID->get_chosen_citizenshortlisted_LastUserID($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}
