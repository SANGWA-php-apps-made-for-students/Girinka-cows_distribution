<?php

require_once 'Fpdf/fpdf.php';
require_once '../web_db/connection.php';
class PDF extends FPDF {

// Load data
    function LoadData() {
        // Read file lines

        $database=new dbconnection();
        $db = $database->openconnection();        $sql = "select * from citizenshortlisted  ";
   // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
        $this->Cell(120, 7,'GIRINKA', 0, 0, 'L');
        $this->Cell(60, 7, 'DISTRICT: GASABO', 0, 0, 'L');
        $this->Ln();
        $this->Cell(120, 7, 'RWANDA ', 0, 0, 'E');
        $this->Cell(60, 7, 'TELEPHONE: 0788252272 ', 0, 0, 'L');

        $this->Ln();
        $this->Ln();
        $this->Ln();
        $this->Ln();
        $this->SetFont("Arial", 'B', 14);
        $this->Cell(170, 7, 'citizenshortlisted REPORT ', 0, 0, 'C');

        $this->Ln();
        $this->Ln();
        $this->SetFont("Arial", '', 14);
// </editor-fold>

$this->Cell(30, 7, 'CitizenID', 1, 0, 'L');$this->Cell(30, 7, 'FirstName', 1, 0, 'L');$this->Cell(30, 7, 'LastName', 1, 0, 'L');$this->Cell(30, 7, 'IDNumber', 1, 0, 'L');$this->Cell(30, 7, 'PhoneNumber', 1, 0, 'L');$this->Cell(30, 7, 'UbudeheCategory', 1, 0, 'L');$this->Cell(30, 7, 'NumberChoosen', 1, 0, 'L');$this->Cell(30, 7, 'Comments', 1, 0, 'L');$this->Cell(30, 7, 'Status', 1, 0, 'L');$this->Cell(30, 7, 'RecordDate', 1, 0, 'L');$this->Cell(30, 7, 'VillageID', 1, 0, 'L');$this->Cell(30, 7, 'LastUserID', 1, 0, 'L');
 $this->Ln();
        foreach ($db->query($sql) as $row) {
$this->cell(30, 7, $row['CitizenID'], 1, 0, 'L');
$this->cell(30, 7, $row['FirstName'], 1, 0, 'L');
$this->cell(30, 7, $row['LastName'], 1, 0, 'L');
$this->cell(30, 7, $row['IDNumber'], 1, 0, 'L');
$this->cell(30, 7, $row['PhoneNumber'], 1, 0, 'L');
$this->cell(30, 7, $row['UbudeheCategory'], 1, 0, 'L');
$this->cell(30, 7, $row['NumberChoosen'], 1, 0, 'L');
$this->cell(30, 7, $row['Comments'], 1, 0, 'L');
$this->cell(30, 7, $row['Status'], 1, 0, 'L');
$this->cell(30, 7, $row['RecordDate'], 1, 0, 'L');
$this->cell(30, 7, $row['VillageID'], 1, 0, 'L');
$this->cell(30, 7, $row['LastUserID'], 1, 0, 'L');


 $this->Ln();
        }
    }
}

$pdf = new PDF();
$pdf->SetFont('Arial', '', 13);
$pdf->AddPage();
$pdf->LoadData();
$pdf->Output(); 
