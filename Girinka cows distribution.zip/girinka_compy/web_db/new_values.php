<?php

class new_values {

    function new_user($names, $user_name, $password, $type) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into user values(:user_id, :names,  :user_name,  :password,  :type)");
            $stm->execute(array(':user_id' => 0, ':names' => $names, ':user_name' => $user_name, ':password' => $password, ':type' => $type
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_cowdonor($CowDonorName, $LastUserID, $DateRecorded) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into cowdonor values(:cowdonor_id, :CowDonorName,  :LastUserID,  :DateRecorded)");
            $stm->execute(array(':cowdonor_id' => 0, ':CowDonorName' => $CowDonorName, ':LastUserID' => $LastUserID, ':DateRecorded' => $DateRecorded
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_cowidentification($TagNumber, $Color, $CowRace, $CowDonerID, $CowStatus, $LastUserID, $DateRecorded) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into cowidentification values(:cowidentification_id, :TagNumber,  :Color,  :CowRace,  :CowDonerID,  :CowStatus,  :LastUserID,  :DateRecorded)");
            $stm->execute(array(':cowidentification_id' => 0, ':TagNumber' => $TagNumber, ':Color' => $Color, ':CowRace' => $CowRace, ':CowDonerID' => $CowDonerID, ':CowStatus' => $CowStatus, ':LastUserID' => $LastUserID, ':DateRecorded' => $DateRecorded
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_cell($CellName, $SectorID) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into cell values(:CellID, :CellName,  :SectorID)");
            $stm->execute(array(':CellID' => 0, ':CellName' => $CellName, ':SectorID' => $SectorID
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_village($VillageName, $CellID) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into village values(:village_id, :VillageName,  :CellID)");
            $stm->execute(array(':village_id' => 0, ':VillageName' => $VillageName, ':CellID' => $CellID
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_sector($SectorName) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into sector values(:sector_id, :SectorName)");
            $stm->execute(array(':sector_id' => 0, ':SectorName' => $SectorName
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_citizenshortlisted($FirstName, $LastName, $IDNumber, $PhoneNumber, $VillageID, $UbudeheCategory, $NumberChoosen, $Comments, $Status, $RecordDate, $LastUserID) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into citizenshortlisted values(:citizenshortlisted_id, :FirstName,  :LastName,  :IDNumber,  :PhoneNumber,  :VillageID,  :UbudeheCategory,  :NumberChoosen,  :Comments,  :Status,  :RecordDate,  :LastUserID)");
            $stm->execute(array(':citizenshortlisted_id' => 0, ':FirstName' => $FirstName, ':LastName' => $LastName, ':IDNumber' => $IDNumber, ':PhoneNumber' => $PhoneNumber, ':VillageID' => $VillageID, ':UbudeheCategory' => $UbudeheCategory, ':NumberChoosen' => $NumberChoosen, ':Comments' => $Comments, ':Status' => $Status, ':RecordDate' => $RecordDate, ':LastUserID' => $LastUserID
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_cowdistribution($CitizenID, $CowID, $DateDistribution, $Comments, $LastUserID, $DateRecorded) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into cowdistribution values(:CowDistributionID, :CitizenID,  :CowID,  :DateDistribution,  :Comments,  :LastUserID,  :DateRecorded)");
            $stm->execute(array(':CowDistributionID' => 0, ':CitizenID' => $CitizenID, ':CowID' => $CowID, ':DateDistribution' => $DateDistribution, ':Comments' => $Comments, ':LastUserID' => $LastUserID, ':DateRecorded' => $DateRecorded
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e->getMessage();
        }
    }

    function new_cowborn($CowDistributionID, $SexNewBorn, $NewBornRace, $BornDate, $NewBornEarTagNumber, $CowStatus, $DateRecorded, $LastUserID) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into cowborn values(:cowborn_id, :CowDistributionID,  :SexNewBorn,  :NewBornRace,  :BornDate,  :NewBornEarTagNumber,  :CowStatus,  :DateRecorded,  :LastUserID)");
            $stm->execute(array(':cowborn_id' => 0, ':CowDistributionID' => $CowDistributionID, ':SexNewBorn' => $SexNewBorn, ':NewBornRace' => $NewBornRace, ':BornDate' => $BornDate, ':NewBornEarTagNumber' => $NewBornEarTagNumber, ':CowStatus' => $CowStatus, ':DateRecorded' => $DateRecorded, ':LastUserID' => $LastUserID
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_newborncowdistribution($CowBornID, $CitizenID, $DateOp, $Comments, $LastUserID, $DateRecorded) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into newborncowdistribution values(:newborncowdistribution_id, :CowBornID,  :CitizenID,  :DateOp,  :Comments,  :LastUserID,  :DateRecorded)");
            $stm->execute(array(':newborncowdistribution_id' => 0, ':CowBornID' => $CowBornID, ':CitizenID' => $CitizenID, ':DateOp' => $DateOp, ':Comments' => $Comments, ':LastUserID' => $LastUserID, ':DateRecorded' => $DateRecorded
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_cowmovement($CowDistributionID, $CitizenID, $DateMoved, $CommentsMovement, $LastUserID, $DateRecorded) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into cowmovement values(:cowmovement_id, :CowDistributionID,  :CitizenID,  :DateMoved,  :CommentsMovement,  :LastUserID,  :DateRecorded)");
            $stm->execute(array(':cowmovement_id' => 0, ':CowDistributionID' => $CowDistributionID, ':CitizenID' => $CitizenID, ':DateMoved' => $DateMoved, ':CommentsMovement' => $CommentsMovement, ':LastUserID' => $LastUserID, ':DateRecorded' => $DateRecorded
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_cowtreatmentreceived($CowDistributionID, $Symptomology, $Intervention, $Comments, $DateTreatment, $LastUserID, $RecordDate) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into cowtreatmentreceived values(:cowtreatmentreceived_id, :CowDistributionID,  :Symptomology,  :Intervention,  :Comments,  :DateTreatment,  :LastUserID,  :RecordDate)");
            $stm->execute(array(':cowtreatmentreceived_id' => 0, ':CowDistributionID' => $CowDistributionID, ':Symptomology' => $Symptomology, ':Intervention' => $Intervention, ':Comments' => $Comments, ':DateTreatment' => $DateTreatment, ':LastUserID' => $LastUserID, ':RecordDate' => $RecordDate
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_cowsold($CowDistributionID, $DateSold, $Redistributed, $RecordedDate, $LastUserID, $Comments) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into cowsold values(:cowsold_id, :CowDistributionID,  :DateSold,  :Redistributed,  :RecordedDate,  :LastUserID,  :Comments)");
            $stm->execute(array(':cowsold_id' => 0, ':CowDistributionID' => $CowDistributionID, ':DateSold' => $DateSold, ':Redistributed' => $Redistributed, ':RecordedDate' => $RecordedDate, ':LastUserID' => $LastUserID, ':Comments' => $Comments
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_cowstolen($CowDistributionID, $DateStolen, $Returned, $RecordDate, $LastUserID, $Comments) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into cowstolen values(:cowstolen_id, :CowDistributionID,  :DateStolen,  :Returned,  :RecordDate,  :LastUserID,  :Comments)");
            $stm->execute(array(':cowstolen_id' => 0, ':CowDistributionID' => $CowDistributionID, ':DateStolen' => $DateStolen, ':Returned' => $Returned, ':RecordDate' => $RecordDate, ':LastUserID' => $LastUserID, ':Comments' => $Comments
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_cowdead($CowDistributionID, $DateSick, $DateDead, $ReasonDeath, $Comments, $LastUserID, $RecoredDate) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into cowdead values(:cowdead_id, :CowDistributionID,  :DateSick,  :DateDead,  :ReasonDeath,  :Comments,  :LastUserID,  :RecoredDate)");
            $stm->execute(array(':cowdead_id' => 0, ':CowDistributionID' => $CowDistributionID, ':DateSick' => $DateSick, ':DateDead' => $DateDead, ':ReasonDeath' => $ReasonDeath, ':Comments' => $Comments, ':LastUserID' => $LastUserID, ':RecoredDate' => $RecoredDate
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

}
