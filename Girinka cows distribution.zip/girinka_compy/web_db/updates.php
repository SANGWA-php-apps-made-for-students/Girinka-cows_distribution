<?php

require_once 'connection.php';
class updates{

 function update_user( $names, $user_name, $password, $type,$user_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE user set 
names= ?, user_name= ?, password= ?, type= ? WHERE user_id=?");
$stmt->execute(array($names, $user_name, $password, $type ,$user_id ));

}
 function update_cowdonor( $CowDonorName, $LastUserID, $DateRecorded,$cowdonor_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowdonor set 
CowDonorName= ?, LastUserID= ?, DateRecorded= ? WHERE cowdonor_id=?");
$stmt->execute(array($CowDonorName, $LastUserID, $DateRecorded ,$cowdonor_id ));

}
 function update_cowidentification( $TagNumber, $Color, $CowRace, $CowDonerID, $CowStatus, $LastUserID, $DateRecorded,$cowidentification_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowidentification set 
TagNumber= ?, Color= ?, CowRace= ?, CowDonerID= ?, CowStatus= ?, LastUserID= ?, DateRecorded= ? WHERE cowidentification_id=?");
$stmt->execute(array($TagNumber, $Color, $CowRace, $CowDonerID, $CowStatus, $LastUserID, $DateRecorded ,$cowidentification_id ));

}
 function update_cell( $CellName, $SectorID,$cell_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cell set 
CellName= ?, SectorID= ? WHERE cell_id=?");
$stmt->execute(array($CellName, $SectorID ,$cell_id ));

}
 function update_village( $VillageName, $CellID,$village_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE village set 
VillageName= ?, CellID= ? WHERE village_id=?");
$stmt->execute(array($VillageName, $CellID ,$village_id ));

}
 function update_sector( $SectorName,$sector_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE sector set 
SectorName= ? WHERE sector_id=?");
$stmt->execute(array($SectorName ,$sector_id ));

}
 function update_citizenshortlisted( $FirstName, $LastName, $IDNumber, $PhoneNumber, $VillageID, $UbudeheCategory, $NumberChoosen, $Comments, $Status, $RecordDate, $LastUserID,$citizenshortlisted_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE citizenshortlisted set 
FirstName= ?, LastName= ?, IDNumber= ?, PhoneNumber= ?, VillageID= ?, UbudeheCategory= ?, NumberChoosen= ?, Comments= ?, Status= ?, RecordDate= ?, LastUserID= ? WHERE citizenshortlisted_id=?");
$stmt->execute(array($FirstName, $LastName, $IDNumber, $PhoneNumber, $VillageID, $UbudeheCategory, $NumberChoosen, $Comments, $Status, $RecordDate, $LastUserID ,$citizenshortlisted_id ));

}
 function update_cowdistribution( $CitizenID, $CowID, $DateDistribution, $Comments, $LastUserID, $DateRecorded,$cowdistribution_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowdistribution set 
CitizenID= ?, CowID= ?, DateDistribution= ?, Comments= ?, LastUserID= ?, DateRecorded= ? WHERE cowdistribution_id=?");
$stmt->execute(array($CitizenID, $CowID, $DateDistribution, $Comments, $LastUserID, $DateRecorded ,$cowdistribution_id ));

}
 function update_cowborn( $CowDistributionID, $SexNewBorn, $NewBornRace, $BornDate, $NewBornEarTagNumber, $CowStatus, $DateRecorded, $LastUserID,$cowborn_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowborn set 
CowDistributionID= ?, SexNewBorn= ?, NewBornRace= ?, BornDate= ?, NewBornEarTagNumber= ?, CowStatus= ?, DateRecorded= ?, LastUserID= ? WHERE cowborn_id=?");
$stmt->execute(array($CowDistributionID, $SexNewBorn, $NewBornRace, $BornDate, $NewBornEarTagNumber, $CowStatus, $DateRecorded, $LastUserID ,$cowborn_id ));

}
 function update_newborncowdistribution( $CowBornID, $CitizenID, $DateOp, $Comments, $LastUserID, $DateRecorded,$newborncowdistribution_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE newborncowdistribution set 
CowBornID= ?, CitizenID= ?, DateOp= ?, Comments= ?, LastUserID= ?, DateRecorded= ? WHERE newborncowdistribution_id=?");
$stmt->execute(array($CowBornID, $CitizenID, $DateOp, $Comments, $LastUserID, $DateRecorded ,$newborncowdistribution_id ));

}
 function update_cowmovement( $CowDistributionID, $CitizenID, $DateMoved, $CommentsMovement, $LastUserID, $DateRecorded,$cowmovement_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowmovement set 
CowDistributionID= ?, CitizenID= ?, DateMoved= ?, CommentsMovement= ?, LastUserID= ?, DateRecorded= ? WHERE cowmovement_id=?");
$stmt->execute(array($CowDistributionID, $CitizenID, $DateMoved, $CommentsMovement, $LastUserID, $DateRecorded ,$cowmovement_id ));

}
 function update_cowtreatmentreceived( $CowDistributionID, $Symptomology, $Intervention, $Comments, $DateTreatment, $LastUserID, $RecordDate,$cowtreatmentreceived_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowtreatmentreceived set 
CowDistributionID= ?, Symptomology= ?, Intervention= ?, Comments= ?, DateTreatment= ?, LastUserID= ?, RecordDate= ? WHERE cowtreatmentreceived_id=?");
$stmt->execute(array($CowDistributionID, $Symptomology, $Intervention, $Comments, $DateTreatment, $LastUserID, $RecordDate ,$cowtreatmentreceived_id ));

}
 function update_cowsold( $CowDistributionID, $DateSold, $Redistributed, $RecordedDate, $LastUserID, $Comments,$cowsold_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowsold set 
CowDistributionID= ?, DateSold= ?, Redistributed= ?, RecordedDate= ?, LastUserID= ?, Comments= ? WHERE cowsold_id=?");
$stmt->execute(array($CowDistributionID, $DateSold, $Redistributed, $RecordedDate, $LastUserID, $Comments ,$cowsold_id ));

}
 function update_cowstolen( $CowDistributionID, $DateStolen, $Returned, $RecordDate, $LastUserID, $Comments,$cowstolen_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowstolen set 
CowDistributionID= ?, DateStolen= ?, Returned= ?, RecordDate= ?, LastUserID= ?, Comments= ? WHERE cowstolen_id=?");
$stmt->execute(array($CowDistributionID, $DateStolen, $Returned, $RecordDate, $LastUserID, $Comments ,$cowstolen_id ));

}
 function update_cowdead( $CowDistributionID, $DateSick, $DateDead, $ReasonDeath, $Comments, $LastUserID, $RecoredDate,$cowdead_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowdead set 
CowDistributionID= ?, DateSick= ?, DateDead= ?, ReasonDeath= ?, Comments= ?, LastUserID= ?, RecoredDate= ? WHERE cowdead_id=?");
$stmt->execute(array($CowDistributionID, $DateSick, $DateDead, $ReasonDeath, $Comments, $LastUserID, $RecoredDate ,$cowdead_id ));

}

}

