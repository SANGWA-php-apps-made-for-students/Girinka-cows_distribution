
--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`user_id`     int(11) NOT NULL AUTO_INCREMENT 
,`names`     VARCHAR(60) 
,`user_name`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`type`     VARCHAR(60) 

,PRIMARY KEY (`user_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowdonor`
--

CREATE TABLE IF NOT EXISTS `cowdonor` (
`CowDonerID`     VARCHAR(60) 
,`CowDonorName`     VARCHAR(60) 
, `LastUserID`     int(11)   
,`DateRecorded`     Date 

,PRIMARY KEY (`CowDonerID`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowidentification`
--

CREATE TABLE IF NOT EXISTS `cowidentification` (
`CawId`     VARCHAR(60) 
,`TagNumber`     VARCHAR(60) 
,`Color`     VARCHAR(60) 
,`CowRace`     VARCHAR(60) 
, `CowDonerID`     int(11)   
,`CowStatus`     VARCHAR(60) 
, `LastUserID`     int(11)   
,`DateRecorded`     Date 

,PRIMARY KEY (`CawId`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cell`
--

CREATE TABLE IF NOT EXISTS `cell` (
`CellID`     VARCHAR(60) 
,`CellName`     VARCHAR(60) 
, `SectorID`     int(11)   

,PRIMARY KEY (`CellID`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `village`
--

CREATE TABLE IF NOT EXISTS `village` (
`VillageID`     VARCHAR(60) 
,`VillageName`     VARCHAR(60) 
,`CellID`     VARCHAR(60) 

,PRIMARY KEY (`VillageID`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `sector`
--

CREATE TABLE IF NOT EXISTS `sector` (
`SectorID`     VARCHAR(60) 
,`SectorName`     VARCHAR(60) 

,PRIMARY KEY (`SectorID`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `citizenshortlisted`
--

CREATE TABLE IF NOT EXISTS `citizenshortlisted` (
`CitizenID`     VARCHAR(60) 
,`FirstName`     VARCHAR(60) 
,`LastName`     VARCHAR(60) 
,`IDNumber`     VARCHAR(60) 
,`PhoneNumber`     VARCHAR(60) 
, `VillageID`     int(11)   
,`UbudeheCategory`     VARCHAR(60) 
,`NumberChoosen`     VARCHAR(60) 
,`Comments`     VARCHAR(60) 
,`Status`     VARCHAR(60) 
,`RecordDate`     Date 
, `LastUserID`     int(11)   

,PRIMARY KEY (`CitizenID`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowdistribution`
--

CREATE TABLE IF NOT EXISTS `cowdistribution` (
`CowDistributionID`     VARCHAR(60) 
, `CitizenID`     int(11)   
, `CowID`     int(11)   
,`DateDistribution`     Date 
,`Comments`     VARCHAR(60) 
, `LastUserID`     int(11)   
,`DateRecorded`     Date 

,PRIMARY KEY (`CowDistributionID`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowborn`
--

CREATE TABLE IF NOT EXISTS `cowborn` (
`CowBornID`     VARCHAR(60) 
, `CowDistributionID`     int(11)   
,`SexNewBorn`     VARCHAR(60) 
,`NewBornRace`     VARCHAR(60) 
,`BornDate`     Date 
,`NewBornEarTagNumber`     VARCHAR(60) 
,`CowStatus`     VARCHAR(60) 
,`DateRecorded`     Date 
, `LastUserID`     int(11)   

,PRIMARY KEY (`CowBornID`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `newborncowdistribution`
--

CREATE TABLE IF NOT EXISTS `newborncowdistribution` (
`NewDistributionID`     VARCHAR(60) 
, `CowBornID`     int(11)   
, `CitizenID`     int(11)   
,`DateOp`     Date 
,`Comments`     VARCHAR(60) 
, `LastUserID`     int(11)   
,`DateRecorded`     Date 

,PRIMARY KEY (`NewDistributionID`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowmovement`
--

CREATE TABLE IF NOT EXISTS `cowmovement` (
`CowMovementID`     VARCHAR(60) 
, `CowDistributionID`     int(11)   
, `CitizenID`     int(11)   
,`DateMoved`     Date 
,`CommentsMovement`     VARCHAR(60) 
, `LastUserID`     int(11)   
,`DateRecorded`     Date 

,PRIMARY KEY (`CowMovementID`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowtreatmentreceived`
--

CREATE TABLE IF NOT EXISTS `cowtreatmentreceived` (
`CowTreatmentID`     VARCHAR(60) 
, `CowDistributionID`     int(11)   
,`Symptomology`     VARCHAR(60) 
,`Intervention`     VARCHAR(60) 
,`Comments`     VARCHAR(60) 
,`DateTreatment`     Date 
, `LastUserID`     int(11)   
,`RecordDate`     Date 

,PRIMARY KEY (`CowTreatmentID`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowsold`
--

CREATE TABLE IF NOT EXISTS `cowsold` (
`CowSoldID`     VARCHAR(60) 
, `CowDistributionID`     int(11)   
,`DateSold`     Date 
,`Redistributed`     VARCHAR(60) 
,`RecordedDate`     VARCHAR(60) 
, `LastUserID`     int(11)   
,`Comments`     VARCHAR(60) 

,PRIMARY KEY (`CowSoldID`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowstolen`
--

CREATE TABLE IF NOT EXISTS `cowstolen` (
`CowStolenID`     VARCHAR(60) 
, `CowDistributionID`     int(11)   
,`DateStolen`     Date 
,`Returned`     VARCHAR(60) 
,`RecordDate`     Date 
, `LastUserID`     int(11)   
,`Comments`     VARCHAR(60) 

,PRIMARY KEY (`CowStolenID`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowdead`
--

CREATE TABLE IF NOT EXISTS `cowdead` (
`CowDeadID`     VARCHAR(60) 
, `CowDistributionID`     int(11)   
,`DateSick`     Date 
,`DateDead`     Date 
,`ReasonDeath`     VARCHAR(60) 
,`Comments`     VARCHAR(60) 
, `LastUserID`     int(11)   
,`RecoredDate`     Date 

,PRIMARY KEY (`CowDeadID`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

