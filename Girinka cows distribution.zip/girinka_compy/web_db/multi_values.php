<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_user() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from user    ";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> user </td>
                    <td> names </td><td> user_name </td><td> type </td>
                    <td>Delete</td><td>Update</td></tr></thead>
            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['user_id']; ?>
                    </td>
                    <td class="names_id_cols user " title="user" >
                        <?php echo $this->_e($row['names']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['user_name']); ?>
                    </td>

                    <td>
                        <?php echo $this->_e($row['type']); ?>
                    </td>


                    <td>
                        <a href="#" class="user_delete_link" style="color: #000080;" value="
                           <?php echo $row['user_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="user_update_link" style="color: #000080;" value="
                           <?php echo $row['user_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_user_names($id) {

            $db = new dbconnection();
            $sql = "select   user.names from user where user_id=:user_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':user_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['names'];
            echo $field;
        }

        function get_chosen_user_user_name($id) {

            $db = new dbconnection();
            $sql = "select   user.user_name from user where user_id=:user_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':user_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['user_name'];
            echo $field;
        }

        function get_chosen_user_password($id) {

            $db = new dbconnection();
            $sql = "select   user.password from user where user_id=:user_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':user_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['password'];
            echo $field;
        }

        function get_chosen_user_type($id) {

            $db = new dbconnection();
            $sql = "select   user.type from user where user_id=:user_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':user_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['type'];
            echo $field;
        }

        function All_user() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  user_id   from user";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_user() {
            $con = new dbconnection();
            $sql = "select user.user_id from user
                    order by user.user_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['user_id'];
            return $first_rec;
        }

        function get_last_user() {
            $con = new dbconnection();
            $sql = "select user.user_id from user
                    order by user.user_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['user_id'];
            return $first_rec;
        }

        function list_cowdonor() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from cowdonor  ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> cowdonor </td>
                    <td> CowDonorName </td><td> LastUserID </td><td> DateRecorded </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['CowDonerID']; ?>
                    </td>
                    <td class="CowDonorName_id_cols cowdonor " title="cowdonor" >
                        <?php echo $this->_e($row['CowDonorName']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['LastUserID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateRecorded']); ?>
                    </td>


                    <td>
                        <a href="#" class="cowdonor_delete_link" style="color: #000080;" value="
                           <?php echo $row['CowDonerID']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cowdonor_update_link" style="color: #000080;" value="
                           <?php echo $row['CowDonerID']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_cowdonor_CowDonorName($id) {

            $db = new dbconnection();
            $sql = "select   cowdonor.CowDonorName from cowdonor where cowdonor_id=:cowdonor_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdonor_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CowDonorName'];
            echo $field;
        }

        function get_chosen_cowdonor_LastUserID($id) {

            $db = new dbconnection();
            $sql = "select   cowdonor.LastUserID from cowdonor where cowdonor_id=:cowdonor_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdonor_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['LastUserID'];
            echo $field;
        }

        function get_chosen_cowdonor_DateRecorded($id) {

            $db = new dbconnection();
            $sql = "select   cowdonor.DateRecorded from cowdonor where cowdonor_id=:cowdonor_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdonor_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateRecorded'];
            echo $field;
        }

        function All_cowdonor() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  CowDonerID   from cowdonor";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cowdonor() {
            $con = new dbconnection();
            $sql = "select cowdonor.cowdonor_id from cowdonor
                    order by cowdonor.cowdonor_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowdonor_id'];
            return $first_rec;
        }

        function get_last_cowdonor() {
            $con = new dbconnection();
            $sql = "select cowdonor.cowdonor_id from cowdonor
                    order by cowdonor.cowdonor_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowdonor_id'];
            return $first_rec;
        }

        function list_cowidentification() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from cowidentification ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> ID </td>
                    <td> TagNumber </td><td> Color </td>
                    <td> CowRace </td><td> DonerID </td>
                    <td> Status </td><td> LastUserID </td><td> DateRecorded </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['CawId']; ?>
                    </td>
                    <td class="TagNumber_id_cols cowidentification " title="cowidentification" >
                        <?php echo $this->_e($row['TagNumber']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['Color']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['CowRace']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['CowDonerID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['CowStatus']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['LastUserID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateRecorded']); ?>
                    </td>


                    <td>
                        <a href="#" class="cowidentification_delete_link" style="color: #000080;" value="
                           <?php echo $row['CawId']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cowidentification_update_link" style="color: #000080;" value="
                           <?php echo $row['CawId']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_cowidentification_TagNumber($id) {

            $db = new dbconnection();
            $sql = "select   cowidentification.TagNumber from cowidentification where cowidentification_id=:cowidentification_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowidentification_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['TagNumber'];
            echo $field;
        }

        function get_chosen_cowidentification_Color($id) {

            $db = new dbconnection();
            $sql = "select   cowidentification.Color from cowidentification where cowidentification_id=:cowidentification_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowidentification_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Color'];
            echo $field;
        }

        function get_chosen_cowidentification_CowRace($id) {

            $db = new dbconnection();
            $sql = "select   cowidentification.CowRace from cowidentification where cowidentification_id=:cowidentification_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowidentification_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CowRace'];
            echo $field;
        }

        function get_chosen_cowidentification_CowDonerID($id) {

            $db = new dbconnection();
            $sql = "select   cowidentification.CowDonerID from cowidentification where cowidentification_id=:cowidentification_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowidentification_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CowDonerID'];
            echo $field;
        }

        function get_chosen_cowidentification_CowStatus($id) {

            $db = new dbconnection();
            $sql = "select   cowidentification.CowStatus from cowidentification where cowidentification_id=:cowidentification_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowidentification_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CowStatus'];
            echo $field;
        }

        function get_chosen_cowidentification_LastUserID($id) {

            $db = new dbconnection();
            $sql = "select   cowidentification.LastUserID from cowidentification where cowidentification_id=:cowidentification_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowidentification_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['LastUserID'];
            echo $field;
        }

        function get_chosen_cowidentification_DateRecorded($id) {

            $db = new dbconnection();
            $sql = "select   cowidentification.DateRecorded from cowidentification where cowidentification_id=:cowidentification_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowidentification_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateRecorded'];
            echo $field;
        }

        function All_cowidentification() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  CawId   from cowidentification";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cowidentification() {
            $con = new dbconnection();
            $sql = "select cowidentification.cowidentification_id from cowidentification
                    order by cowidentification.cowidentification_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowidentification_id'];
            return $first_rec;
        }

        function get_last_cowidentification() {
            $con = new dbconnection();
            $sql = "select cowidentification.cowidentification_id from cowidentification
                    order by cowidentification.cowidentification_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowidentification_id'];
            return $first_rec;
        }

        function list_cell() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from cell  ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> cell </td>
                    <td> CellName </td><td> SectorID </td>
                    <td>Delete</td><td>Update</td></tr></thead>
            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 
                    <td>
                        <?php echo $row['CellID']; ?>
                    </td>
                    <td class="CellName_id_cols cell " title="cell" >
                        <?php echo $this->_e($row['CellName']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['SectorID']); ?>
                    </td>
                    <td>
                        <a href="#" class="cell_delete_link" style="color: #000080;" value="
                           <?php echo $row['CellID']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cell_update_link" style="color: #000080;" value="
                           <?php echo $row['CellID']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_cell_CellName($id) {

            $db = new dbconnection();
            $sql = "select   cell.CellName from cell where cell_id=:cell_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cell_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CellName'];
            echo $field;
        }

        function get_chosen_cell_SectorID($id) {

            $db = new dbconnection();
            $sql = "select   cell.SectorID from cell where cell_id=:cell_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cell_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['SectorID'];
            echo $field;
        }

        function All_cell() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  cell_id   from cell";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cell() {
            $con = new dbconnection();
            $sql = "select cell.cell_id from cell
                    order by cell.cell_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cell_id'];
            return $first_rec;
        }

        function get_last_cell() {
            $con = new dbconnection();
            $sql = "select cell.cell_id from cell
                    order by cell.cell_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cell_id'];
            return $first_rec;
        }

        function list_village() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from village ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> village </td>
                    <td> VillageName </td><td> CellID </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['VillageID']; ?>
                    </td>
                    <td class="VillageName_id_cols village " title="village" >
                        <?php echo $this->_e($row['VillageName']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['CellID']); ?>
                    </td>


                    <td>
                        <a href="#" class="village_delete_link" style="color: #000080;" value="
                           <?php echo $row['village_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="village_update_link" style="color: #000080;" value="
                           <?php echo $row['village_id']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_village_VillageName($id) {

            $db = new dbconnection();
            $sql = "select   village.VillageName from village where village_id=:village_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':village_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['VillageName'];
            echo $field;
        }

        function get_chosen_village_CellID($id) {

            $db = new dbconnection();
            $sql = "select   village.CellID from village where village_id=:village_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':village_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CellID'];
            echo $field;
        }

        function All_village() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  village_id   from village";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_village() {
            $con = new dbconnection();
            $sql = "select village.village_id from village
                    order by village.village_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['village_id'];
            return $first_rec;
        }

        function get_last_village() {
            $con = new dbconnection();
            $sql = "select village.village_id from village
                    order by village.village_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['village_id'];
            return $first_rec;
        }

        function list_sector() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from sector ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> sector </td>
                    <td> SectorName </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['SectorID']; ?>
                    </td>
                    <td class="SectorName_id_cols sector " title="sector" >
                        <?php echo $this->_e($row['SectorName']); ?>
                    </td>

                    <td>
                        <a href="#" class="sector_delete_link" style="color: #000080;" value="
                           <?php echo $row['SectorID']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="sector_update_link" style="color: #000080;" value="
                           <?php echo $row['SectorID']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_sector_SectorName($id) {

            $db = new dbconnection();
            $sql = "select   sector.SectorName from sector where sector_id=:sector_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':sector_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['SectorName'];
            echo $field;
        }

        function All_sector() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  SectorID   from sector";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_sector() {
            $con = new dbconnection();
            $sql = "select sector.sector_id from sector
                    order by sector.sector_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['sector_id'];
            return $first_rec;
        }

        function get_last_sector() {
            $con = new dbconnection();
            $sql = "select sector.sector_id from sector
                    order by sector.sector_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['sector_id'];
            return $first_rec;
        }

        function list_citizenshortlisted() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from citizenshortlisted ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> citizenshortlisted </td>
                    <td> FirstName </td><td> LastName </td><td> IDNumber </td>
                    <td> PhoneNumber </td><td> VillageID </td>

                    <td> LastUserID </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['CitizenID']; ?>
                    </td>
                    <td class="FirstName_id_cols citizenshortlisted " title="citizenshortlisted" >
                        <?php echo $this->_e($row['FirstName']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['LastName']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['IDNumber']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['PhoneNumber']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['VillageID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['LastUserID']); ?>
                    </td>

                    <td>
                        <a href="#" class="citizenshortlisted_delete_link" style="color: #000080;" value="
                           <?php echo $row['CitizenID']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="citizenshortlisted_update_link" style="color: #000080;" value="
                           <?php echo $row['CitizenID']; ?>">Update</a>
                    </td>
                </tr>
                <tr>
                    <td colspan="9">
                        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                            Comment:
                            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">

                                <?php $this->get_comment_by_citizen($row['CitizenID']) ?>
                            </div>       
                        </div>
                    </td>
                </tr>
                <tr class="Details_row">
                    <td colspan="9"> 
                        <div class="parts full_center_two_h heit_free more_onCitizen no_paddin_shade_no_Border">
                            <a href="#">More details for <?php echo $row['FirstName'] ?></a>
                            <span class="parts full_center_two_h heit_free no_shade_noBorder off">
                                <table>
                                    <tr><td> Status </td>
                                        <td> RecordDate </td>
                                        <td> UbudeheCategory </td>
                                        <td> Chosen number </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <?php echo $this->_e($row['Status']); ?>
                                        </td>
                                        <td>
                                            <?php echo $this->_e($row['RecordDate']); ?>
                                        </td>                    
                                        <td>
                                            <?php echo $this->_e($row['UbudeheCategory']); ?>
                                        </td>
                                        <td>
                                            <?php echo $this->_e($row['NumberChoosen']); ?>
                                        </td>
                                    </tr>
                                </table>
                            </span>
                        </div>
                    </td>
                </tr>

                <?php
                $pages+=1;
            }
            ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_citizenshortlisted_FirstName($id) {

        $db = new dbconnection();
        $sql = "select   citizenshortlisted.FirstName from citizenshortlisted where citizenshortlisted_id=:citizenshortlisted_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':citizenshortlisted_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['FirstName'];
        echo $field;
    }

    function get_chosen_citizenshortlisted_LastName($id) {

        $db = new dbconnection();
        $sql = "select   citizenshortlisted.LastName from citizenshortlisted where citizenshortlisted_id=:citizenshortlisted_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':citizenshortlisted_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['LastName'];
        echo $field;
    }

    function get_chosen_citizenshortlisted_IDNumber($id) {

        $db = new dbconnection();
        $sql = "select   citizenshortlisted.IDNumber from citizenshortlisted where citizenshortlisted_id=:citizenshortlisted_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':citizenshortlisted_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['IDNumber'];
        echo $field;
    }

    function get_chosen_citizenshortlisted_PhoneNumber($id) {

        $db = new dbconnection();
        $sql = "select   citizenshortlisted.PhoneNumber from citizenshortlisted where citizenshortlisted_id=:citizenshortlisted_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':citizenshortlisted_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['PhoneNumber'];
        echo $field;
    }

    function get_chosen_citizenshortlisted_VillageID($id) {

        $db = new dbconnection();
        $sql = "select   citizenshortlisted.VillageID from citizenshortlisted where citizenshortlisted_id=:citizenshortlisted_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':citizenshortlisted_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['VillageID'];
        echo $field;
    }

    function get_chosen_citizenshortlisted_UbudeheCategory($id) {

        $db = new dbconnection();
        $sql = "select   citizenshortlisted.UbudeheCategory from citizenshortlisted where citizenshortlisted_id=:citizenshortlisted_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':citizenshortlisted_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['UbudeheCategory'];
        echo $field;
    }

    function get_chosen_citizenshortlisted_NumberChoosen($id) {

        $db = new dbconnection();
        $sql = "select   citizenshortlisted.NumberChoosen from citizenshortlisted where citizenshortlisted_id=:citizenshortlisted_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':citizenshortlisted_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['NumberChoosen'];
        echo $field;
    }

    function get_chosen_citizenshortlisted_Comments($id) {

        $db = new dbconnection();
        $sql = "select   citizenshortlisted.Comments from citizenshortlisted where citizenshortlisted_id=:citizenshortlisted_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':citizenshortlisted_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['Comments'];
        echo $field;
    }

    function get_chosen_citizenshortlisted_Status($id) {

        $db = new dbconnection();
        $sql = "select   citizenshortlisted.Status from citizenshortlisted where citizenshortlisted_id=:citizenshortlisted_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':citizenshortlisted_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['Status'];
        echo $field;
    }

    function get_chosen_citizenshortlisted_RecordDate($id) {

        $db = new dbconnection();
        $sql = "select   citizenshortlisted.RecordDate from citizenshortlisted where citizenshortlisted_id=:citizenshortlisted_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':citizenshortlisted_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['RecordDate'];
        echo $field;
    }

    function get_chosen_citizenshortlisted_LastUserID($id) {

        $db = new dbconnection();
        $sql = "select   citizenshortlisted.LastUserID from citizenshortlisted where citizenshortlisted_id=:citizenshortlisted_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':citizenshortlisted_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['LastUserID'];
        echo $field;
    }

    function All_citizenshortlisted() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  CitizenID   from citizenshortlisted";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }

    function get_first_citizenshortlisted() {
        $con = new dbconnection();
        $sql = "select citizenshortlisted.citizenshortlisted_id from citizenshortlisted
                    order by citizenshortlisted.citizenshortlisted_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['citizenshortlisted_id'];
        return $first_rec;
    }

    function get_last_citizenshortlisted() {
        $con = new dbconnection();
        $sql = "select citizenshortlisted.citizenshortlisted_id from citizenshortlisted
                    order by citizenshortlisted.citizenshortlisted_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['citizenshortlisted_id'];
        return $first_rec;
    }

    function list_cowdistribution() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from CowDistributionID ";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> cowdistribution </td>
                    <td> CitizenID </td><td> CowID </td><td> DateDistribution </td><td> Comments </td><td> LastUserID </td><td> DateRecorded </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['CowDistributionID']; ?>
                    </td>
                    <td class="CitizenID_id_cols cowdistribution " title="cowdistribution" >
                        <?php echo $this->_e($row['CitizenID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['CowID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateDistribution']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['Comments']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['LastUserID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateRecorded']); ?>
                    </td>

                    <td>
                        <a href="#" class="cowdistribution_delete_link" style="color: #000080;" value="
                           <?php echo $row['CowDistributionID']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cowdistribution_update_link" style="color: #000080;" value="
                           <?php echo $row['CowDistributionID']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_cowdistribution_CitizenID($id) {

            $db = new dbconnection();
            $sql = "select   cowdistribution.CitizenID from cowdistribution where cowdistribution_id=:cowdistribution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdistribution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CitizenID'];
            echo $field;
        }

        function get_chosen_cowdistribution_CowID($id) {

            $db = new dbconnection();
            $sql = "select   cowdistribution.CowID from cowdistribution where cowdistribution_id=:cowdistribution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdistribution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CowID'];
            echo $field;
        }

        function get_chosen_cowdistribution_DateDistribution($id) {

            $db = new dbconnection();
            $sql = "select   cowdistribution.DateDistribution from cowdistribution where cowdistribution_id=:cowdistribution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdistribution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateDistribution'];
            echo $field;
        }

        function get_chosen_cowdistribution_Comments($id) {

            $db = new dbconnection();
            $sql = "select   cowdistribution.Comments from cowdistribution where cowdistribution_id=:cowdistribution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdistribution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Comments'];
            echo $field;
        }

        function get_chosen_cowdistribution_LastUserID($id) {

            $db = new dbconnection();
            $sql = "select   cowdistribution.LastUserID from cowdistribution where cowdistribution_id=:cowdistribution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdistribution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['LastUserID'];
            echo $field;
        }

        function get_chosen_cowdistribution_DateRecorded($id) {

            $db = new dbconnection();
            $sql = "select   cowdistribution.DateRecorded from cowdistribution where cowdistribution_id=:cowdistribution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdistribution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateRecorded'];
            echo $field;
        }

        function All_cowdistribution() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  CowDistributionID   from cowdistribution";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cowdistribution() {
            $con = new dbconnection();
            $sql = "select cowdistribution.cowdistribution_id from cowdistribution
                    order by cowdistribution.cowdistribution_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowdistribution_id'];
            return $first_rec;
        }

        function get_last_cowdistribution() {
            $con = new dbconnection();
            $sql = "select cowdistribution.cowdistribution_id from cowdistribution
                    order by cowdistribution.cowdistribution_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowdistribution_id'];
            return $first_rec;
        }

        function list_cowborn() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from cowborn ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> cowborn </td>
                    <td> CowDistributionID </td><td> SexNewBorn </td><td> NewBornRace </td><td> BornDate </td><td> NewBornEarTagNumber </td><td> CowStatus </td><td> DateRecorded </td><td> LastUserID </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 
                    <td>
                        <?php echo $row['CowBornID']; ?>
                    </td>
                    <td class="CowDistributionID_id_cols cowborn " title="cowborn" >
                        <?php echo $this->_e($row['CowDistributionID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['SexNewBorn']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['NewBornRace']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['BornDate']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['NewBornEarTagNumber']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['CowStatus']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateRecorded']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['LastUserID']); ?>
                    </td>


                    <td>
                        <a href="#" class="cowborn_delete_link" style="color: #000080;" value="
                           <?php echo $row['CowBornID']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cowborn_update_link" style="color: #000080;" value="
                           <?php echo $row['CowBornID']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_cowborn_CowDistributionID($id) {

            $db = new dbconnection();
            $sql = "select   cowborn.CowDistributionID from cowborn where cowborn_id=:cowborn_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowborn_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CowDistributionID'];
            echo $field;
        }

        function get_chosen_cowborn_SexNewBorn($id) {

            $db = new dbconnection();
            $sql = "select   cowborn.SexNewBorn from cowborn where cowborn_id=:cowborn_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowborn_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['SexNewBorn'];
            echo $field;
        }

        function get_chosen_cowborn_NewBornRace($id) {

            $db = new dbconnection();
            $sql = "select   cowborn.NewBornRace from cowborn where cowborn_id=:cowborn_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowborn_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['NewBornRace'];
            echo $field;
        }

        function get_chosen_cowborn_BornDate($id) {

            $db = new dbconnection();
            $sql = "select   cowborn.BornDate from cowborn where cowborn_id=:cowborn_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowborn_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['BornDate'];
            echo $field;
        }

        function get_chosen_cowborn_NewBornEarTagNumber($id) {

            $db = new dbconnection();
            $sql = "select   cowborn.NewBornEarTagNumber from cowborn where cowborn_id=:cowborn_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowborn_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['NewBornEarTagNumber'];
            echo $field;
        }

        function get_chosen_cowborn_CowStatus($id) {

            $db = new dbconnection();
            $sql = "select   cowborn.CowStatus from cowborn where cowborn_id=:cowborn_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowborn_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CowStatus'];
            echo $field;
        }

        function get_chosen_cowborn_DateRecorded($id) {

            $db = new dbconnection();
            $sql = "select   cowborn.DateRecorded from cowborn where cowborn_id=:cowborn_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowborn_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateRecorded'];
            echo $field;
        }

        function get_chosen_cowborn_LastUserID($id) {

            $db = new dbconnection();
            $sql = "select   cowborn.LastUserID from cowborn where cowborn_id=:cowborn_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowborn_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['LastUserID'];
            echo $field;
        }

        function All_cowborn() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  CowBornID   from cowborn";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cowborn() {
            $con = new dbconnection();
            $sql = "select cowborn.cowborn_id from cowborn
                    order by cowborn.cowborn_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowborn_id'];
            return $first_rec;
        }

        function get_last_cowborn() {
            $con = new dbconnection();
            $sql = "select cowborn.cowborn_id from cowborn
                    order by cowborn.cowborn_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowborn_id'];
            return $first_rec;
        }

        function list_newborncowdistribution() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from newborncowdistribution ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> newborncowdistribution </td>
                    <td> CowBornID </td><td> CitizenID </td><td> DateOp </td><td> Comments </td><td> LastUserID </td><td> DateRecorded </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 
                    <td>
                        <?php echo $row['NewDistributionID']; ?>
                    </td>
                    <td class="CowBornID_id_cols newborncowdistribution " title="newborncowdistribution" >
                        <?php echo $this->_e($row['CowBornID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['CitizenID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateOp']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['Comments']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['LastUserID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateRecorded']); ?>
                    </td>


                    <td>
                        <a href="#" class="newborncowdistribution_delete_link" style="color: #000080;" value="
                           <?php echo $row['NewDistributionID']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="newborncowdistribution_update_link" style="color: #000080;" value="
                           <?php echo $row['NewDistributionID']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_newborncowdistribution_CowBornID($id) {

            $db = new dbconnection();
            $sql = "select   newborncowdistribution.CowBornID from newborncowdistribution where newborncowdistribution_id=:newborncowdistribution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':newborncowdistribution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CowBornID'];
            echo $field;
        }

        function get_chosen_newborncowdistribution_CitizenID($id) {

            $db = new dbconnection();
            $sql = "select   newborncowdistribution.CitizenID from newborncowdistribution where newborncowdistribution_id=:newborncowdistribution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':newborncowdistribution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CitizenID'];
            echo $field;
        }

        function get_chosen_newborncowdistribution_DateOp($id) {

            $db = new dbconnection();
            $sql = "select   newborncowdistribution.DateOp from newborncowdistribution where newborncowdistribution_id=:newborncowdistribution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':newborncowdistribution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateOp'];
            echo $field;
        }

        function get_chosen_newborncowdistribution_Comments($id) {

            $db = new dbconnection();
            $sql = "select   newborncowdistribution.Comments from newborncowdistribution where newborncowdistribution_id=:newborncowdistribution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':newborncowdistribution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Comments'];
            echo $field;
        }

        function get_chosen_newborncowdistribution_LastUserID($id) {

            $db = new dbconnection();
            $sql = "select   newborncowdistribution.LastUserID from newborncowdistribution where newborncowdistribution_id=:newborncowdistribution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':newborncowdistribution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['LastUserID'];
            echo $field;
        }

        function get_chosen_newborncowdistribution_DateRecorded($id) {

            $db = new dbconnection();
            $sql = "select   newborncowdistribution.DateRecorded from newborncowdistribution where newborncowdistribution_id=:newborncowdistribution_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':newborncowdistribution_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateRecorded'];
            echo $field;
        }

        function All_newborncowdistribution() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  NewDistributionID   from newborncowdistribution";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_newborncowdistribution() {
            $con = new dbconnection();
            $sql = "select newborncowdistribution.newborncowdistribution_id from newborncowdistribution
                    order by newborncowdistribution.newborncowdistribution_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['newborncowdistribution_id'];
            return $first_rec;
        }

        function get_last_newborncowdistribution() {
            $con = new dbconnection();
            $sql = "select newborncowdistribution.newborncowdistribution_id from newborncowdistribution
                    order by newborncowdistribution.newborncowdistribution_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['newborncowdistribution_id'];
            return $first_rec;
        }

        function list_cowmovement() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from cowmovement ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> cowmovement </td>
                    <td> CowDistributionID </td><td> CitizenID </td><td> DateMoved </td><td> CommentsMovement </td><td> LastUserID </td><td> DateRecorded </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['CowMovementID']; ?>
                    </td>
                    <td class="CowDistributionID_id_cols cowmovement " title="cowmovement" >
                        <?php echo $this->_e($row['CowDistributionID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['CitizenID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateMoved']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['CommentsMovement']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['LastUserID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateRecorded']); ?>
                    </td>
                    <td>
                        <a href="#" class="cowmovement_delete_link" style="color: #000080;" value="
                           <?php echo $row['CowMovementID']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cowmovement_update_link" style="color: #000080;" value="
                           <?php echo $row['CowMovementID']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_cowmovement_CowDistributionID($id) {

            $db = new dbconnection();
            $sql = "select   cowmovement.CowDistributionID from cowmovement where cowmovement_id=:cowmovement_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowmovement_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CowDistributionID'];
            echo $field;
        }

        function get_chosen_cowmovement_CitizenID($id) {

            $db = new dbconnection();
            $sql = "select   cowmovement.CitizenID from cowmovement where cowmovement_id=:cowmovement_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowmovement_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CitizenID'];
            echo $field;
        }

        function get_chosen_cowmovement_DateMoved($id) {

            $db = new dbconnection();
            $sql = "select   cowmovement.DateMoved from cowmovement where cowmovement_id=:cowmovement_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowmovement_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateMoved'];
            echo $field;
        }

        function get_chosen_cowmovement_CommentsMovement($id) {

            $db = new dbconnection();
            $sql = "select   cowmovement.CommentsMovement from cowmovement where cowmovement_id=:cowmovement_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowmovement_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CommentsMovement'];
            echo $field;
        }

        function get_chosen_cowmovement_LastUserID($id) {

            $db = new dbconnection();
            $sql = "select   cowmovement.LastUserID from cowmovement where cowmovement_id=:cowmovement_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowmovement_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['LastUserID'];
            echo $field;
        }

        function get_chosen_cowmovement_DateRecorded($id) {

            $db = new dbconnection();
            $sql = "select   cowmovement.DateRecorded from cowmovement where cowmovement_id=:cowmovement_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowmovement_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateRecorded'];
            echo $field;
        }

        function All_cowmovement() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  CowMovementID   from cowmovement";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cowmovement() {
            $con = new dbconnection();
            $sql = "select cowmovement.cowmovement_id from cowmovement
                    order by cowmovement.cowmovement_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowmovement_id'];
            return $first_rec;
        }

        function get_last_cowmovement() {
            $con = new dbconnection();
            $sql = "select cowmovement.cowmovement_id from cowmovement
                    order by cowmovement.cowmovement_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowmovement_id'];
            return $first_rec;
        }

        function list_cowtreatmentreceived() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from cowtreatmentreceived  ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> cowtreatmentreceived </td>
                    <td> CowDistributionID </td><td> Symptomology </td><td> Intervention </td><td> Comments </td><td> DateTreatment </td><td> LastUserID </td><td> RecordDate </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['CowTreatmentID']; ?>
                    </td>
                    <td class="CowDistributionID_id_cols cowtreatmentreceived " title="cowtreatmentreceived" >
                        <?php echo $this->_e($row['CowDistributionID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['Symptomology']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['Intervention']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['Comments']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateTreatment']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['LastUserID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['RecordDate']); ?>
                    </td>


                    <td>
                        <a href="#" class="cowtreatmentreceived_delete_link" style="color: #000080;" value="
                           <?php echo $row['CowTreatmentID']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cowtreatmentreceived_update_link" style="color: #000080;" value="
                           <?php echo $row['CowTreatmentID']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_cowtreatmentreceived_CowDistributionID($id) {

            $db = new dbconnection();
            $sql = "select   cowtreatmentreceived.CowDistributionID from cowtreatmentreceived where cowtreatmentreceived_id=:cowtreatmentreceived_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowtreatmentreceived_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CowDistributionID'];
            echo $field;
        }

        function get_chosen_cowtreatmentreceived_Symptomology($id) {

            $db = new dbconnection();
            $sql = "select   cowtreatmentreceived.Symptomology from cowtreatmentreceived where cowtreatmentreceived_id=:cowtreatmentreceived_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowtreatmentreceived_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Symptomology'];
            echo $field;
        }

        function get_chosen_cowtreatmentreceived_Intervention($id) {

            $db = new dbconnection();
            $sql = "select   cowtreatmentreceived.Intervention from cowtreatmentreceived where cowtreatmentreceived_id=:cowtreatmentreceived_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowtreatmentreceived_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Intervention'];
            echo $field;
        }

        function get_chosen_cowtreatmentreceived_Comments($id) {

            $db = new dbconnection();
            $sql = "select   cowtreatmentreceived.Comments from cowtreatmentreceived where cowtreatmentreceived_id=:cowtreatmentreceived_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowtreatmentreceived_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Comments'];
            echo $field;
        }

        function get_chosen_cowtreatmentreceived_DateTreatment($id) {

            $db = new dbconnection();
            $sql = "select   cowtreatmentreceived.DateTreatment from cowtreatmentreceived where cowtreatmentreceived_id=:cowtreatmentreceived_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowtreatmentreceived_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateTreatment'];
            echo $field;
        }

        function get_chosen_cowtreatmentreceived_LastUserID($id) {

            $db = new dbconnection();
            $sql = "select   cowtreatmentreceived.LastUserID from cowtreatmentreceived where cowtreatmentreceived_id=:cowtreatmentreceived_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowtreatmentreceived_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['LastUserID'];
            echo $field;
        }

        function get_chosen_cowtreatmentreceived_RecordDate($id) {

            $db = new dbconnection();
            $sql = "select   cowtreatmentreceived.RecordDate from cowtreatmentreceived where cowtreatmentreceived_id=:cowtreatmentreceived_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowtreatmentreceived_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['RecordDate'];
            echo $field;
        }

        function All_cowtreatmentreceived() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  CowTreatmentID   from cowtreatmentreceived";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cowtreatmentreceived() {
            $con = new dbconnection();
            $sql = "select cowtreatmentreceived.cowtreatmentreceived_id from cowtreatmentreceived
                    order by cowtreatmentreceived.cowtreatmentreceived_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowtreatmentreceived_id'];
            return $first_rec;
        }

        function get_last_cowtreatmentreceived() {
            $con = new dbconnection();
            $sql = "select cowtreatmentreceived.cowtreatmentreceived_id from cowtreatmentreceived
                    order by cowtreatmentreceived.cowtreatmentreceived_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowtreatmentreceived_id'];
            return $first_rec;
        }

        function list_cowsold() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from cowsold ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> cowsold </td>
                    <td> CowDistributionID </td><td> DateSold </td><td> Redistributed </td><td> RecordedDate </td><td> LastUserID </td><td> Comments </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['CowSoldID']; ?>
                    </td>
                    <td class="CowDistributionID_id_cols cowsold " title="cowsold" >
                        <?php echo $this->_e($row['CowDistributionID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateSold']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['Redistributed']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['RecordedDate']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['LastUserID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['Comments']); ?>
                    </td>


                    <td>
                        <a href="#" class="cowsold_delete_link" style="color: #000080;" value="
                           <?php echo $row['CowSoldID']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cowsold_update_link" style="color: #000080;" value="
                           <?php echo $row['CowSoldID']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_cowsold_CowDistributionID($id) {

            $db = new dbconnection();
            $sql = "select   cowsold.CowDistributionID from cowsold where cowsold_id=:cowsold_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowsold_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CowDistributionID'];
            echo $field;
        }

        function get_chosen_cowsold_DateSold($id) {

            $db = new dbconnection();
            $sql = "select   cowsold.DateSold from cowsold where cowsold_id=:cowsold_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowsold_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateSold'];
            echo $field;
        }

        function get_chosen_cowsold_Redistributed($id) {

            $db = new dbconnection();
            $sql = "select   cowsold.Redistributed from cowsold where cowsold_id=:cowsold_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowsold_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Redistributed'];
            echo $field;
        }

        function get_chosen_cowsold_RecordedDate($id) {

            $db = new dbconnection();
            $sql = "select   cowsold.RecordedDate from cowsold where cowsold_id=:cowsold_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowsold_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['RecordedDate'];
            echo $field;
        }

        function get_chosen_cowsold_LastUserID($id) {

            $db = new dbconnection();
            $sql = "select   cowsold.LastUserID from cowsold where cowsold_id=:cowsold_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowsold_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['LastUserID'];
            echo $field;
        }

        function get_chosen_cowsold_Comments($id) {

            $db = new dbconnection();
            $sql = "select   cowsold.Comments from cowsold where cowsold_id=:cowsold_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowsold_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Comments'];
            echo $field;
        }

        function All_cowsold() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  CowSoldID   from cowsold";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cowsold() {
            $con = new dbconnection();
            $sql = "select cowsold.cowsold_id from cowsold
                    order by cowsold.cowsold_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowsold_id'];
            return $first_rec;
        }

        function get_last_cowsold() {
            $con = new dbconnection();
            $sql = "select cowsold.cowsold_id from cowsold
                    order by cowsold.cowsold_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowsold_id'];
            return $first_rec;
        }

        function list_cowstolen() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from cowstolen ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> cowstolen </td>
                    <td> CowDistributionID </td><td> DateStolen </td><td> Returned </td><td> RecordDate </td><td> LastUserID </td><td> Comments </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['CowStolenID']; ?>
                    </td>
                    <td class="CowDistributionID_id_cols cowstolen " title="cowstolen" >
                        <?php echo $this->_e($row['CowDistributionID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateStolen']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['Returned']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['RecordDate']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['LastUserID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['Comments']); ?>
                    </td>


                    <td>
                        <a href="#" class="cowstolen_delete_link" style="color: #000080;" value="
                           <?php echo $row['CowStolenID']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cowstolen_update_link" style="color: #000080;" value="
                           <?php echo $row['CowStolenID']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_cowstolen_CowDistributionID($id) {

            $db = new dbconnection();
            $sql = "select   cowstolen.CowDistributionID from cowstolen where cowstolen_id=:cowstolen_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowstolen_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CowDistributionID'];
            echo $field;
        }

        function get_chosen_cowstolen_DateStolen($id) {

            $db = new dbconnection();
            $sql = "select   cowstolen.DateStolen from cowstolen where cowstolen_id=:cowstolen_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowstolen_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateStolen'];
            echo $field;
        }

        function get_chosen_cowstolen_Returned($id) {

            $db = new dbconnection();
            $sql = "select   cowstolen.Returned from cowstolen where cowstolen_id=:cowstolen_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowstolen_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Returned'];
            echo $field;
        }

        function get_chosen_cowstolen_RecordDate($id) {

            $db = new dbconnection();
            $sql = "select   cowstolen.RecordDate from cowstolen where cowstolen_id=:cowstolen_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowstolen_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['RecordDate'];
            echo $field;
        }

        function get_chosen_cowstolen_LastUserID($id) {

            $db = new dbconnection();
            $sql = "select   cowstolen.LastUserID from cowstolen where cowstolen_id=:cowstolen_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowstolen_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['LastUserID'];
            echo $field;
        }

        function get_chosen_cowstolen_Comments($id) {

            $db = new dbconnection();
            $sql = "select   cowstolen.Comments from cowstolen where cowstolen_id=:cowstolen_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowstolen_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Comments'];
            echo $field;
        }

        function All_cowstolen() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  CowStolenID   from cowstolen";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cowstolen() {
            $con = new dbconnection();
            $sql = "select cowstolen.cowstolen_id from cowstolen
                    order by cowstolen.cowstolen_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowstolen_id'];
            return $first_rec;
        }

        function get_last_cowstolen() {
            $con = new dbconnection();
            $sql = "select cowstolen.cowstolen_id from cowstolen
                    order by cowstolen.cowstolen_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowstolen_id'];
            return $first_rec;
        }

        function list_cowdead() {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from cowdead  ";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> cowdead </td>
                    <td> CowDistributionID </td><td> DateSick </td><td> DateDead </td><td> ReasonDeath </td><td> Comments </td><td> LastUserID </td><td> RecoredDate </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['CowDeadID']; ?>
                    </td>
                    <td class="CowDistributionID_id_cols cowdead " title="cowdead" >
                        <?php echo $this->_e($row['CowDistributionID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateSick']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['DateDead']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['ReasonDeath']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['Comments']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['LastUserID']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['RecoredDate']); ?>
                    </td>


                    <td>
                        <a href="#" class="cowdead_delete_link" style="color: #000080;" value="
                           <?php echo $row['CowDeadID']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="cowdead_update_link" style="color: #000080;" value="
                           <?php echo $row['CowDeadID']; ?>">Update</a>
                    </td></tr>
                <?php
                $pages+=1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_cowdead_CowDistributionID($id) {

            $db = new dbconnection();
            $sql = "select   cowdead.CowDistributionID from cowdead where cowdead_id=:cowdead_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdead_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['CowDistributionID'];
            echo $field;
        }

        function get_chosen_cowdead_DateSick($id) {

            $db = new dbconnection();
            $sql = "select   cowdead.DateSick from cowdead where cowdead_id=:cowdead_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdead_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateSick'];
            echo $field;
        }

        function get_chosen_cowdead_DateDead($id) {

            $db = new dbconnection();
            $sql = "select   cowdead.DateDead from cowdead where cowdead_id=:cowdead_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdead_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['DateDead'];
            echo $field;
        }

        function get_chosen_cowdead_ReasonDeath($id) {

            $db = new dbconnection();
            $sql = "select   cowdead.ReasonDeath from cowdead where cowdead_id=:cowdead_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdead_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['ReasonDeath'];
            echo $field;
        }

        function get_chosen_cowdead_Comments($id) {

            $db = new dbconnection();
            $sql = "select   cowdead.Comments from cowdead where cowdead_id=:cowdead_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdead_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['Comments'];
            echo $field;
        }

        function get_chosen_cowdead_LastUserID($id) {

            $db = new dbconnection();
            $sql = "select   cowdead.LastUserID from cowdead where cowdead_id=:cowdead_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdead_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['LastUserID'];
            echo $field;
        }

        function get_chosen_cowdead_RecoredDate($id) {

            $db = new dbconnection();
            $sql = "select   cowdead.RecoredDate from cowdead where cowdead_id=:cowdead_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':cowdead_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['RecoredDate'];
            echo $field;
        }

        function All_cowdead() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  CowDeadID   from cowdead";
            foreach ($db->query($sql) as $row) {
                $c+=1;
            }
            return $c;
        }

        function get_first_cowdead() {
            $con = new dbconnection();
            $sql = "select cowdead.cowdead_id from cowdead
                    order by cowdead.cowdead_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowdead_id'];
            return $first_rec;
        }

        function get_last_cowdead() {
            $con = new dbconnection();
            $sql = "select cowdead.cowdead_id from cowdead
                    order by cowdead.cowdead_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['cowdead_id'];
            return $first_rec;
        }

        function get_LastUserID_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select LastUserID.LastUserID_id,   LastUserID.name from LastUserID";
            ?>
        <select class="textbox cbo_LastUserID"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['LastUserID_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_CowDonerID_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select CowDonerID.CowDonerID_id,   CowDonerID.name from CowDonerID";
        ?>
        <select class="textbox cbo_CowDonerID"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['CowDonerID_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_SectorID_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select sector.SectorID,   sector.SectorName from sector";
        ?>
        <select class="textbox cbo_SectorID"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['SectorID'] . ">" . $row['SectorName'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_CellID_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select cell.CellID,   cell.CellName from cell";
        ?>
        <select class="textbox cbo_CellID"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['CellID'] . ">" . $row['CellName'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_VillageID_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select village.VillageID,   village.VillageName from village";
        ?>
        <select class="textbox cbo_VillageID"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['VillageID'] . ">" . $row['VillageName'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_CowID_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select CowID.CowID_id,   CowID.name from CowID";
        ?>
        <select class="textbox cbo_CowID"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['CowID_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_CowBornID_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select CowBornID.CowBornID_id,   CowBornID.name from CowBornID";
        ?>
        <select class="textbox cbo_CowBornID"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['CowBornID_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_CitizenID_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select CitizenID.CitizenID_id,   CitizenID.name from CitizenID";
        ?>
        <select class="textbox cbo_CitizenID"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['CitizenID_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_CowDistributionID_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select CowDistributionID.CowDistributionID_id,   CowDistributionID.name from CowDistributionID";
        ?>
        <select class="textbox cbo_CowDistributionID"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['CowDistributionID_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
        </select>
        <?php
    }

    function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }

    function get_comment_by_citizen($citizen) {
        $con = new dbconnection();
        $sql = "select citizenshortlisted.CitizenID, citizenshortlisted.Comments
                    from citizenshortlisted where  citizenshortlisted.CitizenID = :CitizenID";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array(":CitizenID" => $citizen));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['Comments'];
        echo $first_rec;
    }

}
