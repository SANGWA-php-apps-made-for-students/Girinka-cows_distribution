<?php

require_once 'connection.php';

class deletions {

    function deleteFrom_user($user_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM user where user_id =:user_id");
        $smt->bindValue(':user_id', $user_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cowdonor($cowdonor_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cowdonor where CowDonerID =:cowdonor_id");
        $smt->bindValue(':cowdonor_id', $cowdonor_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cowidentification($cowidentification_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cowidentification where CawId =:cowidentification_id");
        $smt->bindValue(':cowidentification_id', $cowidentification_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cell($cell_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cell where CellID =:cell_id");
        $smt->bindValue(':cell_id', $cell_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_village($village_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM village where village_id =:village_id");
        $smt->bindValue(':village_id', $village_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_sector($sector_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM sector where SectorID =:sector_id");
        $smt->bindValue(':sector_id', $sector_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_citizenshortlisted($citizenshortlisted_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM citizenshortlisted where CitizenID =:citizenshortlisted_id");
        $smt->bindValue(':citizenshortlisted_id', $citizenshortlisted_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cowdistribution($cowdistribution_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cowdistribution where CowDistributionID =:cowdistribution_id");
        $smt->bindValue(':cowdistribution_id', $cowdistribution_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cowborn($cowborn_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cowborn where CowBornID =:cowborn_id");
        $smt->bindValue(':cowborn_id', $cowborn_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_newborncowdistribution($newborncowdistribution_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM newborncowdistribution where NewDistributionID =:newborncowdistribution_id");
        $smt->bindValue(':newborncowdistribution_id', $newborncowdistribution_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cowmovement($cowmovement_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cowmovement where CowMovementID =:cowmovement_id");
        $smt->bindValue(':cowmovement_id', $cowmovement_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cowtreatmentreceived($cowtreatmentreceived_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cowtreatmentreceived where CowTreatmentID =:cowtreatmentreceived_id");
        $smt->bindValue(':cowtreatmentreceived_id', $cowtreatmentreceived_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cowsold($cowsold_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cowsold where CowSoldID =:cowsold_id");
        $smt->bindValue(':cowsold_id', $cowsold_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cowstolen($cowstolen_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cowstolen where CowStolenID =:cowstolen_id");
        $smt->bindValue(':cowstolen_id', $cowstolen_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

    function deleteFrom_cowdead($cowdead_id) {
        $db = new dbconnection();
        $con = $db->openconnection();
        $smt = $con->prepare(" DELETE FROM cowdead where CowDeadID =:cowdead_id");
        $smt->bindValue(':cowdead_id', $cowdead_id, PDO::PARAM_STR);
        $smt->execute();
        echo 'Record removed succefully';
    }

}
