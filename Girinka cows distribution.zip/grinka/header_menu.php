<div class="parts  eighty_centered ">            <div class="parts  no_paddin_shade_no_Border xxx_titles">
                GIRINKA
            </div>
</div>        <div class="parts menu eighty_centered">
<a href="new_user.php">user</a>
<a href="new_sector.php">sector</a>
<a href="new_cell.php">cell</a>
<a href="new_village.php">village</a>
<a href="new_citizen.php">citizen</a>
<a href="new_cowmovement.php">cowmovement</a>
<a href="new_cowidentification.php">cowidentification</a>
<a href="new_cow_distribution.php">cow_distribution</a>
<a href="new_cowdonor.php">cowdonor</a>
<a href="new_newborn_distribution.php">newborn_distribution</a>
<a href="new_cowsold.php">cowsold</a>
<a href="new_cowborn.php">cowborn</a>
<a href="new_cowstolen.php">cowstolen</a>
<a href="new_cowdead.php">cowdead</a>
<a href="new_cowtreatment.php">cowtreatment</a>
<a href="new_roles.php">roles</a>
<a href="new_sector_uesrs.php">sector_uesrs</a>
<a href="new_cell_users.php">cell_users</a>
<a href="new_village_users.php">village_users</a>
<a href="new_district_users.php">district_users</a>
<a href="new_user_cat.php">user_cat</a>
<a href="new_sector.php">sector</a>
<a href="new_cell.php">cell</a>
<a href="new_insemination.php">insemination</a>
<a href="new_visit_event.php">visit_event</a>
<a href="new_images.php">images</a>
<a href="new_kwakwa_inka.php">kwakwa_inka</a>
<a href="new_sickcow.php">sickcow</a>

  <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href="login.php">Login</a>
            </div>
       </div>
