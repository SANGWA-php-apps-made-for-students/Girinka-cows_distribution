
--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`user_id`     int(11) NOT NULL AUTO_INCREMENT 
,`names`     VARCHAR(60) 
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
, `type`     int(11)   
,`cat`     VARCHAR(60) 
,`position`     VARCHAR(60) 

,PRIMARY KEY (`user_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `sector`
--

CREATE TABLE IF NOT EXISTS `sector` (
`sector_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`sector_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cell`
--

CREATE TABLE IF NOT EXISTS `cell` (
`cell_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `sector`     int(11)   

,PRIMARY KEY (`cell_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `village`
--

CREATE TABLE IF NOT EXISTS `village` (
`village_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `cell`     int(11)   

,PRIMARY KEY (`village_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `citizen`
--

CREATE TABLE IF NOT EXISTS `citizen` (
`citizen_id`     int(11) NOT NULL AUTO_INCREMENT 
,`fname`     VARCHAR(60) 
,`lname`     VARCHAR(60) 
,`Idnumber`     VARCHAR(60) 
,`Phone`     VARCHAR(60) 
, `villiage`     int(11)   
,`ubudehe`     VARCHAR(60) 
,`number_chosen`     VARCHAR(60) 
,`comments`     VARCHAR(60) 
,`status`     VARCHAR(60) 
,`date`     Date 
, `account`     int(11)   
,`marital_status`     VARCHAR(60) 

,PRIMARY KEY (`citizen_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowmovement`
--

CREATE TABLE IF NOT EXISTS `cowmovement` (
`cowmovement_id`     int(11) NOT NULL AUTO_INCREMENT 
, `distribution`     int(11)   
, `citizen`     int(11)   
,`date_movement`     Date 
,`comments_movement`     VARCHAR(60) 
, `user`     int(11)   
,`date`     Date 

,PRIMARY KEY (`cowmovement_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowidentification`
--

CREATE TABLE IF NOT EXISTS `cowidentification` (
`cowidentification_id`     int(11) NOT NULL AUTO_INCREMENT 
,`tag_number`     VARCHAR(60) 
,`color`     VARCHAR(60) 
,`race`     VARCHAR(60) 
, `donor`     int(11)   
,`cow_status`     VARCHAR(60) 
, `user`     int(11)   
,`date`     Date 
,`sex`     VARCHAR(60) 
,`age`     VARCHAR(60) 

,PRIMARY KEY (`cowidentification_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cow_distribution`
--

CREATE TABLE IF NOT EXISTS `cow_distribution` (
`cow_distribution_id`     int(11) NOT NULL AUTO_INCREMENT 
, `citizen`     int(11)   
, `cowidentf`     int(11)   
,`date_distribution`     Date 
,`comments`     VARCHAR(60) 
, `User`     int(11)   
,`date`     Date 

,PRIMARY KEY (`cow_distribution_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowdonor`
--

CREATE TABLE IF NOT EXISTS `cowdonor` (
`cowdonor_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `user`     int(11)   
,`date`     Date 

,PRIMARY KEY (`cowdonor_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `newborn_distribution`
--

CREATE TABLE IF NOT EXISTS `newborn_distribution` (
`newborn_distribution_id`     int(11) NOT NULL AUTO_INCREMENT 
, `citizen`     int(11)   
, `cowborn`     int(11)   
,`date_op`     Date 
,`comments`     VARCHAR(60) 
, `user`     int(11)   
,`date`     Date 

,PRIMARY KEY (`newborn_distribution_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowsold`
--

CREATE TABLE IF NOT EXISTS `cowsold` (
`cowsold_id`     int(11) NOT NULL AUTO_INCREMENT 
, `distribution`     int(11)   
,`date_sold`     Date 
,`redistributed`     VARCHAR(60) 
,`date`     Date 
, `user`     int(11)   
,`comments`     VARCHAR(60) 
,`info_source`     VARCHAR(60) 
,`seen`     VARCHAR(60) 

,PRIMARY KEY (`cowsold_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowborn`
--

CREATE TABLE IF NOT EXISTS `cowborn` (
`cowborn_id`     int(11) NOT NULL AUTO_INCREMENT 
, `cow_distribution`     int(11)   
,`sex_newborn`     VARCHAR(60) 
,`new_born_race`     VARCHAR(60) 
,`ear_tag_number`     VARCHAR(60) 
,`cow_status`     VARCHAR(60) 
,`date`     Date 
, `user`     int(11)   
,`info_source`     VARCHAR(60) 
,`seen`     VARCHAR(60) 

,PRIMARY KEY (`cowborn_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowstolen`
--

CREATE TABLE IF NOT EXISTS `cowstolen` (
`cowstolen_id`     int(11) NOT NULL AUTO_INCREMENT 
, `cow_distribution`     int(11)   
,`date_stolen`     Date 
,`returned`     VARCHAR(60) 
,`date`     Date 
, `user`     int(11)   
,`comments`     VARCHAR(60) 
,`info_source`     VARCHAR(60) 
,`seen`     VARCHAR(60) 

,PRIMARY KEY (`cowstolen_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowdead`
--

CREATE TABLE IF NOT EXISTS `cowdead` (
`cowdead_id`     int(11) NOT NULL AUTO_INCREMENT 
, `cow_distribution`     int(11)   
,`date_dead`     Date 
,`reason_death`     VARCHAR(60) 
,`comments`     VARCHAR(60) 
, `user`     int(11)   
,`date`     Date 
,`info_source`     VARCHAR(60) 
,`seen`     VARCHAR(60) 

,PRIMARY KEY (`cowdead_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cowtreatment`
--

CREATE TABLE IF NOT EXISTS `cowtreatment` (
`cowtreatment_id`     int(11) NOT NULL AUTO_INCREMENT 
, `cow_distribution`     int(11)   
,`symptomology`     VARCHAR(60) 
,`interventions`     VARCHAR(60) 
,`comments`     VARCHAR(60) 
,`date_treatment`     Date 
, `user`     int(11)   
,`date`     Date 

,PRIMARY KEY (`cowtreatment_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
`roles_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`roles_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `sector_uesrs`
--

CREATE TABLE IF NOT EXISTS `sector_uesrs` (
`sector_uesrs_id`     int(11) NOT NULL AUTO_INCREMENT 
, `users`     int(11)   
, `role`     int(11)   
, `sector`     int(11)   

,PRIMARY KEY (`sector_uesrs_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `cell_users`
--

CREATE TABLE IF NOT EXISTS `cell_users` (
`cell_users_id`     int(11) NOT NULL AUTO_INCREMENT 
, `user`     int(11)   
, `cell`     int(11)   
, `role`     int(11)   

,PRIMARY KEY (`cell_users_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `village_users`
--

CREATE TABLE IF NOT EXISTS `village_users` (
`village_users_id`     int(11) NOT NULL AUTO_INCREMENT 
, `user`     int(11)   
, `village`     int(11)   
, `role`     int(11)   

,PRIMARY KEY (`village_users_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `district_users`
--

CREATE TABLE IF NOT EXISTS `district_users` (
`district_users_id`     int(11) NOT NULL AUTO_INCREMENT 
, `user`     int(11)   

,PRIMARY KEY (`district_users_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `user_cat`
--

CREATE TABLE IF NOT EXISTS `user_cat` (
`user_cat_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`user_cat_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `insemination`
--

CREATE TABLE IF NOT EXISTS `insemination` (
`insemination_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date`     Date 
, `user`     int(11)   
,`auto_brought`     VARCHAR(60) 
,`type_semen`     VARCHAR(60) 
,`certif_number`     VARCHAR(60) 
,`comments`     VARCHAR(60) 
,`tag_number`     VARCHAR(60) 
,`insemin_date`     Date 

,PRIMARY KEY (`insemination_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `visit_event`
--

CREATE TABLE IF NOT EXISTS `visit_event` (
`visit_event_id`     int(11) NOT NULL AUTO_INCREMENT 
,`event_date`     Date 
,`date`     Date 
, `user`     int(11)   
, `imageid`     int(11)   
,`description`     VARCHAR(60) 

,PRIMARY KEY (`visit_event_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
`images_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 

,PRIMARY KEY (`images_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `kwakwa_inka`
--

CREATE TABLE IF NOT EXISTS `kwakwa_inka` (
`kwakwa_inka_id`     int(11) NOT NULL AUTO_INCREMENT 
,`entry_date`     Date 
,`User`     VARCHAR(60) 
, `old_citizen`     int(11)   
, `new_citizen`     int(11)   
,`comments`     VARCHAR(60) 

,PRIMARY KEY (`kwakwa_inka_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `sickcow`
--

CREATE TABLE IF NOT EXISTS `sickcow` (
`sickcow_id`     int(11) NOT NULL AUTO_INCREMENT 
, `distribution`     int(11)   
,`sickness`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`sickcow_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

