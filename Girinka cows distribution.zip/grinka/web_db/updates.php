<?php

require_once 'connection.php';
class updates{

 function update_user( $names, $username, $password, $type, $cat, $position,$user_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE user set 
names= ?, username= ?, password= ?, type= ?, cat= ?, position= ? WHERE user_id=?");
$stmt->execute(array($names, $username, $password, $type, $cat, $position ,$user_id ));

}
 function update_sector( $name,$sector_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE sector set 
name= ? WHERE sector_id=?");
$stmt->execute(array($name ,$sector_id ));

}
 function update_cell( $name, $sector,$cell_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cell set 
name= ?, sector= ? WHERE cell_id=?");
$stmt->execute(array($name, $sector ,$cell_id ));

}
 function update_village( $name, $cell,$village_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE village set 
name= ?, cell= ? WHERE village_id=?");
$stmt->execute(array($name, $cell ,$village_id ));

}
 function update_citizen( $fname, $lname, $Idnumber, $Phone, $villiage, $ubudehe, $number_chosen, $comments, $status, $date, $account, $marital_status,$citizen_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE citizen set 
fname= ?, lname= ?, Idnumber= ?, Phone= ?, villiage= ?, ubudehe= ?, number_chosen= ?, comments= ?, status= ?, date= ?, account= ?, marital_status= ? WHERE citizen_id=?");
$stmt->execute(array($fname, $lname, $Idnumber, $Phone, $villiage, $ubudehe, $number_chosen, $comments, $status, $date, $account, $marital_status ,$citizen_id ));

}
 function update_cowmovement( $distribution, $citizen, $date_movement, $comments_movement, $user, $date,$cowmovement_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowmovement set 
distribution= ?, citizen= ?, date_movement= ?, comments_movement= ?, user= ?, date= ? WHERE cowmovement_id=?");
$stmt->execute(array($distribution, $citizen, $date_movement, $comments_movement, $user, $date ,$cowmovement_id ));

}
 function update_cowidentification( $tag_number, $color, $race, $donor, $cow_status, $user, $date, $sex, $age,$cowidentification_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowidentification set 
tag_number= ?, color= ?, race= ?, donor= ?, cow_status= ?, user= ?, date= ?, sex= ?, age= ? WHERE cowidentification_id=?");
$stmt->execute(array($tag_number, $color, $race, $donor, $cow_status, $user, $date, $sex, $age ,$cowidentification_id ));

}
 function update_cow_distribution( $citizen, $cowidentf, $date_distribution, $comments, $User, $date,$cow_distribution_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cow_distribution set 
citizen= ?, cowidentf= ?, date_distribution= ?, comments= ?, User= ?, date= ? WHERE cow_distribution_id=?");
$stmt->execute(array($citizen, $cowidentf, $date_distribution, $comments, $User, $date ,$cow_distribution_id ));

}
 function update_cowdonor( $name, $user, $date,$cowdonor_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowdonor set 
name= ?, user= ?, date= ? WHERE cowdonor_id=?");
$stmt->execute(array($name, $user, $date ,$cowdonor_id ));

}
 function update_newborn_distribution( $citizen, $cowborn, $date_op, $comments, $user, $date,$newborn_distribution_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE newborn_distribution set 
citizen= ?, cowborn= ?, date_op= ?, comments= ?, user= ?, date= ? WHERE newborn_distribution_id=?");
$stmt->execute(array($citizen, $cowborn, $date_op, $comments, $user, $date ,$newborn_distribution_id ));

}
 function update_cowsold( $distribution, $date_sold, $redistributed, $date, $user, $comments, $info_source, $seen,$cowsold_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowsold set 
distribution= ?, date_sold= ?, redistributed= ?, date= ?, user= ?, comments= ?, info_source= ?, seen= ? WHERE cowsold_id=?");
$stmt->execute(array($distribution, $date_sold, $redistributed, $date, $user, $comments, $info_source, $seen ,$cowsold_id ));

}
 function update_cowborn( $cow_distribution, $sex_newborn, $new_born_race, $ear_tag_number, $cow_status, $date, $user, $info_source, $seen,$cowborn_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowborn set 
cow_distribution= ?, sex_newborn= ?, new_born_race= ?, ear_tag_number= ?, cow_status= ?, date= ?, user= ?, info_source= ?, seen= ? WHERE cowborn_id=?");
$stmt->execute(array($cow_distribution, $sex_newborn, $new_born_race, $ear_tag_number, $cow_status, $date, $user, $info_source, $seen ,$cowborn_id ));

}
 function update_cowstolen( $cow_distribution, $date_stolen, $returned, $date, $user, $comments, $info_source, $seen,$cowstolen_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowstolen set 
cow_distribution= ?, date_stolen= ?, returned= ?, date= ?, user= ?, comments= ?, info_source= ?, seen= ? WHERE cowstolen_id=?");
$stmt->execute(array($cow_distribution, $date_stolen, $returned, $date, $user, $comments, $info_source, $seen ,$cowstolen_id ));

}
 function update_cowdead( $cow_distribution, $date_dead, $reason_death, $comments, $user, $date, $info_source, $seen,$cowdead_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowdead set 
cow_distribution= ?, date_dead= ?, reason_death= ?, comments= ?, user= ?, date= ?, info_source= ?, seen= ? WHERE cowdead_id=?");
$stmt->execute(array($cow_distribution, $date_dead, $reason_death, $comments, $user, $date, $info_source, $seen ,$cowdead_id ));

}
 function update_cowtreatment( $cow_distribution, $symptomology, $interventions, $comments, $date_treatment, $user, $date,$cowtreatment_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cowtreatment set 
cow_distribution= ?, symptomology= ?, interventions= ?, comments= ?, date_treatment= ?, user= ?, date= ? WHERE cowtreatment_id=?");
$stmt->execute(array($cow_distribution, $symptomology, $interventions, $comments, $date_treatment, $user, $date ,$cowtreatment_id ));

}
 function update_roles( $name,$roles_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE roles set 
name= ? WHERE roles_id=?");
$stmt->execute(array($name ,$roles_id ));

}
 function update_sector_uesrs( $users, $role, $sector,$sector_uesrs_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE sector_uesrs set 
users= ?, role= ?, sector= ? WHERE sector_uesrs_id=?");
$stmt->execute(array($users, $role, $sector ,$sector_uesrs_id ));

}
 function update_cell_users( $user, $cell, $role,$cell_users_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cell_users set 
user= ?, cell= ?, role= ? WHERE cell_users_id=?");
$stmt->execute(array($user, $cell, $role ,$cell_users_id ));

}
 function update_village_users( $user, $village, $role,$village_users_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE village_users set 
user= ?, village= ?, role= ? WHERE village_users_id=?");
$stmt->execute(array($user, $village, $role ,$village_users_id ));

}
 function update_district_users( $user,$district_users_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE district_users set 
user= ? WHERE district_users_id=?");
$stmt->execute(array($user ,$district_users_id ));

}
 function update_user_cat( $name,$user_cat_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE user_cat set 
name= ? WHERE user_cat_id=?");
$stmt->execute(array($name ,$user_cat_id ));

}
 function update_sector( $name,$sector_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE sector set 
name= ? WHERE sector_id=?");
$stmt->execute(array($name ,$sector_id ));

}
 function update_cell( $name, $sector,$cell_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE cell set 
name= ?, sector= ? WHERE cell_id=?");
$stmt->execute(array($name, $sector ,$cell_id ));

}
 function update_insemination( $date, $user, $auto_brought, $type_semen, $certif_number, $comments, $tag_number, $insemin_date,$insemination_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE insemination set 
date= ?, user= ?, auto_brought= ?, type_semen= ?, certif_number= ?, comments= ?, tag_number= ?, insemin_date= ? WHERE insemination_id=?");
$stmt->execute(array($date, $user, $auto_brought, $type_semen, $certif_number, $comments, $tag_number, $insemin_date ,$insemination_id ));

}
 function update_visit_event( $event_date, $date, $user, $imageid, $description,$visit_event_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE visit_event set 
event_date= ?, date= ?, user= ?, imageid= ?, description= ? WHERE visit_event_id=?");
$stmt->execute(array($event_date, $date, $user, $imageid, $description ,$visit_event_id ));

}
 function update_images( $path,$images_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE images set 
path= ? WHERE images_id=?");
$stmt->execute(array($path ,$images_id ));

}
 function update_kwakwa_inka( $entry_date, $User, $old_citizen, $new_citizen, $comments,$kwakwa_inka_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE kwakwa_inka set 
entry_date= ?, User= ?, old_citizen= ?, new_citizen= ?, comments= ? WHERE kwakwa_inka_id=?");
$stmt->execute(array($entry_date, $User, $old_citizen, $new_citizen, $comments ,$kwakwa_inka_id ));

}
 function update_sickcow( $distribution, $sickness, $entry_date, $User,$sickcow_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE sickcow set 
distribution= ?, sickness= ?, entry_date= ?, User= ? WHERE sickcow_id=?");
$stmt->execute(array($distribution, $sickness, $entry_date, $User ,$sickcow_id ));

}

}

