<?php

    class new_values {

        function new_user($names, $username, $password, $type, $cat, $position) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into user values(:user_id, :names,  :username,  :password,  :type,  :cat,  :position)");
                $stm->execute(array(':user_id' => 0, ':names' => $names, ':username' => $username, ':password' => $password, ':type' => $type, ':cat' => $cat, ':position' => $position
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_sector($name) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into sector values(:sector_id, :name)");
                $stm->execute(array(':sector_id' => 0, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cell($name, $sector) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cell values(:cell_id, :name,  :sector)");
                $stm->execute(array(':cell_id' => 0, ':name' => $name, ':sector' => $sector
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_village($name, $cell) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into village values(:village_id, :name,  :cell)");
                $stm->execute(array(':village_id' => 0, ':name' => $name, ':cell' => $cell
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_citizen($fname, $lname, $Idnumber, $Phone, $villiage, $ubudehe, $number_chosen, $comments, $status, $date, $account, $marital_status) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into citizen values(:citizen_id, :fname,  :lname,  :Idnumber,  :Phone,  :villiage,  :ubudehe,  :number_chosen,  :comments,  :status,  :date,  :account,  :marital_status)");
                $stm->execute(array(':citizen_id' => 0, ':fname' => $fname, ':lname' => $lname, ':Idnumber' => $Idnumber, ':Phone' => $Phone, ':villiage' => $villiage, ':ubudehe' => $ubudehe, ':number_chosen' => $number_chosen, ':comments' => $comments, ':status' => $status, ':date' => $date, ':account' => $account, ':marital_status' => $marital_status
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cowmovement($distribution, $citizen, $date_movement, $comments_movement, $user, $date) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cowmovement values(:cowmovement_id, :distribution,  :citizen,  :date_movement,  :comments_movement,  :user,  :date)");
                $stm->execute(array(':cowmovement_id' => 0, ':distribution' => $distribution, ':citizen' => $citizen, ':date_movement' => $date_movement, ':comments_movement' => $comments_movement, ':user' => $user, ':date' => $date
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cowidentification($tag_number, $color, $race, $donor, $cow_status, $user, $date, $sex, $age) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cowidentification values(:cowidentification_id, :tag_number,  :color,  :race,  :donor,  :cow_status,  :user,  :date,  :sex,  :age)");
                $stm->execute(array(':cowidentification_id' => 0, ':tag_number' => $tag_number, ':color' => $color, ':race' => $race, ':donor' => $donor, ':cow_status' => $cow_status, ':user' => $user, ':date' => $date, ':sex' => $sex, ':age' => $age
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cow_distribution($citizen, $cowidentf, $date_distribution, $comments, $User, $date) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cow_distribution values(:cow_distribution_id, :citizen,  :cowidentf,  :date_distribution,  :comments,  :User,  :date)");
                $stm->execute(array(':cow_distribution_id' => 0, ':citizen' => $citizen, ':cowidentf' => $cowidentf, ':date_distribution' => $date_distribution, ':comments' => $comments, ':User' => $User, ':date' => $date
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cowdonor($name, $user, $date) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cowdonor values(:cowdonor_id, :name,  :user,  :date)");
                $stm->execute(array(':cowdonor_id' => 0, ':name' => $name, ':user' => $user, ':date' => $date
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_newborn_distribution($citizen, $cowborn, $date_op, $comments, $user, $date) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into newborn_distribution values(:newborn_distribution_id, :citizen,  :cowborn,  :date_op,  :comments,  :user,  :date)");
                $stm->execute(array(':newborn_distribution_id' => 0, ':citizen' => $citizen, ':cowborn' => $cowborn, ':date_op' => $date_op, ':comments' => $comments, ':user' => $user, ':date' => $date
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cowsold($distribution, $date_sold, $redistributed, $date, $user, $comments, $info_source, $seen) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cowsold values(:cowsold_id, :distribution,  :date_sold,  :redistributed,  :date,  :user,  :comments,  :info_source,  :seen)");
                $stm->execute(array(':cowsold_id' => 0, ':distribution' => $distribution, ':date_sold' => $date_sold, ':redistributed' => $redistributed, ':date' => $date, ':user' => $user, ':comments' => $comments, ':info_source' => $info_source, ':seen' => $seen
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cowborn($cow_distribution, $sex_newborn, $new_born_race, $ear_tag_number, $cow_status, $date, $user, $info_source, $seen) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cowborn values(:cowborn_id, :cow_distribution,  :sex_newborn,  :new_born_race,  :ear_tag_number,  :cow_status,  :date,  :user,  :info_source,  :seen)");
                $stm->execute(array(':cowborn_id' => 0, ':cow_distribution' => $cow_distribution, ':sex_newborn' => $sex_newborn, ':new_born_race' => $new_born_race, ':ear_tag_number' => $ear_tag_number, ':cow_status' => $cow_status, ':date' => $date, ':user' => $user, ':info_source' => $info_source, ':seen' => $seen
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cowstolen($cow_distribution, $date_stolen, $returned, $date, $user, $comments, $info_source, $seen) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cowstolen values(:cowstolen_id, :cow_distribution,  :date_stolen,  :returned,  :date,  :user,  :comments,  :info_source,  :seen)");
                $stm->execute(array(':cowstolen_id' => 0, ':cow_distribution' => $cow_distribution, ':date_stolen' => $date_stolen, ':returned' => $returned, ':date' => $date, ':user' => $user, ':comments' => $comments, ':info_source' => $info_source, ':seen' => $seen
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cowdead($cow_distribution, $date_dead, $reason_death, $comments, $user, $date, $info_source, $seen) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cowdead values(:cowdead_id, :cow_distribution,  :date_dead,  :reason_death,  :comments,  :user,  :date,  :info_source,  :seen)");
                $stm->execute(array(':cowdead_id' => 0, ':cow_distribution' => $cow_distribution, ':date_dead' => $date_dead, ':reason_death' => $reason_death, ':comments' => $comments, ':user' => $user, ':date' => $date, ':info_source' => $info_source, ':seen' => $seen
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cowtreatment($cow_distribution, $symptomology, $interventions, $comments, $date_treatment, $user, $date) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cowtreatment values(:cowtreatment_id, :cow_distribution,  :symptomology,  :interventions,  :comments,  :date_treatment,  :user,  :date)");
                $stm->execute(array(':cowtreatment_id' => 0, ':cow_distribution' => $cow_distribution, ':symptomology' => $symptomology, ':interventions' => $interventions, ':comments' => $comments, ':date_treatment' => $date_treatment, ':user' => $user, ':date' => $date
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_roles($name) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into roles values(:roles_id, :name)");
                $stm->execute(array(':roles_id' => 0, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_sector_uesrs($users, $role, $sector) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into sector_uesrs values(:sector_uesrs_id, :users,  :role,  :sector)");
                $stm->execute(array(':sector_uesrs_id' => 0, ':users' => $users, ':role' => $role, ':sector' => $sector
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cell_users($user, $cell, $role) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cell_users values(:cell_users_id, :user,  :cell,  :role)");
                $stm->execute(array(':cell_users_id' => 0, ':user' => $user, ':cell' => $cell, ':role' => $role
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_village_users($user, $village, $role) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into village_users values(:village_users_id, :user,  :village,  :role)");
                $stm->execute(array(':village_users_id' => 0, ':user' => $user, ':village' => $village, ':role' => $role
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_district_users($user) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into district_users values(:district_users_id, :user)");
                $stm->execute(array(':district_users_id' => 0, ':user' => $user
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_user_cat($name) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into user_cat values(:user_cat_id, :name)");
                $stm->execute(array(':user_cat_id' => 0, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_sector($name) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into sector values(:sector_id, :name)");
                $stm->execute(array(':sector_id' => 0, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cell($name, $sector) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cell values(:cell_id, :name,  :sector)");
                $stm->execute(array(':cell_id' => 0, ':name' => $name, ':sector' => $sector
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_insemination($date, $user, $auto_brought, $type_semen, $certif_number, $comments, $tag_number, $insemin_date) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into insemination values(:insemination_id, :date,  :user,  :auto_brought,  :type_semen,  :certif_number,  :comments,  :tag_number,  :insemin_date)");
                $stm->execute(array(':insemination_id' => 0, ':date' => $date, ':user' => $user, ':auto_brought' => $auto_brought, ':type_semen' => $type_semen, ':certif_number' => $certif_number, ':comments' => $comments, ':tag_number' => $tag_number, ':insemin_date' => $insemin_date
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_visit_event($event_date, $date, $user, $imageid, $description) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into visit_event values(:visit_event_id, :event_date,  :date,  :user,  :imageid,  :description)");
                $stm->execute(array(':visit_event_id' => 0, ':event_date' => $event_date, ':date' => $date, ':user' => $user, ':imageid' => $imageid, ':description' => $description
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_images($path) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into images values(:images_id, :path)");
                $stm->execute(array(':images_id' => 0, ':path' => $path
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_kwakwa_inka($entry_date, $User, $old_citizen, $new_citizen, $comments) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into kwakwa_inka values(:kwakwa_inka_id, :entry_date,  :User,  :old_citizen,  :new_citizen,  :comments)");
                $stm->execute(array(':kwakwa_inka_id' => 0, ':entry_date' => $entry_date, ':User' => $User, ':old_citizen' => $old_citizen, ':new_citizen' => $new_citizen, ':comments' => $comments
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_sickcow($distribution, $sickness, $entry_date, $User) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into sickcow values(:sickcow_id, :distribution,  :sickness,  :entry_date,  :User)");
                $stm->execute(array(':sickcow_id' => 0, ':distribution' => $distribution, ':sickness' => $sickness, ':entry_date' => $entry_date, ':User' => $User
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

    }
    