<?php
    require_once '../web_db/connection.php';

    class multi_values {

        function list_user($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from user";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> user </td>
                        <td> Names </td><td> Username </td><td> Password </td><td> Category </td><td> Category </td><td> Position </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['user_id']; ?>
                        </td>
                        <td class="names_id_cols user " title="user" >
                            <?php echo $this->_e($row['names']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['username']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['password']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['type']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['cat']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['position']); ?>
                        </td>


                        <td>
                            <a href="#" class="user_delete_link" style="color: #000080;" data-id_delete="user_id"  data-table="
                               <?php echo $row['user_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="user_update_link" style="color: #000080;" value="
                               <?php echo $row['user_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_user_names($id) {

                $db = new dbconnection();
                $sql = "select   user.names from user where user_id=:user_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':user_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['names'];
                echo $field;
            }

            function get_chosen_user_username($id) {

                $db = new dbconnection();
                $sql = "select   user.username from user where user_id=:user_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':user_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['username'];
                echo $field;
            }

            function get_chosen_user_password($id) {

                $db = new dbconnection();
                $sql = "select   user.password from user where user_id=:user_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':user_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['password'];
                echo $field;
            }

            function get_chosen_user_type($id) {

                $db = new dbconnection();
                $sql = "select   user.type from user where user_id=:user_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':user_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['type'];
                echo $field;
            }

            function get_chosen_user_cat($id) {

                $db = new dbconnection();
                $sql = "select   user.cat from user where user_id=:user_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':user_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['cat'];
                echo $field;
            }

            function get_chosen_user_position($id) {

                $db = new dbconnection();
                $sql = "select   user.position from user where user_id=:user_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':user_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['position'];
                echo $field;
            }

            function All_user() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  user_id   from user";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_user() {
                $con = new dbconnection();
                $sql = "select user.user_id from user
                    order by user.user_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['user_id'];
                return $first_rec;
            }

            function get_last_user() {
                $con = new dbconnection();
                $sql = "select user.user_id from user
                    order by user.user_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['user_id'];
                return $first_rec;
            }

            function list_sector($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from sector";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> sector </td>
                        <td> Name </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['sector_id']; ?>
                        </td>
                        <td class="name_id_cols sector " title="sector" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>


                        <td>
                            <a href="#" class="sector_delete_link" style="color: #000080;" data-id_delete="sector_id"  data-table="
                               <?php echo $row['sector_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="sector_update_link" style="color: #000080;" value="
                               <?php echo $row['sector_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_sector_name($id) {

                $db = new dbconnection();
                $sql = "select   sector.name from sector where sector_id=:sector_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':sector_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function All_sector() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  sector_id   from sector";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_sector() {
                $con = new dbconnection();
                $sql = "select sector.sector_id from sector
                    order by sector.sector_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['sector_id'];
                return $first_rec;
            }

            function get_last_sector() {
                $con = new dbconnection();
                $sql = "select sector.sector_id from sector
                    order by sector.sector_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['sector_id'];
                return $first_rec;
            }

            function list_cell($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cell";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> cell </td>
                        <td> Name </td><td> Sector </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['cell_id']; ?>
                        </td>
                        <td class="name_id_cols cell " title="cell" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['sector']); ?>
                        </td>


                        <td>
                            <a href="#" class="cell_delete_link" style="color: #000080;" data-id_delete="cell_id"  data-table="
                               <?php echo $row['cell_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="cell_update_link" style="color: #000080;" value="
                               <?php echo $row['cell_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_cell_name($id) {

                $db = new dbconnection();
                $sql = "select   cell.name from cell where cell_id=:cell_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cell_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function get_chosen_cell_sector($id) {

                $db = new dbconnection();
                $sql = "select   cell.sector from cell where cell_id=:cell_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cell_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['sector'];
                echo $field;
            }

            function All_cell() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  cell_id   from cell";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_cell() {
                $con = new dbconnection();
                $sql = "select cell.cell_id from cell
                    order by cell.cell_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cell_id'];
                return $first_rec;
            }

            function get_last_cell() {
                $con = new dbconnection();
                $sql = "select cell.cell_id from cell
                    order by cell.cell_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cell_id'];
                return $first_rec;
            }

            function list_village($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from village";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> village </td>
                        <td> Name </td><td> Cell </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['village_id']; ?>
                        </td>
                        <td class="name_id_cols village " title="village" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['cell']); ?>
                        </td>


                        <td>
                            <a href="#" class="village_delete_link" style="color: #000080;" data-id_delete="village_id"  data-table="
                               <?php echo $row['village_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="village_update_link" style="color: #000080;" value="
                               <?php echo $row['village_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_village_name($id) {

                $db = new dbconnection();
                $sql = "select   village.name from village where village_id=:village_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':village_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function get_chosen_village_cell($id) {

                $db = new dbconnection();
                $sql = "select   village.cell from village where village_id=:village_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':village_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['cell'];
                echo $field;
            }

            function All_village() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  village_id   from village";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_village() {
                $con = new dbconnection();
                $sql = "select village.village_id from village
                    order by village.village_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['village_id'];
                return $first_rec;
            }

            function get_last_village() {
                $con = new dbconnection();
                $sql = "select village.village_id from village
                    order by village.village_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['village_id'];
                return $first_rec;
            }

            function list_citizen($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from citizen";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> citizen </td>
                        <td> null </td><td> Last Name </td><td> ID Number </td><td> Phone </td><td> Village </td><td> Ubudehe </td><td> Number Chosen </td><td> Comments </td><td> Status </td><td> Date </td><td> User </td><td> Marital Status </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['citizen_id']; ?>
                        </td>
                        <td class="fname_id_cols citizen " title="citizen" >
                            <?php echo $this->_e($row['fname']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['lname']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['Idnumber']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['Phone']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['villiage']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['ubudehe']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['number_chosen']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['comments']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['status']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['account']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['marital_status']); ?>
                        </td>


                        <td>
                            <a href="#" class="citizen_delete_link" style="color: #000080;" data-id_delete="citizen_id"  data-table="
                               <?php echo $row['citizen_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="citizen_update_link" style="color: #000080;" value="
                               <?php echo $row['citizen_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_citizen_fname($id) {

                $db = new dbconnection();
                $sql = "select   citizen.fname from citizen where citizen_id=:citizen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':citizen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['fname'];
                echo $field;
            }

            function get_chosen_citizen_lname($id) {

                $db = new dbconnection();
                $sql = "select   citizen.lname from citizen where citizen_id=:citizen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':citizen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['lname'];
                echo $field;
            }

            function get_chosen_citizen_Idnumber($id) {

                $db = new dbconnection();
                $sql = "select   citizen.Idnumber from citizen where citizen_id=:citizen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':citizen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['Idnumber'];
                echo $field;
            }

            function get_chosen_citizen_Phone($id) {

                $db = new dbconnection();
                $sql = "select   citizen.Phone from citizen where citizen_id=:citizen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':citizen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['Phone'];
                echo $field;
            }

            function get_chosen_citizen_villiage($id) {

                $db = new dbconnection();
                $sql = "select   citizen.villiage from citizen where citizen_id=:citizen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':citizen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['villiage'];
                echo $field;
            }

            function get_chosen_citizen_ubudehe($id) {

                $db = new dbconnection();
                $sql = "select   citizen.ubudehe from citizen where citizen_id=:citizen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':citizen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['ubudehe'];
                echo $field;
            }

            function get_chosen_citizen_number_chosen($id) {

                $db = new dbconnection();
                $sql = "select   citizen.number_chosen from citizen where citizen_id=:citizen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':citizen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['number_chosen'];
                echo $field;
            }

            function get_chosen_citizen_comments($id) {

                $db = new dbconnection();
                $sql = "select   citizen.comments from citizen where citizen_id=:citizen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':citizen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['comments'];
                echo $field;
            }

            function get_chosen_citizen_status($id) {

                $db = new dbconnection();
                $sql = "select   citizen.status from citizen where citizen_id=:citizen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':citizen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['status'];
                echo $field;
            }

            function get_chosen_citizen_date($id) {

                $db = new dbconnection();
                $sql = "select   citizen.date from citizen where citizen_id=:citizen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':citizen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date'];
                echo $field;
            }

            function get_chosen_citizen_account($id) {

                $db = new dbconnection();
                $sql = "select   citizen.account from citizen where citizen_id=:citizen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':citizen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['account'];
                echo $field;
            }

            function get_chosen_citizen_marital_status($id) {

                $db = new dbconnection();
                $sql = "select   citizen.marital_status from citizen where citizen_id=:citizen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':citizen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['marital_status'];
                echo $field;
            }

            function All_citizen() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  citizen_id   from citizen";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_citizen() {
                $con = new dbconnection();
                $sql = "select citizen.citizen_id from citizen
                    order by citizen.citizen_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['citizen_id'];
                return $first_rec;
            }

            function get_last_citizen() {
                $con = new dbconnection();
                $sql = "select citizen.citizen_id from citizen
                    order by citizen.citizen_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['citizen_id'];
                return $first_rec;
            }

            function list_cowmovement($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cowmovement";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> cowmovement </td>
                        <td> null </td><td> null </td><td> Date </td><td> Comments </td><td> User </td><td> Date </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['cowmovement_id']; ?>
                        </td>
                        <td class="distribution_id_cols cowmovement " title="cowmovement" >
                            <?php echo $this->_e($row['distribution']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['citizen']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date_movement']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['comments_movement']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['user']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date']); ?>
                        </td>


                        <td>
                            <a href="#" class="cowmovement_delete_link" style="color: #000080;" data-id_delete="cowmovement_id"  data-table="
                               <?php echo $row['cowmovement_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="cowmovement_update_link" style="color: #000080;" value="
                               <?php echo $row['cowmovement_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_cowmovement_distribution($id) {

                $db = new dbconnection();
                $sql = "select   cowmovement.distribution from cowmovement where cowmovement_id=:cowmovement_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowmovement_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['distribution'];
                echo $field;
            }

            function get_chosen_cowmovement_citizen($id) {

                $db = new dbconnection();
                $sql = "select   cowmovement.citizen from cowmovement where cowmovement_id=:cowmovement_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowmovement_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['citizen'];
                echo $field;
            }

            function get_chosen_cowmovement_date_movement($id) {

                $db = new dbconnection();
                $sql = "select   cowmovement.date_movement from cowmovement where cowmovement_id=:cowmovement_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowmovement_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date_movement'];
                echo $field;
            }

            function get_chosen_cowmovement_comments_movement($id) {

                $db = new dbconnection();
                $sql = "select   cowmovement.comments_movement from cowmovement where cowmovement_id=:cowmovement_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowmovement_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['comments_movement'];
                echo $field;
            }

            function get_chosen_cowmovement_user($id) {

                $db = new dbconnection();
                $sql = "select   cowmovement.user from cowmovement where cowmovement_id=:cowmovement_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowmovement_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function get_chosen_cowmovement_date($id) {

                $db = new dbconnection();
                $sql = "select   cowmovement.date from cowmovement where cowmovement_id=:cowmovement_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowmovement_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date'];
                echo $field;
            }

            function All_cowmovement() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  cowmovement_id   from cowmovement";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_cowmovement() {
                $con = new dbconnection();
                $sql = "select cowmovement.cowmovement_id from cowmovement
                    order by cowmovement.cowmovement_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowmovement_id'];
                return $first_rec;
            }

            function get_last_cowmovement() {
                $con = new dbconnection();
                $sql = "select cowmovement.cowmovement_id from cowmovement
                    order by cowmovement.cowmovement_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowmovement_id'];
                return $first_rec;
            }

            function list_cowidentification($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cowidentification";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> cowidentification </td>
                        <td> Tag Number </td><td> Color </td><td> Race </td><td> Donor </td><td> Cow Status </td><td> User </td><td> Date </td><td> Sex </td><td> Age </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['cowidentification_id']; ?>
                        </td>
                        <td class="tag_number_id_cols cowidentification " title="cowidentification" >
                            <?php echo $this->_e($row['tag_number']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['color']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['race']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['donor']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['cow_status']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['user']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['sex']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['age']); ?>
                        </td>


                        <td>
                            <a href="#" class="cowidentification_delete_link" style="color: #000080;" data-id_delete="cowidentification_id"  data-table="
                               <?php echo $row['cowidentification_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="cowidentification_update_link" style="color: #000080;" value="
                               <?php echo $row['cowidentification_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_cowidentification_tag_number($id) {

                $db = new dbconnection();
                $sql = "select   cowidentification.tag_number from cowidentification where cowidentification_id=:cowidentification_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowidentification_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['tag_number'];
                echo $field;
            }

            function get_chosen_cowidentification_color($id) {

                $db = new dbconnection();
                $sql = "select   cowidentification.color from cowidentification where cowidentification_id=:cowidentification_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowidentification_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['color'];
                echo $field;
            }

            function get_chosen_cowidentification_race($id) {

                $db = new dbconnection();
                $sql = "select   cowidentification.race from cowidentification where cowidentification_id=:cowidentification_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowidentification_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['race'];
                echo $field;
            }

            function get_chosen_cowidentification_donor($id) {

                $db = new dbconnection();
                $sql = "select   cowidentification.donor from cowidentification where cowidentification_id=:cowidentification_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowidentification_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['donor'];
                echo $field;
            }

            function get_chosen_cowidentification_cow_status($id) {

                $db = new dbconnection();
                $sql = "select   cowidentification.cow_status from cowidentification where cowidentification_id=:cowidentification_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowidentification_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['cow_status'];
                echo $field;
            }

            function get_chosen_cowidentification_user($id) {

                $db = new dbconnection();
                $sql = "select   cowidentification.user from cowidentification where cowidentification_id=:cowidentification_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowidentification_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function get_chosen_cowidentification_date($id) {

                $db = new dbconnection();
                $sql = "select   cowidentification.date from cowidentification where cowidentification_id=:cowidentification_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowidentification_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date'];
                echo $field;
            }

            function get_chosen_cowidentification_sex($id) {

                $db = new dbconnection();
                $sql = "select   cowidentification.sex from cowidentification where cowidentification_id=:cowidentification_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowidentification_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['sex'];
                echo $field;
            }

            function get_chosen_cowidentification_age($id) {

                $db = new dbconnection();
                $sql = "select   cowidentification.age from cowidentification where cowidentification_id=:cowidentification_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowidentification_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['age'];
                echo $field;
            }

            function All_cowidentification() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  cowidentification_id   from cowidentification";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_cowidentification() {
                $con = new dbconnection();
                $sql = "select cowidentification.cowidentification_id from cowidentification
                    order by cowidentification.cowidentification_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowidentification_id'];
                return $first_rec;
            }

            function get_last_cowidentification() {
                $con = new dbconnection();
                $sql = "select cowidentification.cowidentification_id from cowidentification
                    order by cowidentification.cowidentification_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowidentification_id'];
                return $first_rec;
            }

            function list_cow_distribution($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cow_distribution";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> cow_distribution </td>
                        <td> null </td><td> null </td><td> Distribution Date </td><td> Comments </td><td> User </td><td> Date </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['cow_distribution_id']; ?>
                        </td>
                        <td class="citizen_id_cols cow_distribution " title="cow_distribution" >
                            <?php echo $this->_e($row['citizen']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['cowidentf']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date_distribution']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['comments']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date']); ?>
                        </td>


                        <td>
                            <a href="#" class="cow_distribution_delete_link" style="color: #000080;" data-id_delete="cow_distribution_id"  data-table="
                               <?php echo $row['cow_distribution_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="cow_distribution_update_link" style="color: #000080;" value="
                               <?php echo $row['cow_distribution_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_cow_distribution_citizen($id) {

                $db = new dbconnection();
                $sql = "select   cow_distribution.citizen from cow_distribution where cow_distribution_id=:cow_distribution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cow_distribution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['citizen'];
                echo $field;
            }

            function get_chosen_cow_distribution_cowidentf($id) {

                $db = new dbconnection();
                $sql = "select   cow_distribution.cowidentf from cow_distribution where cow_distribution_id=:cow_distribution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cow_distribution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['cowidentf'];
                echo $field;
            }

            function get_chosen_cow_distribution_date_distribution($id) {

                $db = new dbconnection();
                $sql = "select   cow_distribution.date_distribution from cow_distribution where cow_distribution_id=:cow_distribution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cow_distribution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date_distribution'];
                echo $field;
            }

            function get_chosen_cow_distribution_comments($id) {

                $db = new dbconnection();
                $sql = "select   cow_distribution.comments from cow_distribution where cow_distribution_id=:cow_distribution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cow_distribution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['comments'];
                echo $field;
            }

            function get_chosen_cow_distribution_User($id) {

                $db = new dbconnection();
                $sql = "select   cow_distribution.User from cow_distribution where cow_distribution_id=:cow_distribution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cow_distribution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function get_chosen_cow_distribution_date($id) {

                $db = new dbconnection();
                $sql = "select   cow_distribution.date from cow_distribution where cow_distribution_id=:cow_distribution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cow_distribution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date'];
                echo $field;
            }

            function All_cow_distribution() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  cow_distribution_id   from cow_distribution";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_cow_distribution() {
                $con = new dbconnection();
                $sql = "select cow_distribution.cow_distribution_id from cow_distribution
                    order by cow_distribution.cow_distribution_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cow_distribution_id'];
                return $first_rec;
            }

            function get_last_cow_distribution() {
                $con = new dbconnection();
                $sql = "select cow_distribution.cow_distribution_id from cow_distribution
                    order by cow_distribution.cow_distribution_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cow_distribution_id'];
                return $first_rec;
            }

            function list_cowdonor($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cowdonor";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> cowdonor </td>
                        <td> Name </td><td> User </td><td> Date </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['cowdonor_id']; ?>
                        </td>
                        <td class="name_id_cols cowdonor " title="cowdonor" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['user']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date']); ?>
                        </td>


                        <td>
                            <a href="#" class="cowdonor_delete_link" style="color: #000080;" data-id_delete="cowdonor_id"  data-table="
                               <?php echo $row['cowdonor_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="cowdonor_update_link" style="color: #000080;" value="
                               <?php echo $row['cowdonor_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_cowdonor_name($id) {

                $db = new dbconnection();
                $sql = "select   cowdonor.name from cowdonor where cowdonor_id=:cowdonor_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowdonor_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function get_chosen_cowdonor_user($id) {

                $db = new dbconnection();
                $sql = "select   cowdonor.user from cowdonor where cowdonor_id=:cowdonor_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowdonor_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function get_chosen_cowdonor_date($id) {

                $db = new dbconnection();
                $sql = "select   cowdonor.date from cowdonor where cowdonor_id=:cowdonor_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowdonor_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date'];
                echo $field;
            }

            function All_cowdonor() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  cowdonor_id   from cowdonor";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_cowdonor() {
                $con = new dbconnection();
                $sql = "select cowdonor.cowdonor_id from cowdonor
                    order by cowdonor.cowdonor_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowdonor_id'];
                return $first_rec;
            }

            function get_last_cowdonor() {
                $con = new dbconnection();
                $sql = "select cowdonor.cowdonor_id from cowdonor
                    order by cowdonor.cowdonor_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowdonor_id'];
                return $first_rec;
            }

            function list_newborn_distribution($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from newborn_distribution";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> newborn_distribution </td>
                        <td> null </td><td> null </td><td> Operation Date </td><td> Comments </td><td> User </td><td> Date </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['newborn_distribution_id']; ?>
                        </td>
                        <td class="citizen_id_cols newborn_distribution " title="newborn_distribution" >
                            <?php echo $this->_e($row['citizen']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['cowborn']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date_op']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['comments']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['user']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date']); ?>
                        </td>


                        <td>
                            <a href="#" class="newborn_distribution_delete_link" style="color: #000080;" data-id_delete="newborn_distribution_id"  data-table="
                               <?php echo $row['newborn_distribution_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="newborn_distribution_update_link" style="color: #000080;" value="
                               <?php echo $row['newborn_distribution_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_newborn_distribution_citizen($id) {

                $db = new dbconnection();
                $sql = "select   newborn_distribution.citizen from newborn_distribution where newborn_distribution_id=:newborn_distribution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':newborn_distribution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['citizen'];
                echo $field;
            }

            function get_chosen_newborn_distribution_cowborn($id) {

                $db = new dbconnection();
                $sql = "select   newborn_distribution.cowborn from newborn_distribution where newborn_distribution_id=:newborn_distribution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':newborn_distribution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['cowborn'];
                echo $field;
            }

            function get_chosen_newborn_distribution_date_op($id) {

                $db = new dbconnection();
                $sql = "select   newborn_distribution.date_op from newborn_distribution where newborn_distribution_id=:newborn_distribution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':newborn_distribution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date_op'];
                echo $field;
            }

            function get_chosen_newborn_distribution_comments($id) {

                $db = new dbconnection();
                $sql = "select   newborn_distribution.comments from newborn_distribution where newborn_distribution_id=:newborn_distribution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':newborn_distribution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['comments'];
                echo $field;
            }

            function get_chosen_newborn_distribution_user($id) {

                $db = new dbconnection();
                $sql = "select   newborn_distribution.user from newborn_distribution where newborn_distribution_id=:newborn_distribution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':newborn_distribution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function get_chosen_newborn_distribution_date($id) {

                $db = new dbconnection();
                $sql = "select   newborn_distribution.date from newborn_distribution where newborn_distribution_id=:newborn_distribution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':newborn_distribution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date'];
                echo $field;
            }

            function All_newborn_distribution() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  newborn_distribution_id   from newborn_distribution";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_newborn_distribution() {
                $con = new dbconnection();
                $sql = "select newborn_distribution.newborn_distribution_id from newborn_distribution
                    order by newborn_distribution.newborn_distribution_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['newborn_distribution_id'];
                return $first_rec;
            }

            function get_last_newborn_distribution() {
                $con = new dbconnection();
                $sql = "select newborn_distribution.newborn_distribution_id from newborn_distribution
                    order by newborn_distribution.newborn_distribution_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['newborn_distribution_id'];
                return $first_rec;
            }

            function list_cowsold($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cowsold";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> cowsold </td>
                        <td> null </td><td> Date </td><td> redistributed </td><td> date </td><td> User </td><td> Comments </td><td> Info Source </td><td> Seen </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['cowsold_id']; ?>
                        </td>
                        <td class="distribution_id_cols cowsold " title="cowsold" >
                            <?php echo $this->_e($row['distribution']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date_sold']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['redistributed']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['user']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['comments']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['info_source']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['seen']); ?>
                        </td>


                        <td>
                            <a href="#" class="cowsold_delete_link" style="color: #000080;" data-id_delete="cowsold_id"  data-table="
                               <?php echo $row['cowsold_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="cowsold_update_link" style="color: #000080;" value="
                               <?php echo $row['cowsold_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_cowsold_distribution($id) {

                $db = new dbconnection();
                $sql = "select   cowsold.distribution from cowsold where cowsold_id=:cowsold_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowsold_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['distribution'];
                echo $field;
            }

            function get_chosen_cowsold_date_sold($id) {

                $db = new dbconnection();
                $sql = "select   cowsold.date_sold from cowsold where cowsold_id=:cowsold_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowsold_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date_sold'];
                echo $field;
            }

            function get_chosen_cowsold_redistributed($id) {

                $db = new dbconnection();
                $sql = "select   cowsold.redistributed from cowsold where cowsold_id=:cowsold_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowsold_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['redistributed'];
                echo $field;
            }

            function get_chosen_cowsold_date($id) {

                $db = new dbconnection();
                $sql = "select   cowsold.date from cowsold where cowsold_id=:cowsold_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowsold_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date'];
                echo $field;
            }

            function get_chosen_cowsold_user($id) {

                $db = new dbconnection();
                $sql = "select   cowsold.user from cowsold where cowsold_id=:cowsold_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowsold_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function get_chosen_cowsold_comments($id) {

                $db = new dbconnection();
                $sql = "select   cowsold.comments from cowsold where cowsold_id=:cowsold_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowsold_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['comments'];
                echo $field;
            }

            function get_chosen_cowsold_info_source($id) {

                $db = new dbconnection();
                $sql = "select   cowsold.info_source from cowsold where cowsold_id=:cowsold_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowsold_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['info_source'];
                echo $field;
            }

            function get_chosen_cowsold_seen($id) {

                $db = new dbconnection();
                $sql = "select   cowsold.seen from cowsold where cowsold_id=:cowsold_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowsold_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['seen'];
                echo $field;
            }

            function All_cowsold() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  cowsold_id   from cowsold";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_cowsold() {
                $con = new dbconnection();
                $sql = "select cowsold.cowsold_id from cowsold
                    order by cowsold.cowsold_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowsold_id'];
                return $first_rec;
            }

            function get_last_cowsold() {
                $con = new dbconnection();
                $sql = "select cowsold.cowsold_id from cowsold
                    order by cowsold.cowsold_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowsold_id'];
                return $first_rec;
            }

            function list_cowborn($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cowborn";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> cowborn </td>
                        <td> null </td><td> Sex </td><td> Race </td><td> Tag Number </td><td> Cow Status </td><td> Date </td><td> User </td><td> Source of Info </td><td> Seen </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['cowborn_id']; ?>
                        </td>
                        <td class="cow_distribution_id_cols cowborn " title="cowborn" >
                            <?php echo $this->_e($row['cow_distribution']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['sex_newborn']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['new_born_race']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['ear_tag_number']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['cow_status']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['user']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['info_source']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['seen']); ?>
                        </td>


                        <td>
                            <a href="#" class="cowborn_delete_link" style="color: #000080;" data-id_delete="cowborn_id"  data-table="
                               <?php echo $row['cowborn_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="cowborn_update_link" style="color: #000080;" value="
                               <?php echo $row['cowborn_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_cowborn_cow_distribution($id) {

                $db = new dbconnection();
                $sql = "select   cowborn.cow_distribution from cowborn where cowborn_id=:cowborn_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowborn_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['cow_distribution'];
                echo $field;
            }

            function get_chosen_cowborn_sex_newborn($id) {

                $db = new dbconnection();
                $sql = "select   cowborn.sex_newborn from cowborn where cowborn_id=:cowborn_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowborn_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['sex_newborn'];
                echo $field;
            }

            function get_chosen_cowborn_new_born_race($id) {

                $db = new dbconnection();
                $sql = "select   cowborn.new_born_race from cowborn where cowborn_id=:cowborn_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowborn_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['new_born_race'];
                echo $field;
            }

            function get_chosen_cowborn_ear_tag_number($id) {

                $db = new dbconnection();
                $sql = "select   cowborn.ear_tag_number from cowborn where cowborn_id=:cowborn_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowborn_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['ear_tag_number'];
                echo $field;
            }

            function get_chosen_cowborn_cow_status($id) {

                $db = new dbconnection();
                $sql = "select   cowborn.cow_status from cowborn where cowborn_id=:cowborn_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowborn_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['cow_status'];
                echo $field;
            }

            function get_chosen_cowborn_date($id) {

                $db = new dbconnection();
                $sql = "select   cowborn.date from cowborn where cowborn_id=:cowborn_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowborn_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date'];
                echo $field;
            }

            function get_chosen_cowborn_user($id) {

                $db = new dbconnection();
                $sql = "select   cowborn.user from cowborn where cowborn_id=:cowborn_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowborn_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function get_chosen_cowborn_info_source($id) {

                $db = new dbconnection();
                $sql = "select   cowborn.info_source from cowborn where cowborn_id=:cowborn_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowborn_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['info_source'];
                echo $field;
            }

            function get_chosen_cowborn_seen($id) {

                $db = new dbconnection();
                $sql = "select   cowborn.seen from cowborn where cowborn_id=:cowborn_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowborn_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['seen'];
                echo $field;
            }

            function All_cowborn() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  cowborn_id   from cowborn";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_cowborn() {
                $con = new dbconnection();
                $sql = "select cowborn.cowborn_id from cowborn
                    order by cowborn.cowborn_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowborn_id'];
                return $first_rec;
            }

            function get_last_cowborn() {
                $con = new dbconnection();
                $sql = "select cowborn.cowborn_id from cowborn
                    order by cowborn.cowborn_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowborn_id'];
                return $first_rec;
            }

            function list_cowstolen($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cowstolen";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> cowstolen </td>
                        <td> null </td><td> Date Stolen </td><td> Returned </td><td> Date </td><td> user </td><td> Comments </td><td> Info Source </td><td> seen </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['cowstolen_id']; ?>
                        </td>
                        <td class="cow_distribution_id_cols cowstolen " title="cowstolen" >
                            <?php echo $this->_e($row['cow_distribution']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date_stolen']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['returned']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['user']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['comments']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['info_source']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['seen']); ?>
                        </td>


                        <td>
                            <a href="#" class="cowstolen_delete_link" style="color: #000080;" data-id_delete="cowstolen_id"  data-table="
                               <?php echo $row['cowstolen_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="cowstolen_update_link" style="color: #000080;" value="
                               <?php echo $row['cowstolen_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_cowstolen_cow_distribution($id) {

                $db = new dbconnection();
                $sql = "select   cowstolen.cow_distribution from cowstolen where cowstolen_id=:cowstolen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowstolen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['cow_distribution'];
                echo $field;
            }

            function get_chosen_cowstolen_date_stolen($id) {

                $db = new dbconnection();
                $sql = "select   cowstolen.date_stolen from cowstolen where cowstolen_id=:cowstolen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowstolen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date_stolen'];
                echo $field;
            }

            function get_chosen_cowstolen_returned($id) {

                $db = new dbconnection();
                $sql = "select   cowstolen.returned from cowstolen where cowstolen_id=:cowstolen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowstolen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['returned'];
                echo $field;
            }

            function get_chosen_cowstolen_date($id) {

                $db = new dbconnection();
                $sql = "select   cowstolen.date from cowstolen where cowstolen_id=:cowstolen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowstolen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date'];
                echo $field;
            }

            function get_chosen_cowstolen_user($id) {

                $db = new dbconnection();
                $sql = "select   cowstolen.user from cowstolen where cowstolen_id=:cowstolen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowstolen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function get_chosen_cowstolen_comments($id) {

                $db = new dbconnection();
                $sql = "select   cowstolen.comments from cowstolen where cowstolen_id=:cowstolen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowstolen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['comments'];
                echo $field;
            }

            function get_chosen_cowstolen_info_source($id) {

                $db = new dbconnection();
                $sql = "select   cowstolen.info_source from cowstolen where cowstolen_id=:cowstolen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowstolen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['info_source'];
                echo $field;
            }

            function get_chosen_cowstolen_seen($id) {

                $db = new dbconnection();
                $sql = "select   cowstolen.seen from cowstolen where cowstolen_id=:cowstolen_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowstolen_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['seen'];
                echo $field;
            }

            function All_cowstolen() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  cowstolen_id   from cowstolen";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_cowstolen() {
                $con = new dbconnection();
                $sql = "select cowstolen.cowstolen_id from cowstolen
                    order by cowstolen.cowstolen_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowstolen_id'];
                return $first_rec;
            }

            function get_last_cowstolen() {
                $con = new dbconnection();
                $sql = "select cowstolen.cowstolen_id from cowstolen
                    order by cowstolen.cowstolen_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowstolen_id'];
                return $first_rec;
            }

            function list_cowdead($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cowdead";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> cowdead </td>
                        <td> null </td><td> Date Dead </td><td> Reason </td><td> Comments </td><td> User </td><td> Date </td><td> Info Source </td><td> Seen </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['cowdead_id']; ?>
                        </td>
                        <td class="cow_distribution_id_cols cowdead " title="cowdead" >
                            <?php echo $this->_e($row['cow_distribution']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date_dead']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['reason_death']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['comments']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['user']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['info_source']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['seen']); ?>
                        </td>


                        <td>
                            <a href="#" class="cowdead_delete_link" style="color: #000080;" data-id_delete="cowdead_id"  data-table="
                               <?php echo $row['cowdead_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="cowdead_update_link" style="color: #000080;" value="
                               <?php echo $row['cowdead_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_cowdead_cow_distribution($id) {

                $db = new dbconnection();
                $sql = "select   cowdead.cow_distribution from cowdead where cowdead_id=:cowdead_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowdead_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['cow_distribution'];
                echo $field;
            }

            function get_chosen_cowdead_date_dead($id) {

                $db = new dbconnection();
                $sql = "select   cowdead.date_dead from cowdead where cowdead_id=:cowdead_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowdead_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date_dead'];
                echo $field;
            }

            function get_chosen_cowdead_reason_death($id) {

                $db = new dbconnection();
                $sql = "select   cowdead.reason_death from cowdead where cowdead_id=:cowdead_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowdead_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['reason_death'];
                echo $field;
            }

            function get_chosen_cowdead_comments($id) {

                $db = new dbconnection();
                $sql = "select   cowdead.comments from cowdead where cowdead_id=:cowdead_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowdead_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['comments'];
                echo $field;
            }

            function get_chosen_cowdead_user($id) {

                $db = new dbconnection();
                $sql = "select   cowdead.user from cowdead where cowdead_id=:cowdead_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowdead_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function get_chosen_cowdead_date($id) {

                $db = new dbconnection();
                $sql = "select   cowdead.date from cowdead where cowdead_id=:cowdead_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowdead_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date'];
                echo $field;
            }

            function get_chosen_cowdead_info_source($id) {

                $db = new dbconnection();
                $sql = "select   cowdead.info_source from cowdead where cowdead_id=:cowdead_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowdead_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['info_source'];
                echo $field;
            }

            function get_chosen_cowdead_seen($id) {

                $db = new dbconnection();
                $sql = "select   cowdead.seen from cowdead where cowdead_id=:cowdead_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowdead_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['seen'];
                echo $field;
            }

            function All_cowdead() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  cowdead_id   from cowdead";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_cowdead() {
                $con = new dbconnection();
                $sql = "select cowdead.cowdead_id from cowdead
                    order by cowdead.cowdead_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowdead_id'];
                return $first_rec;
            }

            function get_last_cowdead() {
                $con = new dbconnection();
                $sql = "select cowdead.cowdead_id from cowdead
                    order by cowdead.cowdead_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowdead_id'];
                return $first_rec;
            }

            function list_cowtreatment($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cowtreatment";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> cowtreatment </td>
                        <td> null </td><td> symptomology </td><td> Interventions </td><td> Comments </td><td> Treatment Date </td><td> User </td><td> Date </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['cowtreatment_id']; ?>
                        </td>
                        <td class="cow_distribution_id_cols cowtreatment " title="cowtreatment" >
                            <?php echo $this->_e($row['cow_distribution']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['symptomology']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['interventions']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['comments']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date_treatment']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['user']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date']); ?>
                        </td>


                        <td>
                            <a href="#" class="cowtreatment_delete_link" style="color: #000080;" data-id_delete="cowtreatment_id"  data-table="
                               <?php echo $row['cowtreatment_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="cowtreatment_update_link" style="color: #000080;" value="
                               <?php echo $row['cowtreatment_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_cowtreatment_cow_distribution($id) {

                $db = new dbconnection();
                $sql = "select   cowtreatment.cow_distribution from cowtreatment where cowtreatment_id=:cowtreatment_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowtreatment_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['cow_distribution'];
                echo $field;
            }

            function get_chosen_cowtreatment_symptomology($id) {

                $db = new dbconnection();
                $sql = "select   cowtreatment.symptomology from cowtreatment where cowtreatment_id=:cowtreatment_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowtreatment_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['symptomology'];
                echo $field;
            }

            function get_chosen_cowtreatment_interventions($id) {

                $db = new dbconnection();
                $sql = "select   cowtreatment.interventions from cowtreatment where cowtreatment_id=:cowtreatment_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowtreatment_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['interventions'];
                echo $field;
            }

            function get_chosen_cowtreatment_comments($id) {

                $db = new dbconnection();
                $sql = "select   cowtreatment.comments from cowtreatment where cowtreatment_id=:cowtreatment_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowtreatment_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['comments'];
                echo $field;
            }

            function get_chosen_cowtreatment_date_treatment($id) {

                $db = new dbconnection();
                $sql = "select   cowtreatment.date_treatment from cowtreatment where cowtreatment_id=:cowtreatment_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowtreatment_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date_treatment'];
                echo $field;
            }

            function get_chosen_cowtreatment_user($id) {

                $db = new dbconnection();
                $sql = "select   cowtreatment.user from cowtreatment where cowtreatment_id=:cowtreatment_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowtreatment_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function get_chosen_cowtreatment_date($id) {

                $db = new dbconnection();
                $sql = "select   cowtreatment.date from cowtreatment where cowtreatment_id=:cowtreatment_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cowtreatment_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date'];
                echo $field;
            }

            function All_cowtreatment() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  cowtreatment_id   from cowtreatment";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_cowtreatment() {
                $con = new dbconnection();
                $sql = "select cowtreatment.cowtreatment_id from cowtreatment
                    order by cowtreatment.cowtreatment_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowtreatment_id'];
                return $first_rec;
            }

            function get_last_cowtreatment() {
                $con = new dbconnection();
                $sql = "select cowtreatment.cowtreatment_id from cowtreatment
                    order by cowtreatment.cowtreatment_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cowtreatment_id'];
                return $first_rec;
            }

            function list_roles($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from roles";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> roles </td>
                        <td> Name </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['roles_id']; ?>
                        </td>
                        <td class="name_id_cols roles " title="roles" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>


                        <td>
                            <a href="#" class="roles_delete_link" style="color: #000080;" data-id_delete="roles_id"  data-table="
                               <?php echo $row['roles_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="roles_update_link" style="color: #000080;" value="
                               <?php echo $row['roles_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_roles_name($id) {

                $db = new dbconnection();
                $sql = "select   roles.name from roles where roles_id=:roles_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':roles_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function All_roles() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  roles_id   from roles";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_roles() {
                $con = new dbconnection();
                $sql = "select roles.roles_id from roles
                    order by roles.roles_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['roles_id'];
                return $first_rec;
            }

            function get_last_roles() {
                $con = new dbconnection();
                $sql = "select roles.roles_id from roles
                    order by roles.roles_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['roles_id'];
                return $first_rec;
            }

            function list_sector_uesrs($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from sector_uesrs";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> sector_uesrs </td>
                        <td> null </td><td> null </td><td> null </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['sector_uesrs_id']; ?>
                        </td>
                        <td class="users_id_cols sector_uesrs " title="sector_uesrs" >
                            <?php echo $this->_e($row['users']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['role']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['sector']); ?>
                        </td>


                        <td>
                            <a href="#" class="sector_uesrs_delete_link" style="color: #000080;" data-id_delete="sector_uesrs_id"  data-table="
                               <?php echo $row['sector_uesrs_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="sector_uesrs_update_link" style="color: #000080;" value="
                               <?php echo $row['sector_uesrs_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_sector_uesrs_users($id) {

                $db = new dbconnection();
                $sql = "select   sector_uesrs.users from sector_uesrs where sector_uesrs_id=:sector_uesrs_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':sector_uesrs_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['users'];
                echo $field;
            }

            function get_chosen_sector_uesrs_role($id) {

                $db = new dbconnection();
                $sql = "select   sector_uesrs.role from sector_uesrs where sector_uesrs_id=:sector_uesrs_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':sector_uesrs_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['role'];
                echo $field;
            }

            function get_chosen_sector_uesrs_sector($id) {

                $db = new dbconnection();
                $sql = "select   sector_uesrs.sector from sector_uesrs where sector_uesrs_id=:sector_uesrs_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':sector_uesrs_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['sector'];
                echo $field;
            }

            function All_sector_uesrs() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  sector_uesrs_id   from sector_uesrs";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_sector_uesrs() {
                $con = new dbconnection();
                $sql = "select sector_uesrs.sector_uesrs_id from sector_uesrs
                    order by sector_uesrs.sector_uesrs_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['sector_uesrs_id'];
                return $first_rec;
            }

            function get_last_sector_uesrs() {
                $con = new dbconnection();
                $sql = "select sector_uesrs.sector_uesrs_id from sector_uesrs
                    order by sector_uesrs.sector_uesrs_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['sector_uesrs_id'];
                return $first_rec;
            }

            function list_cell_users($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cell_users";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> cell_users </td>
                        <td> null </td><td> null </td><td> null </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['cell_users_id']; ?>
                        </td>
                        <td class="user_id_cols cell_users " title="cell_users" >
                            <?php echo $this->_e($row['user']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['cell']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['role']); ?>
                        </td>


                        <td>
                            <a href="#" class="cell_users_delete_link" style="color: #000080;" data-id_delete="cell_users_id"  data-table="
                               <?php echo $row['cell_users_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="cell_users_update_link" style="color: #000080;" value="
                               <?php echo $row['cell_users_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_cell_users_user($id) {

                $db = new dbconnection();
                $sql = "select   cell_users.user from cell_users where cell_users_id=:cell_users_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cell_users_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function get_chosen_cell_users_cell($id) {

                $db = new dbconnection();
                $sql = "select   cell_users.cell from cell_users where cell_users_id=:cell_users_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cell_users_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['cell'];
                echo $field;
            }

            function get_chosen_cell_users_role($id) {

                $db = new dbconnection();
                $sql = "select   cell_users.role from cell_users where cell_users_id=:cell_users_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cell_users_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['role'];
                echo $field;
            }

            function All_cell_users() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  cell_users_id   from cell_users";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_cell_users() {
                $con = new dbconnection();
                $sql = "select cell_users.cell_users_id from cell_users
                    order by cell_users.cell_users_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cell_users_id'];
                return $first_rec;
            }

            function get_last_cell_users() {
                $con = new dbconnection();
                $sql = "select cell_users.cell_users_id from cell_users
                    order by cell_users.cell_users_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cell_users_id'];
                return $first_rec;
            }

            function list_village_users($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from village_users";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> village_users </td>
                        <td> null </td><td> null </td><td> null </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['village_users_id']; ?>
                        </td>
                        <td class="user_id_cols village_users " title="village_users" >
                            <?php echo $this->_e($row['user']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['village']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['role']); ?>
                        </td>


                        <td>
                            <a href="#" class="village_users_delete_link" style="color: #000080;" data-id_delete="village_users_id"  data-table="
                               <?php echo $row['village_users_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="village_users_update_link" style="color: #000080;" value="
                               <?php echo $row['village_users_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_village_users_user($id) {

                $db = new dbconnection();
                $sql = "select   village_users.user from village_users where village_users_id=:village_users_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':village_users_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function get_chosen_village_users_village($id) {

                $db = new dbconnection();
                $sql = "select   village_users.village from village_users where village_users_id=:village_users_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':village_users_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['village'];
                echo $field;
            }

            function get_chosen_village_users_role($id) {

                $db = new dbconnection();
                $sql = "select   village_users.role from village_users where village_users_id=:village_users_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':village_users_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['role'];
                echo $field;
            }

            function All_village_users() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  village_users_id   from village_users";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_village_users() {
                $con = new dbconnection();
                $sql = "select village_users.village_users_id from village_users
                    order by village_users.village_users_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['village_users_id'];
                return $first_rec;
            }

            function get_last_village_users() {
                $con = new dbconnection();
                $sql = "select village_users.village_users_id from village_users
                    order by village_users.village_users_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['village_users_id'];
                return $first_rec;
            }

            function list_district_users($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from district_users";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> district_users </td>
                        <td> null </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['district_users_id']; ?>
                        </td>
                        <td class="user_id_cols district_users " title="district_users" >
                            <?php echo $this->_e($row['user']); ?>
                        </td>


                        <td>
                            <a href="#" class="district_users_delete_link" style="color: #000080;" data-id_delete="district_users_id"  data-table="
                               <?php echo $row['district_users_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="district_users_update_link" style="color: #000080;" value="
                               <?php echo $row['district_users_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_district_users_user($id) {

                $db = new dbconnection();
                $sql = "select   district_users.user from district_users where district_users_id=:district_users_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':district_users_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function All_district_users() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  district_users_id   from district_users";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_district_users() {
                $con = new dbconnection();
                $sql = "select district_users.district_users_id from district_users
                    order by district_users.district_users_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['district_users_id'];
                return $first_rec;
            }

            function get_last_district_users() {
                $con = new dbconnection();
                $sql = "select district_users.district_users_id from district_users
                    order by district_users.district_users_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['district_users_id'];
                return $first_rec;
            }

            function list_user_cat($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from user_cat";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> user_cat </td>
                        <td> name </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['user_cat_id']; ?>
                        </td>
                        <td class="name_id_cols user_cat " title="user_cat" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>


                        <td>
                            <a href="#" class="user_cat_delete_link" style="color: #000080;" data-id_delete="user_cat_id"  data-table="
                               <?php echo $row['user_cat_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="user_cat_update_link" style="color: #000080;" value="
                               <?php echo $row['user_cat_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_user_cat_name($id) {

                $db = new dbconnection();
                $sql = "select   user_cat.name from user_cat where user_cat_id=:user_cat_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':user_cat_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function All_user_cat() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  user_cat_id   from user_cat";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_user_cat() {
                $con = new dbconnection();
                $sql = "select user_cat.user_cat_id from user_cat
                    order by user_cat.user_cat_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['user_cat_id'];
                return $first_rec;
            }

            function get_last_user_cat() {
                $con = new dbconnection();
                $sql = "select user_cat.user_cat_id from user_cat
                    order by user_cat.user_cat_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['user_cat_id'];
                return $first_rec;
            }

            function list_sector($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from sector";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> sector </td>
                        <td> Name </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['sector_id']; ?>
                        </td>
                        <td class="name_id_cols sector " title="sector" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>


                        <td>
                            <a href="#" class="sector_delete_link" style="color: #000080;" data-id_delete="sector_id"  data-table="
                               <?php echo $row['sector_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="sector_update_link" style="color: #000080;" value="
                               <?php echo $row['sector_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_sector_name($id) {

                $db = new dbconnection();
                $sql = "select   sector.name from sector where sector_id=:sector_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':sector_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function All_sector() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  sector_id   from sector";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_sector() {
                $con = new dbconnection();
                $sql = "select sector.sector_id from sector
                    order by sector.sector_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['sector_id'];
                return $first_rec;
            }

            function get_last_sector() {
                $con = new dbconnection();
                $sql = "select sector.sector_id from sector
                    order by sector.sector_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['sector_id'];
                return $first_rec;
            }

            function list_cell($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from cell";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> cell </td>
                        <td> Name </td><td> Sector </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['cell_id']; ?>
                        </td>
                        <td class="name_id_cols cell " title="cell" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['sector']); ?>
                        </td>


                        <td>
                            <a href="#" class="cell_delete_link" style="color: #000080;" data-id_delete="cell_id"  data-table="
                               <?php echo $row['cell_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="cell_update_link" style="color: #000080;" value="
                               <?php echo $row['cell_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_cell_name($id) {

                $db = new dbconnection();
                $sql = "select   cell.name from cell where cell_id=:cell_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cell_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function get_chosen_cell_sector($id) {

                $db = new dbconnection();
                $sql = "select   cell.sector from cell where cell_id=:cell_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':cell_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['sector'];
                echo $field;
            }

            function All_cell() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  cell_id   from cell";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_cell() {
                $con = new dbconnection();
                $sql = "select cell.cell_id from cell
                    order by cell.cell_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cell_id'];
                return $first_rec;
            }

            function get_last_cell() {
                $con = new dbconnection();
                $sql = "select cell.cell_id from cell
                    order by cell.cell_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['cell_id'];
                return $first_rec;
            }

            function list_insemination($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from insemination";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> insemination </td>
                        <td> Date </td><td> user </td><td> Auto or Brought </td><td> Type of Semen </td><td> Certificate Number </td><td> Comments </td><td> Tag Number </td><td> Insemination Date </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['insemination_id']; ?>
                        </td>
                        <td class="date_id_cols insemination " title="insemination" >
                            <?php echo $this->_e($row['date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['user']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['auto_brought']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['type_semen']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['certif_number']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['comments']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['tag_number']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['insemin_date']); ?>
                        </td>


                        <td>
                            <a href="#" class="insemination_delete_link" style="color: #000080;" data-id_delete="insemination_id"  data-table="
                               <?php echo $row['insemination_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="insemination_update_link" style="color: #000080;" value="
                               <?php echo $row['insemination_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_insemination_date($id) {

                $db = new dbconnection();
                $sql = "select   insemination.date from insemination where insemination_id=:insemination_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':insemination_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date'];
                echo $field;
            }

            function get_chosen_insemination_user($id) {

                $db = new dbconnection();
                $sql = "select   insemination.user from insemination where insemination_id=:insemination_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':insemination_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function get_chosen_insemination_auto_brought($id) {

                $db = new dbconnection();
                $sql = "select   insemination.auto_brought from insemination where insemination_id=:insemination_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':insemination_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['auto_brought'];
                echo $field;
            }

            function get_chosen_insemination_type_semen($id) {

                $db = new dbconnection();
                $sql = "select   insemination.type_semen from insemination where insemination_id=:insemination_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':insemination_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['type_semen'];
                echo $field;
            }

            function get_chosen_insemination_certif_number($id) {

                $db = new dbconnection();
                $sql = "select   insemination.certif_number from insemination where insemination_id=:insemination_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':insemination_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['certif_number'];
                echo $field;
            }

            function get_chosen_insemination_comments($id) {

                $db = new dbconnection();
                $sql = "select   insemination.comments from insemination where insemination_id=:insemination_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':insemination_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['comments'];
                echo $field;
            }

            function get_chosen_insemination_tag_number($id) {

                $db = new dbconnection();
                $sql = "select   insemination.tag_number from insemination where insemination_id=:insemination_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':insemination_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['tag_number'];
                echo $field;
            }

            function get_chosen_insemination_insemin_date($id) {

                $db = new dbconnection();
                $sql = "select   insemination.insemin_date from insemination where insemination_id=:insemination_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':insemination_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['insemin_date'];
                echo $field;
            }

            function All_insemination() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  insemination_id   from insemination";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_insemination() {
                $con = new dbconnection();
                $sql = "select insemination.insemination_id from insemination
                    order by insemination.insemination_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['insemination_id'];
                return $first_rec;
            }

            function get_last_insemination() {
                $con = new dbconnection();
                $sql = "select insemination.insemination_id from insemination
                    order by insemination.insemination_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['insemination_id'];
                return $first_rec;
            }

            function list_visit_event($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from visit_event";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> visit_event </td>
                        <td> date </td><td> Date </td><td> User </td><td> Picture </td><td> Description </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['visit_event_id']; ?>
                        </td>
                        <td class="event_date_id_cols visit_event " title="visit_event" >
                            <?php echo $this->_e($row['event_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['user']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['imageid']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['description']); ?>
                        </td>


                        <td>
                            <a href="#" class="visit_event_delete_link" style="color: #000080;" data-id_delete="visit_event_id"  data-table="
                               <?php echo $row['visit_event_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="visit_event_update_link" style="color: #000080;" value="
                               <?php echo $row['visit_event_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_visit_event_event_date($id) {

                $db = new dbconnection();
                $sql = "select   visit_event.event_date from visit_event where visit_event_id=:visit_event_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':visit_event_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['event_date'];
                echo $field;
            }

            function get_chosen_visit_event_date($id) {

                $db = new dbconnection();
                $sql = "select   visit_event.date from visit_event where visit_event_id=:visit_event_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':visit_event_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date'];
                echo $field;
            }

            function get_chosen_visit_event_user($id) {

                $db = new dbconnection();
                $sql = "select   visit_event.user from visit_event where visit_event_id=:visit_event_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':visit_event_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['user'];
                echo $field;
            }

            function get_chosen_visit_event_imageid($id) {

                $db = new dbconnection();
                $sql = "select   visit_event.imageid from visit_event where visit_event_id=:visit_event_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':visit_event_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['imageid'];
                echo $field;
            }

            function get_chosen_visit_event_description($id) {

                $db = new dbconnection();
                $sql = "select   visit_event.description from visit_event where visit_event_id=:visit_event_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':visit_event_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['description'];
                echo $field;
            }

            function All_visit_event() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  visit_event_id   from visit_event";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_visit_event() {
                $con = new dbconnection();
                $sql = "select visit_event.visit_event_id from visit_event
                    order by visit_event.visit_event_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['visit_event_id'];
                return $first_rec;
            }

            function get_last_visit_event() {
                $con = new dbconnection();
                $sql = "select visit_event.visit_event_id from visit_event
                    order by visit_event.visit_event_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['visit_event_id'];
                return $first_rec;
            }

            function list_images($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from images";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> images </td>
                        <td> path </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['images_id']; ?>
                        </td>
                        <td class="path_id_cols images " title="images" >
                            <?php echo $this->_e($row['path']); ?>
                        </td>


                        <td>
                            <a href="#" class="images_delete_link" style="color: #000080;" data-id_delete="images_id"  data-table="
                               <?php echo $row['images_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="images_update_link" style="color: #000080;" value="
                               <?php echo $row['images_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_images_path($id) {

                $db = new dbconnection();
                $sql = "select   images.path from images where images_id=:images_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':images_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['path'];
                echo $field;
            }

            function All_images() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  images_id   from images";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_images() {
                $con = new dbconnection();
                $sql = "select images.images_id from images
                    order by images.images_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['images_id'];
                return $first_rec;
            }

            function get_last_images() {
                $con = new dbconnection();
                $sql = "select images.images_id from images
                    order by images.images_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['images_id'];
                return $first_rec;
            }

            function list_kwakwa_inka($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from kwakwa_inka";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> kwakwa_inka </td>
                        <td> Entry Date </td><td> User </td><td> old_citizien </td><td> new_citizen </td><td> comments </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['kwakwa_inka_id']; ?>
                        </td>
                        <td class="entry_date_id_cols kwakwa_inka " title="kwakwa_inka" >
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['old_citizen']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['new_citizen']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['comments']); ?>
                        </td>


                        <td>
                            <a href="#" class="kwakwa_inka_delete_link" style="color: #000080;" data-id_delete="kwakwa_inka_id"  data-table="
                               <?php echo $row['kwakwa_inka_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="kwakwa_inka_update_link" style="color: #000080;" value="
                               <?php echo $row['kwakwa_inka_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_kwakwa_inka_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   kwakwa_inka.entry_date from kwakwa_inka where kwakwa_inka_id=:kwakwa_inka_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':kwakwa_inka_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_kwakwa_inka_User($id) {

                $db = new dbconnection();
                $sql = "select   kwakwa_inka.User from kwakwa_inka where kwakwa_inka_id=:kwakwa_inka_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':kwakwa_inka_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function get_chosen_kwakwa_inka_old_citizen($id) {

                $db = new dbconnection();
                $sql = "select   kwakwa_inka.old_citizen from kwakwa_inka where kwakwa_inka_id=:kwakwa_inka_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':kwakwa_inka_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['old_citizen'];
                echo $field;
            }

            function get_chosen_kwakwa_inka_new_citizen($id) {

                $db = new dbconnection();
                $sql = "select   kwakwa_inka.new_citizen from kwakwa_inka where kwakwa_inka_id=:kwakwa_inka_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':kwakwa_inka_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['new_citizen'];
                echo $field;
            }

            function get_chosen_kwakwa_inka_comments($id) {

                $db = new dbconnection();
                $sql = "select   kwakwa_inka.comments from kwakwa_inka where kwakwa_inka_id=:kwakwa_inka_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':kwakwa_inka_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['comments'];
                echo $field;
            }

            function All_kwakwa_inka() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  kwakwa_inka_id   from kwakwa_inka";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_kwakwa_inka() {
                $con = new dbconnection();
                $sql = "select kwakwa_inka.kwakwa_inka_id from kwakwa_inka
                    order by kwakwa_inka.kwakwa_inka_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['kwakwa_inka_id'];
                return $first_rec;
            }

            function get_last_kwakwa_inka() {
                $con = new dbconnection();
                $sql = "select kwakwa_inka.kwakwa_inka_id from kwakwa_inka
                    order by kwakwa_inka.kwakwa_inka_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['kwakwa_inka_id'];
                return $first_rec;
            }

            function list_sickcow($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from sickcow";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> sickcow </td>
                        <td> Distribution </td><td> Sickness </td><td> Entry Date </td><td> User </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['sickcow_id']; ?>
                        </td>
                        <td class="distribution_id_cols sickcow " title="sickcow" >
                            <?php echo $this->_e($row['distribution']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['sickness']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>


                        <td>
                            <a href="#" class="sickcow_delete_link" style="color: #000080;" data-id_delete="sickcow_id"  data-table="
                               <?php echo $row['sickcow_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="sickcow_update_link" style="color: #000080;" value="
                               <?php echo $row['sickcow_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_sickcow_distribution($id) {

                $db = new dbconnection();
                $sql = "select   sickcow.distribution from sickcow where sickcow_id=:sickcow_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':sickcow_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['distribution'];
                echo $field;
            }

            function get_chosen_sickcow_sickness($id) {

                $db = new dbconnection();
                $sql = "select   sickcow.sickness from sickcow where sickcow_id=:sickcow_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':sickcow_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['sickness'];
                echo $field;
            }

            function get_chosen_sickcow_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   sickcow.entry_date from sickcow where sickcow_id=:sickcow_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':sickcow_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_sickcow_User($id) {

                $db = new dbconnection();
                $sql = "select   sickcow.User from sickcow where sickcow_id=:sickcow_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':sickcow_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function All_sickcow() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  sickcow_id   from sickcow";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_sickcow() {
                $con = new dbconnection();
                $sql = "select sickcow.sickcow_id from sickcow
                    order by sickcow.sickcow_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['sickcow_id'];
                return $first_rec;
            }

            function get_last_sickcow() {
                $con = new dbconnection();
                $sql = "select sickcow.sickcow_id from sickcow
                    order by sickcow.sickcow_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['sickcow_id'];
                return $first_rec;
            }

            function get_type_in_combo() {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select type.type_id,   type.name from type";
                ?>
            <select class="textbox cbo_type"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['type_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_sector_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select sector.sector_id,   sector.name from sector";
            ?>
            <select class="textbox cbo_sector"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_cell_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select cell.cell_id,   cell.name from cell";
            ?>
            <select class="textbox cbo_cell"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['cell_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_fname_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select fname.fname_id,   fname.name from fname";
            ?>
            <select class="textbox cbo_fname"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['fname_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_villiage_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select villiage.villiage_id,   villiage.name from villiage";
            ?>
            <select class="textbox cbo_villiage"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['villiage_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_account_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select account.account_id,   account.name from account";
            ?>
            <select class="textbox cbo_account"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_distribution_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select distribution.distribution_id,   distribution.name from distribution";
            ?>
            <select class="textbox cbo_distribution"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['distribution_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_citizen_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select citizen.citizen_id,   citizen.name from citizen";
            ?>
            <select class="textbox cbo_citizen"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['citizen_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_donor_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select donor.donor_id,   donor.name from donor";
            ?>
            <select class="textbox cbo_donor"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['donor_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_citizen_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select citizen.citizen_id,   citizen.name from citizen";
            ?>
            <select class="textbox cbo_citizen"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['citizen_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_cowidentf_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select cowidentf.cowidentf_id,   cowidentf.name from cowidentf";
            ?>
            <select class="textbox cbo_cowidentf"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['cowidentf_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_User_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select User.User_id,   User.name from User";
            ?>
            <select class="textbox cbo_User"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['User_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_citizen_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select citizen.citizen_id,   citizen.name from citizen";
            ?>
            <select class="textbox cbo_citizen"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['citizen_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_cowborn_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select cowborn.cowborn_id,   cowborn.name from cowborn";
            ?>
            <select class="textbox cbo_cowborn"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['cowborn_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_distribution_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select distribution.distribution_id,   distribution.name from distribution";
            ?>
            <select class="textbox cbo_distribution"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['distribution_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_cow_distribution_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select cow_distribution.cow_distribution_id,   cow_distribution.name from cow_distribution";
            ?>
            <select class="textbox cbo_cow_distribution"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['cow_distribution_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_cow_distribution_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select cow_distribution.cow_distribution_id,   cow_distribution.name from cow_distribution";
            ?>
            <select class="textbox cbo_cow_distribution"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['cow_distribution_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_cow_distribution_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select cow_distribution.cow_distribution_id,   cow_distribution.name from cow_distribution";
            ?>
            <select class="textbox cbo_cow_distribution"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['cow_distribution_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_cow_distribution_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select cow_distribution.cow_distribution_id,   cow_distribution.name from cow_distribution";
            ?>
            <select class="textbox cbo_cow_distribution"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['cow_distribution_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_users_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select users.users_id,   users.name from users";
            ?>
            <select class="textbox cbo_users"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['users_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_role_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select role.role_id,   role.name from role";
            ?>
            <select class="textbox cbo_role"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['role_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_sector_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select sector.sector_id,   sector.name from sector";
            ?>
            <select class="textbox cbo_sector"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_cell_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select cell.cell_id,   cell.name from cell";
            ?>
            <select class="textbox cbo_cell"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['cell_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_role_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select role.role_id,   role.name from role";
            ?>
            <select class="textbox cbo_role"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['role_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_village_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select village.village_id,   village.name from village";
            ?>
            <select class="textbox cbo_village"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['village_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_role_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select role.role_id,   role.name from role";
            ?>
            <select class="textbox cbo_role"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['role_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_sector_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select sector.sector_id,   sector.name from sector";
            ?>
            <select class="textbox cbo_sector"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_user_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select user.user_id,   user.name from user";
            ?>
            <select class="textbox cbo_user"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['user_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_imageid_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select imageid.imageid_id,   imageid.name from imageid";
            ?>
            <select class="textbox cbo_imageid"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['imageid_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_old_citizen_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select old_citizen.old_citizen_id,   old_citizen.name from old_citizen";
            ?>
            <select class="textbox cbo_old_citizen"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['old_citizen_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_new_citizen_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select new_citizen.new_citizen_id,   new_citizen.name from new_citizen";
            ?>
            <select class="textbox cbo_new_citizen"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['new_citizen_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_distribution_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select distribution.distribution_id,   distribution.name from distribution";
            ?>
            <select class="textbox cbo_distribution"><option></option>
                    <?php
                    foreach ($db->query($sql) as $row) {
                        echo "<option value=" . $row['distribution_id'] . ">" . $row['name'] . " </option>";
                    }
                    ?>
            </select>
            <?php
        }

        function _e($string) {
            echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
        }

    }
    