<?php 
require_once 'connection.php';
class deletions{


 function deleteFrom_user( $user_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM user where user_id =:user_id");
$smt->bindValue(':user_id',$user_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_sector( $sector_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM sector where sector_id =:sector_id");
$smt->bindValue(':sector_id',$sector_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cell( $cell_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cell where cell_id =:cell_id");
$smt->bindValue(':cell_id',$cell_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_village( $village_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM village where village_id =:village_id");
$smt->bindValue(':village_id',$village_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_citizen( $citizen_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM citizen where citizen_id =:citizen_id");
$smt->bindValue(':citizen_id',$citizen_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cowmovement( $cowmovement_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cowmovement where cowmovement_id =:cowmovement_id");
$smt->bindValue(':cowmovement_id',$cowmovement_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cowidentification( $cowidentification_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cowidentification where cowidentification_id =:cowidentification_id");
$smt->bindValue(':cowidentification_id',$cowidentification_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cow_distribution( $cow_distribution_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cow_distribution where cow_distribution_id =:cow_distribution_id");
$smt->bindValue(':cow_distribution_id',$cow_distribution_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cowdonor( $cowdonor_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cowdonor where cowdonor_id =:cowdonor_id");
$smt->bindValue(':cowdonor_id',$cowdonor_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_newborn_distribution( $newborn_distribution_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM newborn_distribution where newborn_distribution_id =:newborn_distribution_id");
$smt->bindValue(':newborn_distribution_id',$newborn_distribution_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cowsold( $cowsold_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cowsold where cowsold_id =:cowsold_id");
$smt->bindValue(':cowsold_id',$cowsold_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cowborn( $cowborn_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cowborn where cowborn_id =:cowborn_id");
$smt->bindValue(':cowborn_id',$cowborn_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cowstolen( $cowstolen_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cowstolen where cowstolen_id =:cowstolen_id");
$smt->bindValue(':cowstolen_id',$cowstolen_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cowdead( $cowdead_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cowdead where cowdead_id =:cowdead_id");
$smt->bindValue(':cowdead_id',$cowdead_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cowtreatment( $cowtreatment_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cowtreatment where cowtreatment_id =:cowtreatment_id");
$smt->bindValue(':cowtreatment_id',$cowtreatment_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_roles( $roles_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM roles where roles_id =:roles_id");
$smt->bindValue(':roles_id',$roles_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_sector_uesrs( $sector_uesrs_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM sector_uesrs where sector_uesrs_id =:sector_uesrs_id");
$smt->bindValue(':sector_uesrs_id',$sector_uesrs_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cell_users( $cell_users_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cell_users where cell_users_id =:cell_users_id");
$smt->bindValue(':cell_users_id',$cell_users_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_village_users( $village_users_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM village_users where village_users_id =:village_users_id");
$smt->bindValue(':village_users_id',$village_users_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_district_users( $district_users_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM district_users where district_users_id =:district_users_id");
$smt->bindValue(':district_users_id',$district_users_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_user_cat( $user_cat_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM user_cat where user_cat_id =:user_cat_id");
$smt->bindValue(':user_cat_id',$user_cat_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_sector( $sector_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM sector where sector_id =:sector_id");
$smt->bindValue(':sector_id',$sector_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_cell( $cell_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM cell where cell_id =:cell_id");
$smt->bindValue(':cell_id',$cell_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_insemination( $insemination_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM insemination where insemination_id =:insemination_id");
$smt->bindValue(':insemination_id',$insemination_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_visit_event( $visit_event_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM visit_event where visit_event_id =:visit_event_id");
$smt->bindValue(':visit_event_id',$visit_event_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_images( $images_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM images where images_id =:images_id");
$smt->bindValue(':images_id',$images_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_kwakwa_inka( $kwakwa_inka_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM kwakwa_inka where kwakwa_inka_id =:kwakwa_inka_id");
$smt->bindValue(':kwakwa_inka_id',$kwakwa_inka_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_sickcow( $sickcow_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM sickcow where sickcow_id =:sickcow_id");
$smt->bindValue(':sickcow_id',$sickcow_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


}

