//<editor-fold defaultstate="collapsed" desc="these variables are used in the delete and update of the table records">
var table_update = '';
var id_delete = 0;
var current_del_btn = null;
//</editor-fold>
$(document).ready(function () {
get_new_data_hide_show();
show_form_toUpdate();
sickcow_del_udpate();
get_pages_moving();
dlog_btn_No_Yes();
hide_select_pane()
show_Y_N_dialog();
hide_Y_N_dialog()

        get_type_id_combo();        get_sector_id_combo();        get_cell_id_combo();        get_fname_id_combo();        get_villiage_id_combo();        get_account_id_combo();        get_distribution_id_combo();        get_citizen_id_combo();        get_user_id_combo();        get_donor_id_combo();        get_user_id_combo();        get_citizen_id_combo();        get_cowidentf_id_combo();        get_User_id_combo();        get_user_id_combo();        get_citizen_id_combo();        get_cowborn_id_combo();        get_user_id_combo();        get_distribution_id_combo();        get_user_id_combo();        get_cow_distribution_id_combo();        get_user_id_combo();        get_cow_distribution_id_combo();        get_user_id_combo();        get_cow_distribution_id_combo();        get_user_id_combo();        get_cow_distribution_id_combo();        get_user_id_combo();        get_users_id_combo();        get_role_id_combo();        get_sector_id_combo();        get_user_id_combo();        get_cell_id_combo();        get_role_id_combo();        get_user_id_combo();        get_village_id_combo();        get_role_id_combo();        get_user_id_combo();        get_sector_id_combo();        get_user_id_combo();        get_user_id_combo();        get_imageid_id_combo();        get_old_citizen_id_combo();        get_new_citizen_id_combo();        get_distribution_id_combo();


});

function get_type_id_combo() {
    try {
        $('.cbo_type').change(function () {
            var cbo_type = $('.cbo_type option:selected').val();
                $('#txt_type_id').val(cbo_type);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_sector_id_combo() {
    try {
        $('.cbo_sector').change(function () {
            var cbo_sector = $('.cbo_sector option:selected').val();
                $('#txt_sector_id').val(cbo_sector);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_cell_id_combo() {
    try {
        $('.cbo_cell').change(function () {
            var cbo_cell = $('.cbo_cell option:selected').val();
                $('#txt_cell_id').val(cbo_cell);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_fname_id_combo() {
    try {
        $('.cbo_fname').change(function () {
            var cbo_fname = $('.cbo_fname option:selected').val();
                $('#txt_fname_id').val(cbo_fname);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_villiage_id_combo() {
    try {
        $('.cbo_villiage').change(function () {
            var cbo_villiage = $('.cbo_villiage option:selected').val();
                $('#txt_villiage_id').val(cbo_villiage);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').val();
                $('#txt_account_id').val(cbo_account);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_distribution_id_combo() {
    try {
        $('.cbo_distribution').change(function () {
            var cbo_distribution = $('.cbo_distribution option:selected').val();
                $('#txt_distribution_id').val(cbo_distribution);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_citizen_id_combo() {
    try {
        $('.cbo_citizen').change(function () {
            var cbo_citizen = $('.cbo_citizen option:selected').val();
                $('#txt_citizen_id').val(cbo_citizen);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_donor_id_combo() {
    try {
        $('.cbo_donor').change(function () {
            var cbo_donor = $('.cbo_donor option:selected').val();
                $('#txt_donor_id').val(cbo_donor);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_citizen_id_combo() {
    try {
        $('.cbo_citizen').change(function () {
            var cbo_citizen = $('.cbo_citizen option:selected').val();
                $('#txt_citizen_id').val(cbo_citizen);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_cowidentf_id_combo() {
    try {
        $('.cbo_cowidentf').change(function () {
            var cbo_cowidentf = $('.cbo_cowidentf option:selected').val();
                $('#txt_cowidentf_id').val(cbo_cowidentf);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_User_id_combo() {
    try {
        $('.cbo_User').change(function () {
            var cbo_User = $('.cbo_User option:selected').val();
                $('#txt_User_id').val(cbo_User);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_citizen_id_combo() {
    try {
        $('.cbo_citizen').change(function () {
            var cbo_citizen = $('.cbo_citizen option:selected').val();
                $('#txt_citizen_id').val(cbo_citizen);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_cowborn_id_combo() {
    try {
        $('.cbo_cowborn').change(function () {
            var cbo_cowborn = $('.cbo_cowborn option:selected').val();
                $('#txt_cowborn_id').val(cbo_cowborn);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_distribution_id_combo() {
    try {
        $('.cbo_distribution').change(function () {
            var cbo_distribution = $('.cbo_distribution option:selected').val();
                $('#txt_distribution_id').val(cbo_distribution);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_cow_distribution_id_combo() {
    try {
        $('.cbo_cow_distribution').change(function () {
            var cbo_cow_distribution = $('.cbo_cow_distribution option:selected').val();
                $('#txt_cow_distribution_id').val(cbo_cow_distribution);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_cow_distribution_id_combo() {
    try {
        $('.cbo_cow_distribution').change(function () {
            var cbo_cow_distribution = $('.cbo_cow_distribution option:selected').val();
                $('#txt_cow_distribution_id').val(cbo_cow_distribution);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_cow_distribution_id_combo() {
    try {
        $('.cbo_cow_distribution').change(function () {
            var cbo_cow_distribution = $('.cbo_cow_distribution option:selected').val();
                $('#txt_cow_distribution_id').val(cbo_cow_distribution);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_cow_distribution_id_combo() {
    try {
        $('.cbo_cow_distribution').change(function () {
            var cbo_cow_distribution = $('.cbo_cow_distribution option:selected').val();
                $('#txt_cow_distribution_id').val(cbo_cow_distribution);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_users_id_combo() {
    try {
        $('.cbo_users').change(function () {
            var cbo_users = $('.cbo_users option:selected').val();
                $('#txt_users_id').val(cbo_users);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_role_id_combo() {
    try {
        $('.cbo_role').change(function () {
            var cbo_role = $('.cbo_role option:selected').val();
                $('#txt_role_id').val(cbo_role);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_sector_id_combo() {
    try {
        $('.cbo_sector').change(function () {
            var cbo_sector = $('.cbo_sector option:selected').val();
                $('#txt_sector_id').val(cbo_sector);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_cell_id_combo() {
    try {
        $('.cbo_cell').change(function () {
            var cbo_cell = $('.cbo_cell option:selected').val();
                $('#txt_cell_id').val(cbo_cell);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_role_id_combo() {
    try {
        $('.cbo_role').change(function () {
            var cbo_role = $('.cbo_role option:selected').val();
                $('#txt_role_id').val(cbo_role);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_village_id_combo() {
    try {
        $('.cbo_village').change(function () {
            var cbo_village = $('.cbo_village option:selected').val();
                $('#txt_village_id').val(cbo_village);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_role_id_combo() {
    try {
        $('.cbo_role').change(function () {
            var cbo_role = $('.cbo_role option:selected').val();
                $('#txt_role_id').val(cbo_role);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_sector_id_combo() {
    try {
        $('.cbo_sector').change(function () {
            var cbo_sector = $('.cbo_sector option:selected').val();
                $('#txt_sector_id').val(cbo_sector);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_user_id_combo() {
    try {
        $('.cbo_user').change(function () {
            var cbo_user = $('.cbo_user option:selected').val();
                $('#txt_user_id').val(cbo_user);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_imageid_id_combo() {
    try {
        $('.cbo_imageid').change(function () {
            var cbo_imageid = $('.cbo_imageid option:selected').val();
                $('#txt_imageid_id').val(cbo_imageid);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_old_citizen_id_combo() {
    try {
        $('.cbo_old_citizen').change(function () {
            var cbo_old_citizen = $('.cbo_old_citizen option:selected').val();
                $('#txt_old_citizen_id').val(cbo_old_citizen);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_new_citizen_id_combo() {
    try {
        $('.cbo_new_citizen').change(function () {
            var cbo_new_citizen = $('.cbo_new_citizen option:selected').val();
                $('#txt_new_citizen_id').val(cbo_new_citizen);
        });
    } catch (err) {
        alert(err.message);
    }
}function get_distribution_id_combo() {
    try {
        $('.cbo_distribution').change(function () {
            var cbo_distribution = $('.cbo_distribution option:selected').val();
                $('#txt_distribution_id').val(cbo_distribution);
        });
    } catch (err) {
        alert(err.message);
    }
}
function cancel_update() {
    $('.cancel_btn').unbind('click').click(function () {
        var cancel_update = $(this).data('cancel_name');
        $.post('../admin/handler.php', {cancel_update: cancel_update}, function (data) {
        }).complete(function () {
            window.location.reload();
        });
    });
}
function hide_Y_N_dialog() {//here the user will be confirming to delete the record
    $('#user_yes_btn,  .yes_dlg_btn').click(function () {
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {

        }).complete(function () {
            $('.y_n_dialog').fadeOut(300);
            current_del_btn.closest('tr').slideUp(400);
            $('.menu').show();
            window.location.reload();
        });
    });
    $('#no_btn, .no_btn').click(function () {
        $('.y_n_dialog').fadeOut(300);
        $('.menu').show();
    });

}function show_Y_N_dialog() {
    $('.y_n_dialog').fadeIn(200);
}
function get_new_data_hide_show(){
     $('.new_data_hider').click(function (){
         $('.new_data_box').slideToggle();
     });
    
}
function validate_numbers_textfields() {
  $('.only_numbers').keydown(function (e) {
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                        // Allow: Ctrl+A, Command+A
                                (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                                // Allow: home, end, left, right, down, up
                                        (e.keyCode >= 35 && e.keyCode <= 40)) {
                            // let it happen, don't do anything
                            return;
                        }
                        // Ensure that it is a number and stop the keypress
                        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                            e.preventDefault();
                        }
                    });   }
function hover_theme1() {
    $('.hover_theme1').mouseover(function () {
        $(this).css('background-color', '#29f15c');
        $(this).addClass('no_shade_noBorder');
        $(this).css('cursoer','pointer');
    });

    $('.hover_theme1').mouseleave(function () {
        $(this).css('background-color', 'transparent');
        $(this).removeClass('no_shade_noBorder');
    });
}
function show_form_toUpdate() {
    var updname=$('#txt_shall_expand_toUpdate').val();
    if (updname!='') {
          $('.new_data_box').delay(200).slideDown();
    }
        
}
function postDisplayData(call_dialog,div) {
    $.post('../Admin/handler.php', {call_dialog: call_dialog}, function (data) {
        $(div).html(data);
    }).complete(function () {
        $('.msg_dialog').slideDown(300);
    });
}function dlog_btn_No_Yes() {
    $('#dlog_btnNo').unbind('click').click(function () {
        alert('Confirmed!');
    });
    $('#dlog_btnYs').unbind('click').click(function () {
         alert('Declined!');
    });
}function hide_select_pane() {
    $('.foreign_select').unbind('click').click(function () {
        $(this).fadeOut(200);
        $('.dialog').hide("drop", {direction: 'up'}, 500,
                (function () {
                    $('.menu').show();
                }));
    });

}

//update from user ...
 
function user_del_udpate(){
$('.user_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.user').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromuser.. 
 $('.user_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from sector ...
 
function sector_del_udpate(){
$('.sector_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.sector').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromsector.. 
 $('.sector_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cell ...
 
function cell_del_udpate(){
$('.cell_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cell').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcell.. 
 $('.cell_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from village ...
 
function village_del_udpate(){
$('.village_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.village').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromvillage.. 
 $('.village_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from citizen ...
 
function citizen_del_udpate(){
$('.citizen_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.citizen').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcitizen.. 
 $('.citizen_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cowmovement ...
 
function cowmovement_del_udpate(){
$('.cowmovement_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowmovement').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowmovement.. 
 $('.cowmovement_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cowidentification ...
 
function cowidentification_del_udpate(){
$('.cowidentification_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowidentification').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowidentification.. 
 $('.cowidentification_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cow_distribution ...
 
function cow_distribution_del_udpate(){
$('.cow_distribution_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cow_distribution').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcow_distribution.. 
 $('.cow_distribution_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cowdonor ...
 
function cowdonor_del_udpate(){
$('.cowdonor_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowdonor').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowdonor.. 
 $('.cowdonor_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from newborn_distribution ...
 
function newborn_distribution_del_udpate(){
$('.newborn_distribution_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.newborn_distribution').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromnewborn_distribution.. 
 $('.newborn_distribution_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cowsold ...
 
function cowsold_del_udpate(){
$('.cowsold_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowsold').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowsold.. 
 $('.cowsold_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cowborn ...
 
function cowborn_del_udpate(){
$('.cowborn_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowborn').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowborn.. 
 $('.cowborn_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cowstolen ...
 
function cowstolen_del_udpate(){
$('.cowstolen_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowstolen').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowstolen.. 
 $('.cowstolen_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cowdead ...
 
function cowdead_del_udpate(){
$('.cowdead_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowdead').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowdead.. 
 $('.cowdead_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cowtreatment ...
 
function cowtreatment_del_udpate(){
$('.cowtreatment_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cowtreatment').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcowtreatment.. 
 $('.cowtreatment_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from roles ...
 
function roles_del_udpate(){
$('.roles_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.roles').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromroles.. 
 $('.roles_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from sector_uesrs ...
 
function sector_uesrs_del_udpate(){
$('.sector_uesrs_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.sector_uesrs').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromsector_uesrs.. 
 $('.sector_uesrs_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cell_users ...
 
function cell_users_del_udpate(){
$('.cell_users_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cell_users').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcell_users.. 
 $('.cell_users_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from village_users ...
 
function village_users_del_udpate(){
$('.village_users_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.village_users').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromvillage_users.. 
 $('.village_users_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from district_users ...
 
function district_users_del_udpate(){
$('.district_users_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.district_users').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromdistrict_users.. 
 $('.district_users_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from user_cat ...
 
function user_cat_del_udpate(){
$('.user_cat_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.user_cat').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromuser_cat.. 
 $('.user_cat_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from sector ...
 
function sector_del_udpate(){
$('.sector_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.sector').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromsector.. 
 $('.sector_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from cell ...
 
function cell_del_udpate(){
$('.cell_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.cell').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromcell.. 
 $('.cell_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from insemination ...
 
function insemination_del_udpate(){
$('.insemination_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.insemination').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete frominsemination.. 
 $('.insemination_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from visit_event ...
 
function visit_event_del_udpate(){
$('.visit_event_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.visit_event').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromvisit_event.. 
 $('.visit_event_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from images ...
 
function images_del_udpate(){
$('.images_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.images').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromimages.. 
 $('.images_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from kwakwa_inka ...
 
function kwakwa_inka_del_udpate(){
$('.kwakwa_inka_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.kwakwa_inka').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromkwakwa_inka.. 
 $('.kwakwa_inka_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}//update from sickcow ...
 
function sickcow_del_udpate(){
$('.sickcow_update_link').unbind('click').click(function () {
        var table_to_update = $(this).closest('td').siblings('.sickcow').attr('title');
        var id_update = $(this).attr('value').trim();
        $.post('../Admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromsickcow.. 
 $('.sickcow_delete_link').unbind('click').click(function () {
        table_to_delete = $(this).data('table');
          id_delete = $(this).data('id_delete');
          current_del_btn = $(this);
          show_Y_N_dialog();        

    });
}
