<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_cowtreatment'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'cowtreatment'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $cowtreatment_id=$_SESSION['id_upd'];
                      
$cow_distribution =trim( $_POST['txt_cow_distribution_id']);
$symptomology = $_POST['txt_symptomology'];
$interventions = $_POST['txt_interventions'];
$comments = $_POST['txt_comments'];
$date_treatment = $_POST['txt_date_treatment'];
$user = $_POST['txt_user_id'];

$date = $_POST['txt_date'];


$upd_obj->update_cowtreatment($cow_distribution, $symptomology, $interventions, $comments, $date_treatment, $user, $date,$cowtreatment_id);
unset($_SESSION['table_to_update']);
}}else{$cow_distribution =trim( $_POST['txt_cow_distribution_id']);
$symptomology = $_POST['txt_symptomology'];
$interventions = $_POST['txt_interventions'];
$comments = $_POST['txt_comments'];
$date_treatment = $_POST['txt_date_treatment'];
$user =trim( $_POST['txt_user_id']);
$date = $_POST['txt_date'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_cowtreatment($cow_distribution, $symptomology, $interventions, $comments, $date_treatment, $user, $date);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
cowtreatment</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_cowtreatment.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_cow_distribution_id"   name="txt_cow_distribution_id"/><input type="hidden" id="txt_user_id"   name="txt_user_id"/>
      <?php
            include 'admin_header.php';
                ?>

  <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog--><div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 cowtreatment saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered new_data_title">  cowtreatment Registration </div>
 <table class="new_data_table">




<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_cowtreatment" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">cowtreatment List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_cowtreatment();
                    $obj->list_cowtreatment($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_cow_distribution_combo() {
    $obj = new multi_values();
    $obj->get_cow_distribution_in_combo();
}
function get_cow_distribution_combo() {
    $obj = new multi_values();
    $obj->get_cow_distribution_in_combo();
}
function chosen_cow_distribution_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowtreatment') {               $id = $_SESSION['id_upd'];
               $cow_distribution = new multi_values();
               return $cow_distribution->get_chosen_cowtreatment_cow_distribution($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_symptomology_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowtreatment') {               $id = $_SESSION['id_upd'];
               $symptomology = new multi_values();
               return $symptomology->get_chosen_cowtreatment_symptomology($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_interventions_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowtreatment') {               $id = $_SESSION['id_upd'];
               $interventions = new multi_values();
               return $interventions->get_chosen_cowtreatment_interventions($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_comments_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowtreatment') {               $id = $_SESSION['id_upd'];
               $comments = new multi_values();
               return $comments->get_chosen_cowtreatment_comments($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_date_treatment_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowtreatment') {               $id = $_SESSION['id_upd'];
               $date_treatment = new multi_values();
               return $date_treatment->get_chosen_cowtreatment_date_treatment($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_user_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowtreatment') {               $id = $_SESSION['id_upd'];
               $user = new multi_values();
               return $user->get_chosen_cowtreatment_user($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowtreatment') {               $id = $_SESSION['id_upd'];
               $date = new multi_values();
               return $date->get_chosen_cowtreatment_date($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
