<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_cowidentification'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'cowidentification'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $cowidentification_id=$_SESSION['id_upd'];
                      
$tag_number = $_POST['txt_tag_number'];
$color = $_POST['txt_color'];
$race = $_POST['txt_race'];
$donor = $_POST['txt_donor_id'];

$cow_status = $_POST['txt_cow_status'];
$user = $_POST['txt_user_id'];

$date = $_POST['txt_date'];
$sex = $_POST['txt_sex'];
$age = $_POST['txt_age'];


$upd_obj->update_cowidentification($tag_number, $color, $race, $donor, $cow_status, $user, $date, $sex, $age,$cowidentification_id);
unset($_SESSION['table_to_update']);
}}else{$tag_number = $_POST['txt_tag_number'];
$color = $_POST['txt_color'];
$race = $_POST['txt_race'];
$donor =trim( $_POST['txt_donor_id']);
$cow_status = $_POST['txt_cow_status'];
$user =trim( $_POST['txt_user_id']);
$date = $_POST['txt_date'];
$sex = $_POST['txt_sex'];
$age = $_POST['txt_age'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_cowidentification($tag_number, $color, $race, $donor, $cow_status, $user, $date, $sex, $age);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
cowidentification</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_cowidentification.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_donor_id"   name="txt_donor_id"/><input type="hidden" id="txt_user_id"   name="txt_user_id"/>
      <?php
            include 'admin_header.php';
                ?>

  <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog--><div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 cowidentification saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered new_data_title">  cowidentification Registration </div>
 <table class="new_data_table">




<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_cowidentification" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">cowidentification List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_cowidentification();
                    $obj->list_cowidentification($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_donor_combo() {
    $obj = new multi_values();
    $obj->get_donor_in_combo();
}
function get_donor_combo() {
    $obj = new multi_values();
    $obj->get_donor_in_combo();
}
function chosen_tag_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowidentification') {               $id = $_SESSION['id_upd'];
               $tag_number = new multi_values();
               return $tag_number->get_chosen_cowidentification_tag_number($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_color_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowidentification') {               $id = $_SESSION['id_upd'];
               $color = new multi_values();
               return $color->get_chosen_cowidentification_color($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_race_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowidentification') {               $id = $_SESSION['id_upd'];
               $race = new multi_values();
               return $race->get_chosen_cowidentification_race($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_donor_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowidentification') {               $id = $_SESSION['id_upd'];
               $donor = new multi_values();
               return $donor->get_chosen_cowidentification_donor($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_cow_status_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowidentification') {               $id = $_SESSION['id_upd'];
               $cow_status = new multi_values();
               return $cow_status->get_chosen_cowidentification_cow_status($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_user_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowidentification') {               $id = $_SESSION['id_upd'];
               $user = new multi_values();
               return $user->get_chosen_cowidentification_user($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowidentification') {               $id = $_SESSION['id_upd'];
               $date = new multi_values();
               return $date->get_chosen_cowidentification_date($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_sex_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowidentification') {               $id = $_SESSION['id_upd'];
               $sex = new multi_values();
               return $sex->get_chosen_cowidentification_sex($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_age_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowidentification') {               $id = $_SESSION['id_upd'];
               $age = new multi_values();
               return $age->get_chosen_cowidentification_age($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
