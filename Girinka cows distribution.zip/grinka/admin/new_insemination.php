<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_insemination'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'insemination'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $insemination_id=$_SESSION['id_upd'];
                      
$date = $_POST['txt_date'];
$user = $_POST['txt_user_id'];

$auto_brought = $_POST['txt_auto_brought'];
$type_semen = $_POST['txt_type_semen'];
$certif_number = $_POST['txt_certif_number'];
$comments = $_POST['txt_comments'];
$tag_number = $_POST['txt_tag_number'];
$insemin_date = $_POST['txt_insemin_date'];


$upd_obj->update_insemination($date, $user, $auto_brought, $type_semen, $certif_number, $comments, $tag_number, $insemin_date,$insemination_id);
unset($_SESSION['table_to_update']);
}}else{$date = $_POST['txt_date'];
$user =trim( $_POST['txt_user_id']);
$auto_brought = $_POST['txt_auto_brought'];
$type_semen = $_POST['txt_type_semen'];
$certif_number = $_POST['txt_certif_number'];
$comments = $_POST['txt_comments'];
$tag_number = $_POST['txt_tag_number'];
$insemin_date = $_POST['txt_insemin_date'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_insemination($date, $user, $auto_brought, $type_semen, $certif_number, $comments, $tag_number, $insemin_date);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
insemination</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_insemination.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_user_id"   name="txt_user_id"/>
      <?php
            include 'admin_header.php';
                ?>

  <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog--><div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 insemination saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered new_data_title">  insemination Registration </div>
 <table class="new_data_table">




<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_insemination" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">insemination List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_insemination();
                    $obj->list_insemination($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_user_combo() {
    $obj = new multi_values();
    $obj->get_user_in_combo();
}
function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'insemination') {               $id = $_SESSION['id_upd'];
               $date = new multi_values();
               return $date->get_chosen_insemination_date($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_user_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'insemination') {               $id = $_SESSION['id_upd'];
               $user = new multi_values();
               return $user->get_chosen_insemination_user($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_auto_brought_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'insemination') {               $id = $_SESSION['id_upd'];
               $auto_brought = new multi_values();
               return $auto_brought->get_chosen_insemination_auto_brought($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_type_semen_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'insemination') {               $id = $_SESSION['id_upd'];
               $type_semen = new multi_values();
               return $type_semen->get_chosen_insemination_type_semen($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_certif_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'insemination') {               $id = $_SESSION['id_upd'];
               $certif_number = new multi_values();
               return $certif_number->get_chosen_insemination_certif_number($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_comments_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'insemination') {               $id = $_SESSION['id_upd'];
               $comments = new multi_values();
               return $comments->get_chosen_insemination_comments($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_tag_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'insemination') {               $id = $_SESSION['id_upd'];
               $tag_number = new multi_values();
               return $tag_number->get_chosen_insemination_tag_number($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_insemin_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'insemination') {               $id = $_SESSION['id_upd'];
               $insemin_date = new multi_values();
               return $insemin_date->get_chosen_insemination_insemin_date($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
