<?php
 session_start();

if (isset($_POST['cbo_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_type_id_by_type_name($_POST['cbo_type']);
    return $id;
}
if (isset($_POST['cbo_sector'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_sector_id_by_sector_name($_POST['cbo_sector']);
    return $id;
}
if (isset($_POST['cbo_cell'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_cell_id_by_cell_name($_POST['cbo_cell']);
    return $id;
}
if (isset($_POST['cbo_fname'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_fname_id_by_fname_name($_POST['cbo_fname']);
    return $id;
}
if (isset($_POST['cbo_villiage'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_villiage_id_by_villiage_name($_POST['cbo_villiage']);
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
if (isset($_POST['cbo_distribution'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_distribution_id_by_distribution_name($_POST['cbo_distribution']);
    return $id;
}
if (isset($_POST['cbo_citizen'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_citizen_id_by_citizen_name($_POST['cbo_citizen']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_donor'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_donor_id_by_donor_name($_POST['cbo_donor']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_citizen'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_citizen_id_by_citizen_name($_POST['cbo_citizen']);
    return $id;
}
if (isset($_POST['cbo_cowidentf'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_cowidentf_id_by_cowidentf_name($_POST['cbo_cowidentf']);
    return $id;
}
if (isset($_POST['cbo_User'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_User_id_by_User_name($_POST['cbo_User']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_citizen'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_citizen_id_by_citizen_name($_POST['cbo_citizen']);
    return $id;
}
if (isset($_POST['cbo_cowborn'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_cowborn_id_by_cowborn_name($_POST['cbo_cowborn']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_distribution'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_distribution_id_by_distribution_name($_POST['cbo_distribution']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_cow_distribution'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_cow_distribution_id_by_cow_distribution_name($_POST['cbo_cow_distribution']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_cow_distribution'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_cow_distribution_id_by_cow_distribution_name($_POST['cbo_cow_distribution']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_cow_distribution'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_cow_distribution_id_by_cow_distribution_name($_POST['cbo_cow_distribution']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_cow_distribution'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_cow_distribution_id_by_cow_distribution_name($_POST['cbo_cow_distribution']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_users'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_users_id_by_users_name($_POST['cbo_users']);
    return $id;
}
if (isset($_POST['cbo_role'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_role_id_by_role_name($_POST['cbo_role']);
    return $id;
}
if (isset($_POST['cbo_sector'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_sector_id_by_sector_name($_POST['cbo_sector']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_cell'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_cell_id_by_cell_name($_POST['cbo_cell']);
    return $id;
}
if (isset($_POST['cbo_role'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_role_id_by_role_name($_POST['cbo_role']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_village'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_village_id_by_village_name($_POST['cbo_village']);
    return $id;
}
if (isset($_POST['cbo_role'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_role_id_by_role_name($_POST['cbo_role']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_sector'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_sector_id_by_sector_name($_POST['cbo_sector']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_user'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_user_id_by_user_name($_POST['cbo_user']);
    return $id;
}
if (isset($_POST['cbo_imageid'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_imageid_id_by_imageid_name($_POST['cbo_imageid']);
    return $id;
}
if (isset($_POST['cbo_old_citizen'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_old_citizen_id_by_old_citizen_name($_POST['cbo_old_citizen']);
    return $id;
}
if (isset($_POST['cbo_new_citizen'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_new_citizen_id_by_new_citizen_name($_POST['cbo_new_citizen']);
    return $id;
}
if (isset($_POST['cbo_distribution'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_distribution_id_by_distribution_name($_POST['cbo_distribution']);
    return $id;
}

if (isset($_POST['table_to_update']) ) {
    $id_upd = $_POST['id_update'];
    $table_upd = $_POST['table_to_update'];
    $pref = 'upd_';
    $sufx = $table_upd;
    $_SESSION['table_to_update'] = $table_upd;
    $_SESSION['id_upd'] = $id_upd;
    echo $_SESSION['id_upd'];
}


//The Delete from user
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'user') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_user($id);}
//The Delete from sector
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'sector') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_sector($id);}
//The Delete from cell
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cell') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cell($id);}
//The Delete from village
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'village') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_village($id);}
//The Delete from citizen
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'citizen') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_citizen($id);}
//The Delete from cowmovement
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowmovement') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowmovement($id);}
//The Delete from cowidentification
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowidentification') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowidentification($id);}
//The Delete from cow_distribution
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cow_distribution') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cow_distribution($id);}
//The Delete from cowdonor
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowdonor') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowdonor($id);}
//The Delete from newborn_distribution
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'newborn_distribution') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_newborn_distribution($id);}
//The Delete from cowsold
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowsold') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowsold($id);}
//The Delete from cowborn
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowborn') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowborn($id);}
//The Delete from cowstolen
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowstolen') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowstolen($id);}
//The Delete from cowdead
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowdead') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowdead($id);}
//The Delete from cowtreatment
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cowtreatment') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cowtreatment($id);}
//The Delete from roles
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'roles') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_roles($id);}
//The Delete from sector_uesrs
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'sector_uesrs') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_sector_uesrs($id);}
//The Delete from cell_users
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cell_users') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cell_users($id);}
//The Delete from village_users
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'village_users') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_village_users($id);}
//The Delete from district_users
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'district_users') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_district_users($id);}
//The Delete from user_cat
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'user_cat') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_user_cat($id);}
//The Delete from sector
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'sector') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_sector($id);}
//The Delete from cell
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'cell') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_cell($id);}
//The Delete from insemination
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'insemination') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_insemination($id);}
//The Delete from visit_event
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'visit_event') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_visit_event($id);}
//The Delete from images
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'images') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_images($id);}
//The Delete from kwakwa_inka
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'kwakwa_inka') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_kwakwa_inka($id);}
//The Delete from sickcow
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'sickcow') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_sickcow($id);}
if (isset($_POST['pagination_n'])) {
    $_SESSION['pagination_n'] = $_POST['pagination_n'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['paginated_page'];
}
if (isset($_POST['page_no_iteml'])) {
    unset($_SESSION['pagination_n']);
    $_SESSION['page_no_iteml'] = $_POST['page_no_iteml'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['page_no_iteml'];
}
