<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_cowborn'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'cowborn'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $cowborn_id=$_SESSION['id_upd'];
                      
$cow_distribution =trim( $_POST['txt_cow_distribution_id']);
$sex_newborn = $_POST['txt_sex_newborn'];
$new_born_race = $_POST['txt_new_born_race'];
$ear_tag_number = $_POST['txt_ear_tag_number'];
$cow_status = $_POST['txt_cow_status'];
$date = $_POST['txt_date'];
$user = $_POST['txt_user_id'];

$info_source = $_POST['txt_info_source'];
$seen = $_POST['txt_seen'];


$upd_obj->update_cowborn($cow_distribution, $sex_newborn, $new_born_race, $ear_tag_number, $cow_status, $date, $user, $info_source, $seen,$cowborn_id);
unset($_SESSION['table_to_update']);
}}else{$cow_distribution =trim( $_POST['txt_cow_distribution_id']);
$sex_newborn = $_POST['txt_sex_newborn'];
$new_born_race = $_POST['txt_new_born_race'];
$ear_tag_number = $_POST['txt_ear_tag_number'];
$cow_status = $_POST['txt_cow_status'];
$date = $_POST['txt_date'];
$user =trim( $_POST['txt_user_id']);
$info_source = $_POST['txt_info_source'];
$seen = $_POST['txt_seen'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_cowborn($cow_distribution, $sex_newborn, $new_born_race, $ear_tag_number, $cow_status, $date, $user, $info_source, $seen);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
cowborn</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_cowborn.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_cow_distribution_id"   name="txt_cow_distribution_id"/><input type="hidden" id="txt_user_id"   name="txt_user_id"/>
      <?php
            include 'admin_header.php';
                ?>

  <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog--><div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 cowborn saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered new_data_title">  cowborn Registration </div>
 <table class="new_data_table">


<tr><td><label for="txt_seen">Seen </label></td><td> <input type="text"     name="txt_seen" required id="txt_seen" class="textbox" value="<?php echo trim(chosen_seen_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_cowborn" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">cowborn List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_cowborn();
                    $obj->list_cowborn($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_cow_distribution_combo() {
    $obj = new multi_values();
    $obj->get_cow_distribution_in_combo();
}
function get_cow_distribution_combo() {
    $obj = new multi_values();
    $obj->get_cow_distribution_in_combo();
}
function chosen_cow_distribution_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowborn') {               $id = $_SESSION['id_upd'];
               $cow_distribution = new multi_values();
               return $cow_distribution->get_chosen_cowborn_cow_distribution($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_sex_newborn_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowborn') {               $id = $_SESSION['id_upd'];
               $sex_newborn = new multi_values();
               return $sex_newborn->get_chosen_cowborn_sex_newborn($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_new_born_race_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowborn') {               $id = $_SESSION['id_upd'];
               $new_born_race = new multi_values();
               return $new_born_race->get_chosen_cowborn_new_born_race($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_ear_tag_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowborn') {               $id = $_SESSION['id_upd'];
               $ear_tag_number = new multi_values();
               return $ear_tag_number->get_chosen_cowborn_ear_tag_number($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_cow_status_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowborn') {               $id = $_SESSION['id_upd'];
               $cow_status = new multi_values();
               return $cow_status->get_chosen_cowborn_cow_status($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowborn') {               $id = $_SESSION['id_upd'];
               $date = new multi_values();
               return $date->get_chosen_cowborn_date($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_user_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowborn') {               $id = $_SESSION['id_upd'];
               $user = new multi_values();
               return $user->get_chosen_cowborn_user($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_info_source_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowborn') {               $id = $_SESSION['id_upd'];
               $info_source = new multi_values();
               return $info_source->get_chosen_cowborn_info_source($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_seen_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'cowborn') {               $id = $_SESSION['id_upd'];
               $seen = new multi_values();
               return $seen->get_chosen_cowborn_seen($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
