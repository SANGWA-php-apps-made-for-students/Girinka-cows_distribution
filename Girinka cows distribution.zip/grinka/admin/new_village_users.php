<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_village_users'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'village_users'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $village_users_id=$_SESSION['id_upd'];
                      
$user =trim( $_POST['txt_user_id']);
$village = $_POST['txt_village_id'];

$role = $_POST['txt_role_id'];



$upd_obj->update_village_users($user, $village, $role,$village_users_id);
unset($_SESSION['table_to_update']);
}}else{$user =trim( $_POST['txt_user_id']);
$village =trim( $_POST['txt_village_id']);
$role =trim( $_POST['txt_role_id']);

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_village_users($user, $village, $role);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
village_users</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_village_users.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

<input type="hidden" id="txt_user_id"   name="txt_user_id"/><input type="hidden" id="txt_village_id"   name="txt_village_id"/><input type="hidden" id="txt_role_id"   name="txt_role_id"/>
      <?php
            include 'admin_header.php';
                ?>

  <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog--><div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 village_users saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered new_data_title">  village_users Registration </div>
 <table class="new_data_table">




<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_village_users" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">village_users List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_village_users();
                    $obj->list_village_users($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_user_combo() {
    $obj = new multi_values();
    $obj->get_user_in_combo();
}
function get_user_combo() {
    $obj = new multi_values();
    $obj->get_user_in_combo();
}
function get_user_combo() {
    $obj = new multi_values();
    $obj->get_user_in_combo();
}
function chosen_user_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'village_users') {               $id = $_SESSION['id_upd'];
               $user = new multi_values();
               return $user->get_chosen_village_users_user($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_village_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'village_users') {               $id = $_SESSION['id_upd'];
               $village = new multi_values();
               return $village->get_chosen_village_users_village($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_role_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'village_users') {               $id = $_SESSION['id_upd'];
               $role = new multi_values();
               return $role->get_chosen_village_users_role($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}
