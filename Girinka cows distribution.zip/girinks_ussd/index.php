<?php

require_once 'includes/config.php';
require_once 'includes/database.php';
require_once 'includes/g_db.php';
require_once 'web_db/Datalist.php';
require_once 'web_db/new_values.php';
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

function headers() {
    header("HTTP/1.1 200 OK");
    header("Server: Apache-Coyote/1.1");
    header("Path=/ekaye/index.php");
    header("Freeflow: FC");
    header("cpRefId: 12345");
    header("Expires: -1");
    header("Pragma: no-cache");
    header("Cache-Control: max-age=0");
    header("Content-Type: UTF-8");
    header("Content-Length: 20");
}

function header_girinka() {
    header("HTTP/1.1 200 OK");
    header("Server: Apache-Coyote/1.1");
    header("Path=/ekaye/girinka.php");
    header("Freeflow: FC"); //
    header("cpRefId: 12345"); // 
    header("Expires: -1");
    header("Pragma: no-cache");
    header("Cache-Control: max-age=0");
    header("Content-Type: UTF-8");
    header("Content-Length: 20");
}

if ($_REQUEST['input'] == '757' || $_REQUEST['input'] == '0') {
    headers();

    $sql = "INSERT INTO ussd(data,input,sessionid,phone,time) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW()) ";
    $database->query($sql);
    echo "Welcome to Ekaye By Gisagara district.Hitamo icyo ushaka kureba: \n 1.Ibibazo \n 2.Ubudehe \n 3.Umuhigo \n 4.Girinka \n 5.Gusohoka ";
} else if ($_REQUEST['input'] == '1') {//For ibibazo input
    $sql = "SELECT id,input,sessionid,nic FROM ussd WHERE sessionid ='{$_REQUEST['sessionid']}' ORDER BY time DESC LIMIT 1  ";
    $query = $database->query($sql);
    $row = $database->fetch_array($query);
    if ($row['input'] == 4) {//Dead cows - and the user has entered the id
        $sql = "INSERT INTO ussd(data,input,sessionid,phone,time,input_name) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW(),'dead') ";
        $database->query($sql);
        echo 'Injiza nomero yirangamuntu yawe';
    } else {
        echo "IBIBAZO. \n Shyiramo numero y' indangamuntu kugirango ubashe gukomeza \n Shyiramo 0 usubire ahabanza";
    }
} else if ($_REQUEST['input'] == '2') {//for ubudehe input
    $sql = "SELECT id,input,sessionid,nic FROM ussd WHERE sessionid ='{$_REQUEST['sessionid']}' ORDER BY time DESC LIMIT 1  ";
    $query = $database->query($sql);
    $row = $database->fetch_array($query);
    if ($row['input'] == 4) {// this is the born
        header_girinka();
        $sql = "INSERT INTO ussd(data,input,sessionid,phone,time,input_name) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW(),'born') ";
        $database->query($sql);
        echo 'Injiza numero yirangamuntu';
    } else {
        header("HTTP/1.1 200 OK");
        header("Server: Apache-Coyote/1.1");
        header("cpRefId: 12345");
        header("Expires: -1");
        header("Pragma: no-cache");
        header("Cache-Control: max-age=0");
        header("Content-Type: UTF-8");
        header("Content-Length: 20");
        $sql = "INSERT INTO ussd(data,input,sessionid,phone,time) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW()) ";
        $database->query($sql);
        echo "UBUDEHE. \n Shyiramo numero y' indangamuntu ubashe gukomeza, niba ntayo ufite shyiramo iy'ukurera \n Shyiramo 0 usubire ahabanza";
    }
} else if ($_REQUEST['input'] == '3') {// oh 
    //check if the last menu was 4
    $sql = "SELECT id,input,sessionid,nic FROM ussd WHERE sessionid ='{$_REQUEST['sessionid']}' ORDER BY time DESC LIMIT 1  ";
    $query = $database->query($sql);
    $row = $database->fetch_array($query);
    if ($row['input'] == 4) {// this is the 
        header_girinka();
        $sql = "INSERT INTO ussd(data,input,sessionid,phone,time,input_name) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW(),'sold') ";
        $database->query($sql);
        echo 'Injiza numero yirangamuntu';
    } else {
        header("Server: Apache-Coyote/1.1");
        header("cpRefId: 12345");
        header("Expires: -1");
        header("Pragma: no-cache");
        header("Cache-Control: max-age=0");
        header("Content-Type: UTF-8");
        header("Content-Length: 20");
        $sql = "INSERT INTO ussd(data,input,sessionid,phone,time) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW()) ";
        $database->query($sql);
        echo "UMUHIGO. \n Shyiramo numero y'indangamuntu ubashe gukomeza \n Shyiramo 0 usubire ahabanza";
    }
} else if ($_REQUEST['input'] == '4') {// for closing the flare
    $sql = "SELECT id,input,sessionid,nic FROM ussd WHERE sessionid ='{$_REQUEST['sessionid']}' ORDER BY time DESC LIMIT 1  ";
    $query = $database->query($sql);
    $row = $database->fetch_array($query);
    if ($row['input'] == 4) {// this is the stolen cow
        header_girinka();
        $sql = "INSERT INTO ussd(data,input,sessionid,phone,time,input_name) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW(),'stolen') ";
        $database->query($sql);
        echo 'Injiza nomero yirangamuntu';
    } else {
        header_girinka();
        $sql = "INSERT INTO ussd(data,input,sessionid,phone,time,input_name) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW(),'girinka') ";
        $database->query($sql);
        echo "TANGA AMAKURU ATANDUKANYE KU: \n1. INKA YAPFUYE \n"
        . "2. INKA YAVUTSE \n"
        . "3. INKA YAGURISHIJWE \n"
        . "4. INKA YIBWE\n"
        . "5. INKA YAVUWE\n"
        . "6. INKA YARWAYE";
    }
} else if ($_REQUEST['input'] == '5') {// For treatment menu
    $sql = "SELECT id,input,sessionid,nic FROM ussd WHERE sessionid ='{$_REQUEST['sessionid']}' ORDER BY time DESC LIMIT 1  ";
    $query = $database->query($sql);
    $row = $database->fetch_array($query);
    if ($row['input'] == 4) {// this is the stolen cow
        header_girinka();
        $sql = "INSERT INTO ussd(data,input,sessionid,phone,time,input_name) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW(),'treatment') ";
        $database->query($sql);
        echo 'Injiza nomero yirangamuntu';
    } else {
        header_girinka();
        $sql = "INSERT INTO ussd(data,input,sessionid,phone,time,input_name) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW(),'treatment') ";
        $database->query($sql);
    }
} else if ($_REQUEST['input'] == '6') {
    $sql = "SELECT id,input,sessionid,nic FROM ussd WHERE sessionid ='{$_REQUEST['sessionid']}' ORDER BY time DESC LIMIT 1  ";
    $query = $database->query($sql);
    $row = $database->fetch_array($query);
    if ($row['input'] == 4) {// this is the stolen cow
        header("Path=/ekaye/girinka.php");
        header("Freeflow: FC"); //
        header("cpRefId: 12345"); // 
        header("Expires: -1");
        header("Pragma: no-cache");
        header("Cache-Control: max-age=0");
        header("Content-Type: UTF-8");
        header("Content-Length: 20");
        $sql = "INSERT INTO ussd(data,input,sessionid,phone,time,input_name) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW(),'sick') ";
        $database->query($sql);
        echo 'Injiza nomero yirangamuntu';
    } else {
        header_girinka();
        $sql = "INSERT INTO ussd(data,input,sessionid,phone,time,input_name) VALUES('$actual_link',{$_REQUEST['input']},{$_REQUEST['sessionid']},{$_REQUEST['msisdn']},NOW(),'sick') ";
        $database->query($sql);
    }
} else if ($_REQUEST['input'] != 757 && $_REQUEST['input'] != 0 && $_REQUEST['input'] != 1 && $_REQUEST['input'] != 2 && $_REQUEST['input'] != 3 && $_REQUEST['input'] != 4 && $_REQUEST['input'] != 5 && $_REQUEST['input'] != 6) {
    //connect to girinka db
    $sql_ctzn = $g_dbase->query("select Idnumber from citizen where Idnumber='{$_REQUEST['input']}'");
    $row_c = $g_dbase->fetch_array($sql_ctzn);
    $idnumber = $row_c['Idnumber'];

    if (!empty($idnumber)) {//if irangamuntu exists
        $received = new Datalist();
        $supervision = new new_values();
        $citizen_id = $received->get_citizenid_by_nid($_REQUEST['input']);
        $distribution_id = $received->get_distr_by_citizen($citizen_id);
        if (!empty($received->citzien_recieved_cow($citizen_id))) {// if the citizen has truly received a cow
            $sql_name = $database->query("select input_name from ussd where sessionid='{$_REQUEST['sessionid']}' ORDER BY time DESC LIMIT 1");
            $row = $database->fetch_array($sql_name);
            $tid = trim($_REQUEST['input']); //this is just trimmed input
            $c_name = $g_dbase->query("select fname,lname from citizen where Idnumber='$tid'");
            $rowczn = $g_dbase->fetch_array($c_name);
            $rowc = $rowczn['fname'] . ' ' . $rowczn['lname'];
            if ($row['input_name'] == 'dead') {
                if (!empty($received->cow_already_dead($distribution_id))) {//if the citizen's cow is already dead
                    echo 'Amakuru yuko inka yawe yapfuye asanzwe ahari';
                } else {
                    $supervision->new_cowdead($distribution_id, date("y-m-d"), '', '', 0, date("y-m-d"), 'phone', 'no'); //the user will be updated in updating time
                    echo $rowc . ' Amakuru yinka yapfuye utanze yakiriwe neza';
                }
            } else if ($row['input_name'] == 'born') {
                $supervision->new_cowborn($distribution_id, '', '', '', 'available', date("y-m-d"), 0, 'phone', 'no');
                echo $rowc . 'amakuru yinka yavutse utanze yakiriwe neza';
            } else if ($row['input_name'] == 'sold') {
                $supervision->new_cowsold($distribution_id, date("y-m-d"), 'no', date("y-m-d"), 0, '', 'phone', 'no');
                echo $rowc . ' amakuru yinka yagurishijwe utanze yakiriwe neza';
            } else if ($row['input_name'] == 'stolen') {
                echo $rowc . ' amakuru yinka yibwe utanze yakiriwe neza';
                $supervision->new_cowstolen($distribution_id, date("y-m-d"), 'yes', date("y-m-d"), 0, '', 'phone', 'no');
            } else if ($row['input_name'] == 'treatment') {
                echo $rowc . ' amakuru yinka yavuwe utanze yakiriwe neza';
                $supervision->new_cowtreatment($distribution_id, '', '', '', date("y-m-d"), 0, date("y-m-d"), 'phone', 'no');
            } else if ($row['input_name'] == 'sick') {
                echo $rowc . ' amakuru yinka yarwaye utanze yakiriwe neza';
                $supervision->new_sickcow($distribution_id, '', date("y-m-d"), 0, 'phone', 'no');
            } else {
                $sql = "SELECT id,input,sessionid,nic FROM ussd WHERE sessionid ='{$_REQUEST['sessionid']}' ORDER BY time DESC LIMIT 1  ";
                $query = $database->query($sql);
                $row = $database->fetch_array($query);
                //Processing ubudehe
                if ($row['input'] == 2) {
                    headers();
                    $sql = "SELECT category,hhm  FROM ubudehe WHERE q_1_9 ='{$_REQUEST['input']}'  ";
                    $query = $database->query($sql);
                    $row = $database->fetch_array($query);
                    if ($row['hhm'] != '') {
                        echo " Amazina: {$row['hhm']}; Icyiciro: {$row['category']} \n 0)usubire ahabanza \n 5) Gusohoka";
                    } else {
                        echo "Nomero y'indangamuntu washyizemo ntabudehe ifite, ongera ugerageze.";
                    }
                } else if ($row['input'] == 1) { //processing Ibibazo
                    if ($_REQUEST['input'] == 11) {
                        headers();
                        $sql = "SELECT Solution  FROM tbl_problems WHERE nic ='{$row['nic']}'  ";
                        $query1 = $database->query($sql);
                        $row1 = $database->fetch_array($query1);
                        if ($row1['Solution'] != '') {
                            echo " Igisubizo: {$row1['Solution']} \n 12)ibindi byakivuzweho \n 0)usubire ahabanza \n 5) Gusohoka";
                        } else {
                            echo "Ikibazo cyawe Ntagisubizo kirabona. \n 0)usubire ahabanza \n 5) Gusohoka";
                        }
                    } else if ($_REQUEST['input'] == 12) {
                        headers();
                        $sql = "SELECT Comment  FROM tbl_problems WHERE nic ='{$row['nic']}'  ";
                        $query1 = $database->query($sql);
                        $row1 = $database->fetch_array($query1);
                        if ($row1['Comment'] != '') {
                            echo " Ibindi: {$row1['Comment']} \n 0)usubire ahabanza \n 5) Gusohoka";
                        } else {
                            echo "Ntabindi byavuzwe kuri ikikibazo. \n 0)usubire ahabanza \n 5) Gusohoka";
                        }
                    } else {
                        headers();
                        $sql = "SELECT statement,Solution  FROM tbl_problems WHERE nic ='{$_REQUEST['input']}'  ";
                        $query1 = $database->query($sql);
                        $row1 = $database->fetch_array($query1);
                        if ($row1['statement'] != '') {
                            $sql = "UPDATE  ussd SET nic ='{$_REQUEST['input']}' WHERE id = {$row['id']}";
                            $database->query($sql);
                            echo " Ikabazo: {$row1['statement']} \n 11)Igisubizo \n 12)ibindi byakivuzweho \n 0)usubire ahabanza \n 4) Gusohoka";
                        } else {
                            echo "Nomero y'indangamuntu washyizemo ntago iri muri sisiteme yabantu bafite ibibazo. \n 0)usubire ahabanza \n 5) Gusohoka";
                        }
                    }
                } else if ($row['input'] == 4) {
                   header_girinka();
                    echo $_REQUEST['input'];
                } else if ($row['input'] == 3) { //processing Imihigo
                    header("HTTP/1.1 200 OK");
                    header("Server: Apache-Coyote/1.1");
                    header("Path=/ekaye/index.php");
                    header("cpRefId: 12345");
                    header("Expires: -1");
                    header("Pragma: no-cache");
                    header("Cache-Control: max-age=0");
                    echo "Iyi service ntibashije kuboneka";
                } else {
                    header("HTTP/1.1 200 OK");
                    header("Server: Apache-Coyote/1.1");
                    header("Path=/ekaye/index.php");
                    header("cpRefId: 12345");
                    header("Expires: -1");
                    header("Pragma: no-cache");
                    header("Cache-Control: max-age=0");
                    echo "Ibyo ushyizemo ntago byemewe.";
                }
            }
        } else {
            echo 'Irangamuntu yawe ntabwo iri kurutonde rwaborojwe';
        }
    } else {
        echo 'Irangamuntu yawe ntibashije kuboneka';
    }
}
 //360