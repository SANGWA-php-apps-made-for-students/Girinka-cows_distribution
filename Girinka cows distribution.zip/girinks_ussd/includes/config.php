<?php
//DATABASE CONSTANTS
 defined("DB_SERVE")? NULL : DEFINE("DB_SERVE","localhost");
 defined("DB_USER")? NULL : DEFINE("DB_USER","rushema");
 defined("DB_PASS")? NULL : DEFINE("DB_PASS","rushema");
 defined("DB_NAME")? NULL : DEFINE("DB_NAME","ekaye");
?>
