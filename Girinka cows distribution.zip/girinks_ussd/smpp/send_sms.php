<?php

    class send_sms {
        
    }

    require_once 'smppclient.class.php';
    require_once 'gsmencoder.class.php';
    require_once 'sockettransport.class.php';

    // Construct transport and clienti
    $transport = new SocketTransport(array('172.17.83.20'), 3339);
    $transport->setRecvTimeout(10000);
    $smpp = new SmppClient($transport);

    // Activate binary hex-output of server interaction
    $smpp->debug = true;
    $transport->debug = true;

    // Open the connection
    $transport->open();
    $smpp->bindTransmitter("SMPP294", "924SMPP");
    $message = 'Hello this is the test';
    $encodedMessage = GsmEncoder::utf8_to_gsm0338($message);
    $from = new SmppAddress('757', SMPP::TON_ALPHANUMERIC);
    $to = new SmppAddress('250785142113', SMPP::TON_INTERNATIONAL, SMPP::NPI_E164);
    $smpp->sendSMS($from, $to, $encodedMessage, $tags);
    $smpp->close();
    