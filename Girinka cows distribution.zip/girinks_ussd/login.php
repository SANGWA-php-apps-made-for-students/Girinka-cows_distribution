<?php
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>GIRINKA |Login</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link rel="shortcut icon" href="../web_images/cow.png" type="image/x-icon"><style>
            a{
                color: #fff;
            }
        </style>
    </head>
    <body id="bg_login">
        <form action="login.php" method="post">
            <div class=" parts  full_center_two_h title margin_free skin" style="min-height: 100px;">
                <div class="parts margin_free no_paddin_shade_no_Border margin_free">
                    <div class="parts box logo no_paddin_shade_no_Border margin_free">
                    </div>

                    <div class="parts no_paddin_shade_no_Border margin_free "style="font-size: 30px; font-weight: bolder;">GIRINKA</div>


                </div>
            </div>
            <div class=" parts eighty_centered top_off_x no_paddin_shade_no_Border">
                <div class="xxx_titles iconed title_icon whilte_text" style="text-align: left">
                    Enter your username and password, all fields are required
                </div>
            </div>
            <div class="parts eighty_centered no_paddin_shade_no_Border top_off_x">

                <div class="parts pane no_bg no_paddin_shade_no_Border">
                    <div class="parts xx_titles  margin_free  skin">
                        Login
                    </div>
                    <div class="partsn x_titles no_paddin_shade_no_Border reverse_margin left_off_eighty">
                        Usename 
                    </div>
                    <div class="parts no_paddin_shade_no_Border left_off_eighty">
                        <input type="text" name="username" class="textbox" required>
                    </div>
                    <div class="parts no_paddin_shade_no_Border x_titles reverse_margin left_off_eighty">
                        Password:
                    </div>
                    <div class="parts no_paddin_shade_no_Border left_off_eighty">
                        <input type="password" name="password" class="textbox" required>
                    </div>
                    <div class="parts eighty_centered no_paddin_shade_no_Border" style="color: #ff0000;"><?php
                            login();
                        ?></div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                        <input type="submit"name="send" class="button right_off_eighty" value="Login">

                    </div>
                </div>
                <div class="parts box off" id="hous_in_hand"></div>
                <div class="parts two_fifty_right off" id="side_pic"> </div>
                <a href="index.php"><div class="parts two_fifty_right no_paddin_shade_no_Border link_cursor" id="side_pic2"> </div></a>
                <div class="parts two_fifty_right sixty_percent  whilte_text no_shade_noBorder" >

                </div>
            </div>

        </form>
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/scriptsAddon.js" type="text/javascript"></script>
    </body>
</html>
<?php

    function login() {
        if (isset($_POST['send'])) {
            $obj = new more_db_op();
//        require_once './web_db/updates.php';
//        $obj_update = new updates();

            $username = $_POST['username'];
            $password = $_POST['password'];
            $cat = $obj->get_user_category($username, $password);

            if (isset($cat)) {
                $_SESSION['names'] = $obj->get_name_logged_in($username, $password);
                $_SESSION['userid'] = $obj->get_id_logged_in($username, $password);
                $_SESSION['cat'] = $obj->get_user_category($username, $password);
                $_SESSION['login_token'] = $_SESSION['userid'];
                $_SESSION['user_cat_loc'] = $obj->get_user_cat_loc($username, $password);
                $_SESSION['loc'] = $obj->get_loc($username, $password); //this is the location name
                $_SESSION['loc_id'] = $obj->get_sector_id_by_user($username, $password);
                $_SESSION['any_alert'] = (!empty($obj->get_if_alert())) ? $obj->get_if_alert() : '';
//update that the user is online
                //$obj_update->get_user_online($_SESSION['userid']);
                if ($cat == 'Administrator') {//he is sector
                    header('location: admin/admin_dashboard.php');
                } else if ($cat == 'manager') {// he is district
//                header('location: District/districtDashboard.php');
                } else if ($cat == 'agent') {// he is minagri
                    header('location: Minagri/MinagriDashboard.php');
                } else if ($cat == 'admin') {// he is amdinistrator
                    header('location: adminDash/index.php');
                }
            } else {
                echo '<div class="red_message">Username or password invalid</div>';
            }
        }
    }

    class more_db_op {

        function get_if_alert() {
            $con = new dbconnection();
            $sql_dead = "select count(cowdead_id) as cowdead_id from cowdead where info_source='phone' and seen='no'";
            $sql_cowborn = "select cowborn.cowborn_id from cowborn where info_source='phone' and seen='no'";
            $sql_cowstolen = "select cowstolen.cowstolen_id from cowstolen where info_source='phone' and seen ='no'";
            $sql_cowsold = "select cowsold.cowsold_id from cowsold where info_source='phone' and seen='no'";

            $stmt_dead = $con->openconnection()->prepare($sql_dead);
            $stmt_born = $con->openconnection()->prepare($sql_cowborn);
            $stmt_stolen = $con->openconnection()->prepare($sql_cowstolen);
            $stmt_sold = $con->openconnection()->prepare($sql_cowsold);

            $stmt_dead->execute();
            $stmt_born->execute();
            $stmt_stolen->execute();
            $stmt_sold->execute();

            $row_dead = $stmt_dead->fetch(PDO::FETCH_ASSOC);
            $row_born = $stmt_born->fetch(PDO::FETCH_ASSOC);
            $row_stolen = $stmt_stolen->fetch(PDO::FETCH_ASSOC);
            $row_sold = $stmt_sold->fetch(PDO::FETCH_ASSOC);

            $dead = $row_born = $userid = $row_dead['cowdead_id'];
            $born = $row_born = $userid = $row_born['cowborn_id'];
            $stolen = $row_born = $userid = $row_stolen['cowstolen_id'];
            $sold = $row_born = $userid = $row_sold['cowsold_id'];
            if (!empty($dead) || !empty($born) || !empty($stolen) || !empty($sold)) {
                return 'found';
            } else {
                return 'not found';
            }
        }

        function get_user_category($user_name, $password) {
            require_once 'admin/dbConnection.php';
            $con = new dbconnection();
            $cat = '';
            $sql = "select   type from user where username=:username and password=:password";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->bindValue(':username', $user_name);
            $stmt->bindValue(':password', $password);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $cat = $row['type'];
            return $cat;
        }

        function get_name_logged_in($user_name, $password) {
            require_once 'admin/dbConnection.php';
            $con = new dbconnection();
            $cat = '';
            $sql = "select names from user where username=:username and password=:password";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->bindValue(':username', $user_name);
            $stmt->bindValue(':password', $password);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $cat = $row['names'];
            return $cat;
        }

        function get_userid_by_Acc_cat($name) {
            $userid = 0;
            require_once '../admin/dbConnection.php';
            $con = new my_connection();
            $sql = "select    account.account_id from  account join account_category on account_category.account_category_id=account.account_category where   name = :name";
            $stmt = $con->getCon()->prepare($sql);
            $stmt->bindValue(':name', $name);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['account_id'];
            return $userid;
        }

        function get_id_logged_in($user_name, $password) {
            $userid = 0;
            require_once 'admin/dbConnection.php';
            $con = new dbconnection();
            $sql = "select    user_id from user where username=:username and password=:password";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->bindValue(':username', $user_name);
            $stmt->bindValue(':password', $password);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $userid = $row['user_id'];
            return $userid;
        }

        function get_user_cat_loc($username, $password) {
            $con = new dbconnection();
            $sql = "select user_cat.name from user
                    join user_cat on user_cat.user_cat_id=user.cat
                    where user.username=:username and user.password=:password";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":username" => $username, ":password" => $password));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['name'];
            return $first_rec;
        }

        function get_loc($username, $password) {
            $loc_name = '';
            if ($_SESSION['user_cat_loc'] == 'district') {
                return 'Gisagara';
            } else if ($_SESSION['user_cat_loc'] == 'sector') {
                return $this->get_sector_name_by_user($username, $password);
            } else {
                return $this->get_cell_name_by_user($username, $password);
            }
        }

        function get_sector_name_by_user($username, $password) {
            require_once 'admin/dbConnection.php';
            $con = new dbconnection();
            $cat = '';
            $sql = "select sector.name from sector  
                join  sector_uesrs on sector.sector_id=sector_uesrs.sector
                join  user on sector_uesrs.role = user.cat 
                join  user_cat on user_cat.user_cat_id=user.cat
                where user.username=:username and password=:password ";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->bindValue(':username', $username);
            $stmt->bindValue(':password', $password);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $cat = $row['name'];
            return $cat;
        }

        function get_sector_id_by_user($username, $password) {
            require_once 'admin/dbConnection.php';
            $con = new dbconnection();
            $sql = "select sector.sector_id from sector  
                join  sector_uesrs on sector.sector_id=sector_uesrs.sector
                join  user on sector_uesrs.users = user.user_id 
                join  user_cat on user_cat.user_cat_id=user.cat
                where user.username=:username and password=:password ";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->bindValue(':username', $username);
            $stmt->bindValue(':password', $password);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row['sector_id'];
        }

        function get_cell_name_by_user($username, $password) {
            require_once 'admin/dbConnection.php';
            $con = new dbconnection();
            $cat = '';
            $sql = "select cell.name from cell
        join  cell_users on  cell_users.cell=cell.cell_id
         join user on cell_users.user = user.user_id 
          join user_cat on user_cat.user_cat_id=user.cat 
          where user.username=:username and user.password=:password ";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->bindValue(':username', $username);
            $stmt->bindValue(':password', $password);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $cat = $row['name'];
            return $cat;
        }

    }
    