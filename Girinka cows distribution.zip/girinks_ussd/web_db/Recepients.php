<?php

    class recipients {

        function functionName($param) {
            
        }

    }
    