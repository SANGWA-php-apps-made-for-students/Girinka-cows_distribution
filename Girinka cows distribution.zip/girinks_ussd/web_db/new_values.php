<?php

    require_once 'connection.php';

    class new_values {

        function new_cowsold($distribution, $date_sold, $redistributed, $date, $user, $comments, $info_source, $seen) {
            try {
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cowsold values(:cowsold_id, :distribution,  :date_sold,  :redistributed,  :date,  :user,  :comments,  :info_source,  :seen)");
                $stm->execute(array(':cowsold_id' => 0, ':distribution' => $distribution, ':date_sold' => $date_sold, ':redistributed' => $redistributed, ':date' => $date, ':user' => $user, ':comments' => $comments, ':info_source' => $info_source, ':seen' => $seen));

                require_once 'smppclient.class.php';
                require_once 'gsmencoder.class.php';
                require_once 'sockettransport.class.php';
                require_once 'sms.php';
                $send_now = new send_sms();
                $address = new citizen_address();
                $addrs = $address->get_village($distribution);
                $names = $address->get_names($distribution);
                // <editor-fold defaultstate="collapsed" desc="----Sms-----">
                $message = ' atanze amakuru ko inka yagurishijwe'; //'Umuturage utuye Akaboti/Impinga/Kansi atanze amakuru yinka yapfuye';;
                $send_now->saying($names, $addrs, $message, '250784113888');
                $send_now->saying($names, $addrs, $message, '250788612293');
                $send_now->saying($names, $addrs, $message, '250788842221');
                $send_now->saying($names, $addrs, $message, '250788352353');
                $send_now->saying($names, $addrs, $message, '250788977537');
                $send_now->saying($names, $addrs, $message, '250788861991');
                $send_now->saying($names, $addrs, $message, '250783393726');
                $send_now->saying($names, $addrs, $message, '250783597413');
                $send_now->saying($names, $addrs, $message, '250788465214');
                $send_now->saying($names, $addrs, $message, '250783215457');
                $send_now->saying($names, $addrs, $message, '250783345425');
                $send_now->saying($names, $addrs, $message, '250783397681');
                $send_now->saying($names, $addrs, $message, '250784018929');
                $send_now->saying($names, $addrs, $message, '250784450330');
                $send_now->saying($names, $addrs, $message, '250783650392');
                $send_now->saying($names, $addrs, $message, '250788660324');
                $send_now->saying($names, $addrs, $message, '250788864721');
                $send_now->saying($names, $addrs, $message, '250788801340');
                $send_now->saying($names, $addrs, $message, '250781260515');
                $send_now->saying($names, $addrs, $message, '250784113888');
                $send_now->saying($names, $addrs, $message, '250788807478');
                $send_now->saying($names, $addrs, $message, '250788748671');
// </editor-fold>
            } catch (PDOException $e) {
                echo 'Error .. ' . $e->getMessage();
            }
        }

        function new_cowborn($cow_distribution, $sex_newborn, $new_born_race, $ear_tag_number, $cow_status, $date, $user, $info_source, $seen) {
            try {
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cowborn values(:cowborn_id, :cow_distribution,  :sex_newborn,  :new_born_race,  :ear_tag_number,  :cow_status,  :date,  :user,  :info_source,  :seen)");
                $stm->execute(array(':cowborn_id' => 0, ':cow_distribution' => $cow_distribution, ':sex_newborn' => $sex_newborn, ':new_born_race' => $new_born_race, ':ear_tag_number' => $ear_tag_number, ':cow_status' => $cow_status, ':date' => $date, ':user' => $user, ':info_source' => $info_source, ':seen' => $seen));

                require_once 'smppclient.class.php';
                require_once 'gsmencoder.class.php';
                require_once 'sockettransport.class.php';
                require_once 'sms.php';
                $address = new citizen_address();
                $send_now = new send_sms();
                $addrs = $address->get_village($cow_distribution);
                $names = $address->get_names($cow_distribution);
                // <editor-fold defaultstate="collapsed" desc="----Sms-----">
                $message = ' atanze amakuru ko inka yavutse'; //'Umuturage utuye Akaboti/Impinga/Kansi atanze amakuru yinka yapfuye';;
                $send_now->saying($names, $addrs, $message, '250784113888');
                $send_now->saying($names, $addrs, $message, '250788612293');
                $send_now->saying($names, $addrs, $message, '250788842221');
                $send_now->saying($names, $addrs, $message, '250788352353');
                $send_now->saying($names, $addrs, $message, '250788977537');
                $send_now->saying($names, $addrs, $message, '250788861991');
                $send_now->saying($names, $addrs, $message, '250783393726');
                $send_now->saying($names, $addrs, $message, '250783597413');
                $send_now->saying($names, $addrs, $message, '250788465214');
                $send_now->saying($names, $addrs, $message, '250783215457');
                $send_now->saying($names, $addrs, $message, '250783345425');
                $send_now->saying($names, $addrs, $message, '250783397681');
                $send_now->saying($names, $addrs, $message, '250784018929');
                $send_now->saying($names, $addrs, $message, '250784450330');
                $send_now->saying($names, $addrs, $message, '250783650392');
                $send_now->saying($names, $addrs, $message, '250788660324');
                $send_now->saying($names, $addrs, $message, '250788864721');
                $send_now->saying($names, $addrs, $message, '250788801340');
                $send_now->saying($names, $addrs, $message, '250781260515');
                $send_now->saying($names, $addrs, $message, '250784113888');
                $send_now->saying($names, $addrs, $message, '250788807478');
                $send_now->saying($names, $addrs, $message, '250788748671');
// </editor-fold>
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cowstolen($cow_distribution, $date_stolen, $returned, $date, $user, $comments, $info_source, $seen) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cowstolen values(:cowstolen_id, :cow_distribution,  :date_stolen,  :returned,  :date,  :user,  :comments,  :info_source,  :seen)");
                $stm->execute(array(':cowstolen_id' => 0, ':cow_distribution' => $cow_distribution, ':date_stolen' => $date_stolen, ':returned' => $returned, ':date' => $date, ':user' => $user, ':comments' => $comments, ':info_source' => $info_source, ':seen' => $seen));

                require_once 'smppclient.class.php';
                require_once 'gsmencoder.class.php';
                require_once 'sockettransport.class.php';
                require_once 'sms.php';

                $address = new citizen_address();
                $send_now = new send_sms();
                $addrs = $address->get_village($cow_distribution);
                $names = $address->get_names($cow_distribution);
                // <editor-fold defaultstate="collapsed" desc="----Sms-----">

                $message = ' atanze amakuru ko inka yibwe'; //'Umuturage utuye Akaboti/Impinga/Kansi atanze amakuru yinka yapfuye';;
                $send_now->saying($names, $addrs, $message, '250784113888');
                $send_now->saying($names, $addrs, $message, '250788612293');
                $send_now->saying($names, $addrs, $message, '250788842221');
                $send_now->saying($names, $addrs, $message, '250788352353');
                $send_now->saying($names, $addrs, $message, '250788977537');
                $send_now->saying($names, $addrs, $message, '250788861991');
                $send_now->saying($names, $addrs, $message, '250783393726');
                $send_now->saying($names, $addrs, $message, '250783597413');
                $send_now->saying($names, $addrs, $message, '250788465214');
                $send_now->saying($names, $addrs, $message, '250783215457');
                $send_now->saying($names, $addrs, $message, '250783345425');
                $send_now->saying($names, $addrs, $message, '250783397681');
                $send_now->saying($names, $addrs, $message, '250784018929');
                $send_now->saying($names, $addrs, $message, '250784450330');
                $send_now->saying($names, $addrs, $message, '250783650392');
                $send_now->saying($names, $addrs, $message, '250788660324');
                $send_now->saying($names, $addrs, $message, '250788864721');
                $send_now->saying($names, $addrs, $message, '250788801340');
                $send_now->saying($names, $addrs, $message, '250781260515');
                $send_now->saying($names, $addrs, $message, '250784113888');
                $send_now->saying($names, $addrs, $message, '250788807478');
                $send_now->saying($names, $addrs, $message, '250788748671');
// </editor-fold>
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cowdead($cow_distribution, $date_dead, $reason_death, $comments, $user, $date, $info_source, $seen) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cowdead values(:cowdead_id, :cow_distribution,  :date_dead,  :reason_death,  :comments,  :user,  :date,  :info_source,  :seen)");
                $stm->execute(array(':cowdead_id' => 0, ':cow_distribution' => $cow_distribution, ':date_dead' => $date_dead, ':reason_death' => $reason_death, ':comments' => $comments, ':user' => $user, ':date' => $date, ':info_source' => $info_source, ':seen' => $seen));
                //

                require_once 'smppclient.class.php';
                require_once 'gsmencoder.class.php';
                require_once 'sockettransport.class.php';
                require_once 'sms.php';

                $address = new citizen_address();
                $send_now = new send_sms();
                $addrs = $address->get_village($cow_distribution);
                $names = $address->get_names($cow_distribution);
                // <editor-fold defaultstate="collapsed" desc="----Sms-----">
                $message = ' atanze amakuru ko inka yapfuye'; //'Umuturage utuye Akaboti/Impinga/Kansi atanze amakuru yinka yapfuye';;
                $send_now->saying($names, $addrs, $message, '250784113888');
                $send_now->saying($names, $addrs, $message, '250788612293');
                $send_now->saying($names, $addrs, $message, '250788842221');
                $send_now->saying($names, $addrs, $message, '250788352353');
                $send_now->saying($names, $addrs, $message, '250788977537');
                $send_now->saying($names, $addrs, $message, '250788861991');
                $send_now->saying($names, $addrs, $message, '250783393726');
                $send_now->saying($names, $addrs, $message, '250783597413');
                $send_now->saying($names, $addrs, $message, '250788465214');
                $send_now->saying($names, $addrs, $message, '250783215457');
                $send_now->saying($names, $addrs, $message, '250783345425');
                $send_now->saying($names, $addrs, $message, '250783397681');
                $send_now->saying($names, $addrs, $message, '250784018929');
                $send_now->saying($names, $addrs, $message, '250784450330');
                $send_now->saying($names, $addrs, $message, '250783650392');
                $send_now->saying($names, $addrs, $message, '250788660324');
                $send_now->saying($names, $addrs, $message, '250788864721');
                $send_now->saying($names, $addrs, $message, '250788801340');
                $send_now->saying($names, $addrs, $message, '250781260515');
                $send_now->saying($names, $addrs, $message, '250784113888');
                $send_now->saying($names, $addrs, $message, '250788807478');
                $send_now->saying($names, $addrs, $message, '250788748671');
// </editor-fold>
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_sickcow($distribution, $sickness, $entry_date, $User, $infor_source, $seen) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into sickcow values(:sickcow_id, :distribution,  :sickness,  :entry_date,  :User,:info_source,:seen)");
                $stm->execute(array(':sickcow_id' => 0, ':distribution' => $distribution, ':sickness' => $sickness, ':entry_date' => $entry_date, ':User' => $User, ':info_source' => $infor_source, ':seen' => $seen));

                require_once 'smppclient.class.php';
                require_once 'gsmencoder.class.php';
                require_once 'sockettransport.class.php';
                require_once 'sms.php';

                $address = new citizen_address();
                $send_now = new send_sms();
                $addrs = $address->get_village($distribution);
                $names = $address->get_names($distribution);
                // <editor-fold defaultstate="collapsed" desc="----Sms-----">

                $message = ' atanze amakuru ko inka yarwaye'; //'Umuturage utuye Akaboti/Impinga/Kansi atanze amakuru yinka yapfuye';;
                $send_now->saying($names, $addrs, $message, '250784113888');
                $send_now->saying($names, $addrs, $message, '250788612293');
                $send_now->saying($names, $addrs, $message, '250788842221');
                $send_now->saying($names, $addrs, $message, '250788352353');
                $send_now->saying($names, $addrs, $message, '250788977537');
                $send_now->saying($names, $addrs, $message, '250788861991');
                $send_now->saying($names, $addrs, $message, '250783393726');
                $send_now->saying($names, $addrs, $message, '250783597413');
                $send_now->saying($names, $addrs, $message, '250788465214');
                $send_now->saying($names, $addrs, $message, '250783215457');
                $send_now->saying($names, $addrs, $message, '250783345425');
                $send_now->saying($names, $addrs, $message, '250783397681');
                $send_now->saying($names, $addrs, $message, '250784018929');
                $send_now->saying($names, $addrs, $message, '250784450330');
                $send_now->saying($names, $addrs, $message, '250783650392');
                $send_now->saying($names, $addrs, $message, '250788660324');
                $send_now->saying($names, $addrs, $message, '250788864721');
                $send_now->saying($names, $addrs, $message, '250788801340');
                $send_now->saying($names, $addrs, $message, '250781260515');
                $send_now->saying($names, $addrs, $message, '250784113888');
                $send_now->saying($names, $addrs, $message, '250788807478');
                $send_now->saying($names, $addrs, $message, '250788748671');
// </editor-fold>
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_cowtreatment($cow_distribution, $symptomology, $interventions, $comments, $date_treatment, $user, $date, $info_source, $seen) {
            try {
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into cowtreatment values(:cowtreatment_id, :cow_distribution,  :symptomology,  :interventions,  :comments,  :date_treatment,  :user,  :date, :info_source,:seen)");
                $stm->execute(array(':cowtreatment_id' => 0, ':cow_distribution' => $cow_distribution, ':symptomology' => $symptomology, ':interventions' => $interventions, ':comments' => $comments, ':date_treatment' => $date_treatment, ':user' => $user, ':date' => $date, ':info_source' => $info_source, ':seen' => $seen));

                require_once 'smppclient.class.php';
                require_once 'gsmencoder.class.php';
                require_once 'sockettransport.class.php';
                require_once 'sms.php';

                $address = new citizen_address();
                $send_now = new send_sms();
                $addrs = $address->get_village($cow_distribution);
                $names = $address->get_names($cow_distribution);
                // <editor-fold defaultstate="collapsed" desc="----Sms-----">

                $message = ' atanze amakuru ko inka yavuwe'; //'Umuturage utuye Akaboti/Impinga/Kansi atanze amakuru yinka yapfuye';;
                $send_now->saying($names, $addrs, $message, '250784113888');
                $send_now->saying($names, $addrs, $message, '250788612293');
                $send_now->saying($names, $addrs, $message, '250788842221');
                $send_now->saying($names, $addrs, $message, '250788352353');
                $send_now->saying($names, $addrs, $message, '250788977537');
                $send_now->saying($names, $addrs, $message, '250788861991');
                $send_now->saying($names, $addrs, $message, '250783393726');
                $send_now->saying($names, $addrs, $message, '250783597413');
                $send_now->saying($names, $addrs, $message, '250788465214');
                $send_now->saying($names, $addrs, $message, '250783215457');
                $send_now->saying($names, $addrs, $message, '250783345425');
                $send_now->saying($names, $addrs, $message, '250783397681');
                $send_now->saying($names, $addrs, $message, '250784018929');
                $send_now->saying($names, $addrs, $message, '250784450330');
                $send_now->saying($names, $addrs, $message, '250783650392');
                $send_now->saying($names, $addrs, $message, '250788660324');
                $send_now->saying($names, $addrs, $message, '250788864721');
                $send_now->saying($names, $addrs, $message, '250788801340');
                $send_now->saying($names, $addrs, $message, '250781260515');
                $send_now->saying($names, $addrs, $message, '250784113888');
                $send_now->saying($names, $addrs, $message, '250788807478');
                $send_now->saying($names, $addrs, $message, '250788748671');
// </editor-fold>
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

    }

    class citizen_address {

        function get_village($distribudtion) {
            $obj = new dbconnection();
            $sql = "select citizen.village, village.name as village, cell.name as cell, sector.name as sector from citizen 
                    join cow_distribution on cow_distribution.citizen=citizen.citizen_id
                    join village on village.village_id=citizen.village
                    join cell on cell.cell_id=village.cell
                    join sector on sector.sector_id=cell.sector
                    where cow_distribution.cow_distribution_id=:distr";
            $stmt = $obj->openconnection()->prepare($sql);
            $stmt->execute(array(":distr" => $distribudtion));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $address = $row['village'] . ' / ' . $row['cell'] . ' / ' . $row['sector'];
            return $address;
        }

        function get_names($distribution) {
            $obj = new dbconnection();
            $sql = "select citizen.fname,citizen.lname, sector.name as sector from citizen 
                    join cow_distribution on cow_distribution.citizen=citizen.citizen_id
                    join village on village.village_id=citizen.village
                    join cell on cell.cell_id=village.cell
                    join sector on sector.sector_id=cell.sector
                    where cow_distribution.cow_distribution_id=:distr";
            $stmt = $obj->openconnection()->prepare($sql);
            $stmt->execute(array(":distr" => $distribution));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $names = $row['fname'] . ' ' . $row['lname'];
            return $names;
        }

    }
    