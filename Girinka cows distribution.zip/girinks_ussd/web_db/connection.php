<?php

class dbconnection {

    function openconnection() {
        $db = new PDO('mysql:host=localhost;dbname=girinka;charset=utf8mb4', 'rushema', 'rushema');
        return $db;
    }

}
