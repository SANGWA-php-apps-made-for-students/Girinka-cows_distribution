<?php 
require 'PHPMailerAutoload.php';
$mail = new PHPMailer;
//$mail->SMTPDebug = 3;                               // Enable verbose debug output
$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'kayibanda.ipage.com;smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'customer.care@bahopolyclinic.com'; // SMTP username
$mail->Password = 'We_care_you7890';                           // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                    // TCP port to connect to

$mail->From = 'customer.care@bahopolyclinic.com';
$mail->FromName = 'Baho Polyclinic website';
$mail->addAddress('info@bahopolyclinic.com', 'Information');     // Add a recipient
//$mail->addAddress('rushemaa@gmail.com');               // Name is optional
// $mail->addReplyTo('rushemaa@gmail.com', 'Information');
// $mail->addCC('rushemaa@gmail.com');
// $mail->addBCC('rushemaa@gmail.com');

// $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
// $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML
?>	